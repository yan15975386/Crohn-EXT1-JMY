#!/usr/bin/env python3
"""Offline audit and descriptive extensions of frozen, actually executed results.

Python >=3.8 standard library only. No downloads, package installation, count
model fitting, target replacement, or changes to expression eligibility.
"""
import argparse
import csv
import gzip
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def read_tsv(path):
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f, delimiter='\t'))


def write_tsv(path, rows):
    rows = list(rows)
    assert rows, 'Refusing to write a table with no rows: ' + str(path)
    columns = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, columns, delimiter='\t', lineterminator='\n')
        w.writeheader()
        for r in rows:
            w.writerow({k: ('NA' if v is None or isinstance(v, float) and not math.isfinite(v) else v) for k, v in r.items()})


def number(value):
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def bh(values):
    assert all(v is not None and 0 <= v <= 1 for v in values)
    order = sorted(range(len(values)), key=lambda i: values[i])
    ans = [1.0] * len(values)
    last = 1.0
    for j in range(len(order) - 1, -1, -1):
        i = order[j]
        last = min(last, values[i] * len(values) / (j + 1))
        ans[i] = last
    return ans


def dot(a, b):
    return math.fsum(x * y for x, y in zip(a, b))


def residuals(y, columns):
    """Reorthogonalized modified Gram-Schmidt projection, no normal equations."""
    q = []
    for column in columns:
        v = list(map(float, column))
        initial = math.sqrt(dot(v, v))
        if initial == 0:
            raise ValueError('Zero design column')
        v = [x / initial for x in v]
        for _ in range(2):
            for z in q:
                a = dot(z, v)
                v = [x - a * zz for x, zz in zip(v, z)]
        norm = math.sqrt(dot(v, v))
        if norm < 1e-10:
            raise ValueError('Rank deficient design')
        q.append([x / norm for x in v])
    result = list(map(float, y))
    for z in q:
        a = dot(z, result)
        result = [x - a * zz for x, zz in zip(result, z)]
    return result


def correlation(x, y):
    if len(x) < 3:
        return None
    xx = [v - statistics.mean(x) for v in x]
    yy = [v - statistics.mean(y) for v in y]
    denom = math.sqrt(dot(xx, xx) * dot(yy, yy))
    return max(-1.0, min(1.0, dot(xx, yy) / denom)) if denom else None


def ranks(values):
    order = sorted(range(len(values)), key=lambda i: values[i])
    out = [0.0] * len(values)
    i = 0
    while i < len(values):
        j = i + 1
        while j < len(values) and values[order[j]] == values[order[i]]:
            j += 1
        for k in range(i, j):
            out[order[k]] = (i + 1 + j) / 2
        i = j
    return out


def quantile(values, p):
    s = sorted(values)
    x = (len(s) - 1) * p
    lo = math.floor(x)
    hi = math.ceil(x)
    return s[lo] + (s[hi] - s[lo]) * (x - lo)


def eig_symmetric(matrix):
    a = [r[:] for r in matrix]
    n = len(a)
    for _ in range(100 * n * n):
        i, j = max(((i, j) for i in range(n) for j in range(i + 1, n)), key=lambda ij: abs(a[ij[0]][ij[1]]))
        if abs(a[i][j]) < 1e-13:
            return sorted(a[k][k] for k in range(n))
        theta = 0.5 * math.atan2(2 * a[i][j], a[j][j] - a[i][i])
        c, s = math.cos(theta), math.sin(theta)
        ai, aj, off = a[i][i], a[j][j], a[i][j]
        for k in range(n):
            if k not in (i, j):
                x, y = a[k][i], a[k][j]
                a[k][i] = a[i][k] = c * x - s * y
                a[k][j] = a[j][k] = s * x + c * y
        a[i][i] = c*c*ai - 2*s*c*off + s*s*aj
        a[j][j] = s*s*ai + 2*s*c*off + c*c*aj
        a[i][j] = a[j][i] = 0.0
    raise ValueError('Eigenvalue iteration did not converge')


def design_diagnostics(rows, name):
    keys = [k for k in rows[0] if k != 'unit_key']
    cols = [[float(r[k]) for r in rows] for k in keys]
    assert keys[0] == '(Intercept)' and set(cols[0]) == {1.0}
    # Check full rank; VIF includes every other predictor and the intercept.
    residuals([0.0] * len(rows), cols)
    vif = []
    standardized = [cols[0]]
    for j in range(1, len(keys)):
        y = cols[j]
        total = math.fsum((x - statistics.mean(y))**2 for x in y)
        resid = residuals(y, cols[:j] + cols[j+1:])
        rss = dot(resid, resid)
        vif.append({'model': name, 'term': keys[j], 'n': len(y), 'VIF': total / rss, 'R2_on_other_predictors': 1 - rss / total})
        standardized.append([(x - statistics.mean(y)) / math.sqrt(total) for x in y])
    standardized[0] = [1 / math.sqrt(len(rows))] * len(rows)
    gram = [[dot(a, b) for b in standardized] for a in standardized]
    ev = eig_symmetric(gram)
    assert ev[0] > 1e-10
    summary = {'model': name, 'n': len(rows), 'rank': len(keys), 'nominal_residual_df': len(rows)-len(keys), 'condition_number_scaled_design': math.sqrt(ev[-1]/ev[0]), 'max_VIF': max(r['VIF'] for r in vif)}
    return vif, summary


def matrix_stats(path):
    with gzip.open(path, 'rt') as f:
        assert f.readline().startswith('%%MatrixMarket matrix coordinate')
        line = f.readline()
        while line.startswith('%'):
            line = f.readline()
        ng, nu, nnz = map(int, line.split())
        totals, detected = [0] * nu, [set() for _ in range(nu)]
        entries = 0
        seen = set()
        for line in f:
            i, j, v = line.split()
            i, j, v = int(i)-1, int(j)-1, float(v)
            assert v >= 0 and v.is_integer() and 0 <= i < ng and 0 <= j < nu
            assert (i, j) not in seen, 'Duplicate coordinate in frozen matrix'
            seen.add((i, j))
            totals[j] += int(v)
            if v > 0:
                detected[j].add(i)
            entries += 1
        assert entries == nnz
    return ng, totals, [len(s) for s in detected]


def summaries_and_overlap(rows, model, group_key='group', value_key='IFN7_z'):
    groups = sorted(set(r[group_key] for r in rows))
    assert len(groups) == 2
    vals = {g: [float(r[value_key]) for r in rows if r[group_key] == g] for g in groups}
    low, high = max(min(v) for v in vals.values()), min(max(v) for v in vals.values())
    summaries = []
    for g in groups:
        v = vals[g]
        summaries.append({'model': model, 'group': g, 'n': len(v), 'mean': statistics.mean(v), 'sd': statistics.stdev(v), 'min': min(v), 'q25': quantile(v,.25), 'median': quantile(v,.5), 'q75': quantile(v,.75), 'max': max(v), 'shared_observed_range_low': low if low <= high else None, 'shared_observed_range_high': high if low <= high else None, 'n_in_shared_observed_range': sum(low <= x <= high for x in v), 'interpretation': 'Observed-range overlap is descriptive and does not establish positivity or lack of confounding.'})
    return summaries


def extract_roster(inp, out):
    roster = read_tsv(inp/'tables/Table_S26_recovered_exploratory_candidate_roster29.tsv')
    assert len(roster) == 29 and len(set(r['gene'] for r in roster)) == 28
    targets = sorted(set(r['gene'] for r in roster))
    long, primary, summaries, audits = [], [], [], []
    files = sorted((inp/'returned_server_R3').glob('ALL_genes_*.tsv.gz'))
    assert len(files) == 34
    for path in files:
        fit = path.name[len('ALL_genes_'):-len('.tsv.gz')]
        rows = read_tsv(path)
        # Validate the saved complete-transcriptome correction independently.
        computed = bh([float(r['PValue']) for r in rows])
        error = max(abs(q - float(r['genome_q'])) for q, r in zip(computed, rows))
        assert error < 1e-10
        audits.append({'check':'full_transcriptome_BH', 'fit':fit, 'passed':True, 'maximum_absolute_difference':error, 'n_genes':len(rows)})
        bysymbol = defaultdict(list)
        for r in rows:
            bysymbol[r['gene_symbol']].append(r)
        selected = {}
        for gene in targets:
            hits = bysymbol.get(gene, [])
            assert len(hits) <= 1, 'Ambiguous gene symbol; do not select by P: ' + gene
            selected[gene] = hits[0] if hits else None
        pvals = [float(selected[g]['PValue']) if selected[g] else 1.0 for g in targets]
        qs = dict(zip(targets, bh(pvals)))
        unique = []
        for gene in targets:
            r = selected[gene]
            result = {'fit':fit, 'followup_compartment':'CD163hi' if not fit.startswith('PAIRED') else 'paired_CD163hi_minus_ITGA4', 'gene':gene, 'status':'TESTED' if r else 'NOT_IN_FILTERED_FIT', 'log2FC':number(r['logFC']) if r else None, 'P':number(r['PValue']) if r else None, 'transcriptome_q':number(r['genome_q']) if r else None, 'q_unique28_sensitivity':qs[gene] if r else None, 'CI95_low':number(r['CI95_low']) if r else None, 'CI95_high':number(r['CI95_high']) if r else None, 'n_unique_targets_family':28}
            unique.append(result)
            if fit in ['ORIGINAL_A_vs_H_edgeR_QL','ORIGINAL_A_vs_H_limma_voom']:
                primary.append(result)
        ud = {r['gene']:r for r in unique}
        for i, record in enumerate(roster,1):
            result = dict(ud[record['gene']])
            result.update({'roster_record':i,'source_compartment':record['compartment'],'source_log2FC':float(record['logFC']),'later_EXT1_JMY_focus':record['later_EXT1_JMY_focus'],'source_state_not_equated_to_followup':True,'duplicate_symbol_in_roster':sum(s['gene']==record['gene'] for s in roster)>1})
            long.append(result)
        summaries.append({'fit':fit,'roster_records':29,'unique_genes':28,'tested_unique_genes':sum(r['status']=='TESTED' for r in unique),'not_in_fit_unique_genes':sum(r['status']!='TESTED' for r in unique),'transcriptome_q_below_0_05':sum(r['transcriptome_q'] is not None and r['transcriptome_q']<.05 for r in unique),'frozen_gene_family_q_below_0_05':sum(r['q_unique28_sensitivity'] is not None and r['q_unique28_sensitivity']<.05 for r in unique)})
    assert len(long)==986 and len(primary)==56
    write_tsv(out/'Table_S28_roster29_all34_saved_fits986.tsv',long)
    write_tsv(out/'Table_S29_unique28_primary_methods56.tsv',primary)
    write_tsv(out/'Roster_fit_summary34.tsv',summaries)
    return audits


def ifn_diagnostics(inp, out):
    allvif, allsummary, overlap, correlations, plots = [], [], [], [], []
    display = read_tsv(inp/'tables/Figure4_patient_expression_DISPLAY_ONLY.tsv')
    for contrast in ['A_vs_H','A_vs_U']:
        fit = 'IFN7_COHORT_' + contrast
        units = read_tsv(inp/'returned_server_R3'/('units_'+fit+'.tsv'))
        design = read_tsv(inp/'returned_server_R3'/('design_'+fit+'.tsv'))
        assert [r['unit_key'] for r in units] == [r['unit_key'] for r in design]
        for u,d in zip(units,design):
            assert abs(float(u['IFN7_z'])-float(d['IFN7_z']))<1e-12
        vif, summary = design_diagnostics(design,fit)
        allvif.extend(vif);allsummary.append(summary)
        overlap.extend(summaries_and_overlap(units,fit))
        selected = [r for r in display if r['model_id']=='CD163hi_Full_'+contrast]
        lookup = {(r['unit_key'],r['gene_symbol']):r for r in selected}
        assert len(lookup)==2*len(units)
        for u in units:
            a,b = lookup[(u['unit_key'],'EXT1')],lookup[(u['unit_key'],'JMY')]
            assert a['group']==b['group']==u['group']
            assert a['individual_id']==b['individual_id']==u['individual_id']
            plots.append({'model':fit,'unit_key':u['unit_key'],'individual_id':u['individual_id'],'group':u['group'],'IFN7_z':float(u['IFN7_z']),'log2_cells':float(u['log2_cells']),'EXT1_log2CPM_plus1':float(a['log2_TMM_CPM_plus1_display_only']),'JMY_log2CPM_plus1':float(b['log2_TMM_CPM_plus1_display_only']),'IFN7_raw_display':float(a['IFN7_mean_log2_TMM_CPM_plus1_DESCRIPTIVE'])})
        pv = [r for r in plots if r['model']==fit]
        # Exact frozen score alignment check, not a new score definition.
        raw=[r['IFN7_raw_display'] for r in pv]
        z=[(x-statistics.mean(raw))/statistics.stdev(raw) for x in raw]
        assert max(abs(a-r['IFN7_z']) for a,r in zip(z,pv))<1e-10
        x=[r['IFN7_z'] for r in pv]
        y=[float(r['group']=='CD_inflamed') for r in pv]
        correlations.append({'model':fit,'subset':'ALL','x':'IFN7_z','y':'case_group_binary','n':len(pv),'Pearson_r':correlation(x,y),'Spearman_rho':correlation(ranks(x),ranks(y)),'P_values_computed':False,'interpretation':'Descriptive group-score association, not causal regulation or independent validation.'})
        for subset in ['ALL']+sorted(set(r['group'] for r in pv)):
            rs=[r for r in pv if subset=='ALL' or r['group']==subset]
            for variable in ['log2_cells','EXT1_log2CPM_plus1','JMY_log2CPM_plus1']:
                x=[r['IFN7_z'] for r in rs];y=[r[variable] for r in rs]
                correlations.append({'model':fit,'subset':subset,'x':'IFN7_z','y':variable,'n':len(rs),'Pearson_r':correlation(x,y),'Spearman_rho':correlation(ranks(x),ranks(y)),'P_values_computed':False,'interpretation':'Descriptive within-model correlation, not causal regulation or independent validation.'})
    for fit in ['AUTHOR_MACROPHAGES__CHEM_IFN7','POOLED_AUTHOR_MACROPHAGES__CHEM_IFN7']:
        units=read_tsv(inp/'returned_server_06E'/('units_'+fit+'.tsv'))
        design=read_tsv(inp/'returned_server_06E'/('design_'+fit+'.tsv'))
        assert [r['unit_key'] for r in units]==[r['unit_key'] for r in design]
        vif,summary=design_diagnostics(design,fit)
        allvif.extend(vif);allsummary.append(summary)
        overlap.extend(summaries_and_overlap(units,fit))
    write_tsv(out/'Table_S30_IFN7_distribution_and_overlap8.tsv',overlap)
    write_tsv(out/'Table_S31_design_VIF_terms.tsv',allvif)
    write_tsv(out/'IFN7_design_summary4.tsv',allsummary)
    write_tsv(out/'Table_S32_IFN7_descriptive_correlations20.tsv',correlations)
    write_tsv(out/'IFN7_patient_plot_source250.tsv',plots)


def coverage(inp,out):
    quality, cross, summaries = [], [], []
    for compartment in ['AUTHOR_MACROPHAGES','POOLED_AUTHOR_MACROPHAGES']:
        units=read_tsv(inp/'external_counts'/('units_'+compartment+'.tsv'))
        ng,totals,detected=matrix_stats(inp/'external_counts'/('counts_'+compartment+'.mtx.gz'))
        assert ng==28923 and len(units)==len(totals)
        for j,u in enumerate(units):
            quality.append(dict(u,compartment=compartment,total_raw_counts=totals[j],detected_genes=detected[j],counts_per_cell=totals[j]/int(u['n_cells'])))
        chemistry=sorted(set(u['Chem'] for u in units))
        for chem in chemistry:
            for group in ['Heal','Infl']:
                selected=[u for u in units if u['Chem']==chem and u['Type']==group]
                cross.append({'compartment':compartment,'chemistry':chem,'group':group,'n_donors':len(selected),'n_cells':sum(int(u['n_cells']) for u in selected)})
        for group in ['Heal','Infl']:
            rs=[u for u in quality if u['compartment']==compartment and u['Type']==group]
            for key in ['n_cells','total_raw_counts','detected_genes','counts_per_cell']:
                v=[float(r[key]) for r in rs]
                summaries.append({'compartment':compartment,'group':group,'quantity':key,'n':len(v),'min':min(v),'q25':quantile(v,.25),'median':quantile(v,.5),'q75':quantile(v,.75),'max':max(v)})
    assert len(quality)==31
    write_tsv(out/'Table_S33_independent_donor_coverage31.tsv',quality)
    write_tsv(out/'Table_S34_independent_chemistry_group_counts.tsv',cross)
    write_tsv(out/'Independent_coverage_group_summary.tsv',summaries)


def source_comparison(inp,out):
    schema=json.loads((inp/'source/IBDverse_published_DGE_schema.json').read_text())
    assert len(schema)==3 and all(r['methods']==['mast::singlecell::glmer'] for r in schema)
    cfg=(inp/'source/original_case_control.yml').read_text()
    assert 'deseq::pseudobulk::glmGamPoi' in cfg
    rows=[
        {'analysis':'Original atlas MAST','unit':'Single cells with Sanger-sample random intercept','covariates':'Detected-gene count, disease, sex, public age bin, mitochondrial percentage','method':'MAST mixed hurdle model','numeric_candidate_outputs':'Available in the three audited CD-versus-healthy deposited outputs; Table S23','added_contribution_here':'Existing EXT1 association acknowledged; no first-discovery claim'},
        {'analysis':'Original atlas DESeq2','unit':'Pseudobulk by sanger_sample_id in pinned repository configuration','covariates':'Pinned configuration specifies detected-gene count, disease, sex and age_binned; paper gives a broader description','method':'DESeq2 1.42.1 reported in paper; deseq::pseudobulk::glmGamPoi configured in repository','numeric_candidate_outputs':'Not present in the three audited deposited CD-versus-healthy files; those contain MAST only. Gene-specific DESeq2 P/q were not recovered.','added_contribution_here':'Patient aggregation alone is not a novel feature; no invented source DESeq2 estimates'},
        {'analysis':'Current targeted reassessment','unit':'One pseudobulk per individual-state-model','covariates':'Original sex + public age decade + group; cohort, age-factor, cell-count, IFN7 and robust variants','method':'edgeR QL plus separate limma-voom uncertainty estimates','numeric_candidate_outputs':'All original and sensitivity transcriptomes retained; roster extraction and model diagnostics added','added_contribution_here':'Scope, conditional association, uncertainty and independent expression eligibility, within an exploratory design'}]
    write_tsv(out/'Table_S27_original_study_methods_comparison3.tsv',rows)
    status={'paper_doi':'10.1038/s41588-026-02634-7','paper_url':'https://pmc.ncbi.nlm.nih.gov/articles/PMC13364666/','original_paper_already_used_pseudobulk':True,'repository':'andersonlab/sc_ti_atlas','pinned_commit':'33711e15a3b673b1d2f4b75f8e60fb9f96c1802e','configuration_path':'configs/dge/params__TI-fr005-case-control.yml','configuration_git_blob_sha1':'93bfaf5858d4d9c9aed84b1dc8324f292bb391f2','audited_numeric_outputs':3,'audited_numeric_output_methods':['mast::singlecell::glmer'],'source_DESeq2_candidate_numeric_results_recovered':False,'missing_source_DESeq2_outputs_assigned_P1':False,'journal_Supplementary_Table4_workbook_retrieved':False,'scope':'Three deposited CD-versus-healthy outputs, their archive directory, original article methods and pinned source repository; not a claim that no DESeq2 output exists elsewhere.'}
    (out/'Original_DESeq2_availability_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')


def self_tests():
    assert max(abs(a-b) for a,b in zip(bh([.01,.04,.03,1]),[.04,.05333333333333334,.05333333333333334,1]))<1e-12
    assert ranks([3,1,1,4])==[3,1.5,1.5,4]
    assert abs(correlation([1,2,3],[2,4,6])-1)<1e-12
    assert quantile([1,2,3,4],.25)==1.75
    e=eig_symmetric([[1,.5],[.5,1]])
    assert max(abs(a-b) for a,b in zip(e,[.5,1.5]))<1e-12
    x=[1,2,3,4,5];y=[3+2*z for z in x]
    assert max(map(abs,residuals(y,[[1]*5,x])))<1e-12
    try:residuals(y,[[1]*5,x,[2*z for z in x]])
    except ValueError:pass
    else:raise AssertionError('Did not reject rank deficiency')
    return 7


def verify_inputs(inp):
    checks=[]
    manifest=read_tsv(inp/'INPUT_SHA256.tsv')
    for r in manifest:
        p=inp/r['path']
        assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'], 'Input changed: '+r['path']
        checks.append({'check':'input_SHA256','fit':r['path'],'passed':True,'maximum_absolute_difference':0,'n_genes':None})
    return checks


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-dir',type=Path,default=Path(__file__).resolve().parent/'inputs')
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=False)
    (args.out/'RUN_STATUS.txt').write_text('RUNNING\n')
    try:
        n=self_tests()
        print('SELF_TESTS',n,'SYNTHETIC_ONLY',flush=True)
        checks=verify_inputs(args.input_dir)
        checks.extend(extract_roster(args.input_dir,args.out))
        print('ROSTER_29_RECORDS_34_FITS_EXTRACTED',flush=True)
        ifn_diagnostics(args.input_dir,args.out)
        coverage(args.input_dir,args.out)
        source_comparison(args.input_dir,args.out)
        write_tsv(args.out/'06F_input_and_BH_checks.tsv',checks)
        status={'completed':True,'source_inputs_verified':len(checks)-34,'full_transcriptome_BH_checks':34,'roster_rows':986,'primary_unique_gene_method_rows':56,'independent_donor_compartment_rows':31,'new_RNA_count_models_fitted':False,'new_disease_P_values_computed':False,'targets_filters_compartments_changed':False,'synthetic_self_tests':n,'synthetic_tests_are_biological_evidence':False,'source_DESeq2_candidate_numbers_recovered':False}
        (args.out/'06F_completion.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
        (args.out/'RUN_STATUS.txt').write_text('COMPLETED\n')
        print('COMPLETED_06F',args.out,flush=True)
    except Exception as e:
        (args.out/'RUN_STATUS.txt').write_text('FAILED\n'+str(e)+'\n')
        raise


if __name__=='__main__':
    main()
