#!/usr/bin/env Rscript
options(stringsAsFactors=FALSE,warn=1)
args<-commandArgs(trailingOnly=TRUE)
if(length(args)!=2L)stop('Usage: Rscript 06N_analysis.R MODULE OUTPUT')
code<-normalizePath(args[1],mustWork=TRUE);out<-args[2]
dir.create(out,recursive=TRUE,showWarnings=FALSE)
for(pkg in c('Matrix','edgeR','limma','statmod'))if(!requireNamespace(pkg,quietly=TRUE))stop('Missing installed package: ',pkg)
TARGETS<-c('EXT1','JMY');GROUPS<-c('Healthy','CD_uninflamed','CD_inflamed')
read_tab<-function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE)
write_tab<-function(x,name){p<-file.path(out,name);dir.create(dirname(p),recursive=TRUE,showWarnings=FALSE);con<-if(grepl('\\.gz$',p))gzfile(p,'wt')else file(p,'wt');on.exit(try(close(con),silent=TRUE));write.table(x,con,sep='\t',quote=FALSE,row.names=FALSE,na='NA')}
logmsg<-function(...)cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),...,'\n')
main<-function(){
 genes<-read_tab(file.path(code,'inputs/genes.tsv'));u<-read_tab(file.path(code,'inputs/units_CD163hi.tsv'))
 con<-gzfile(file.path(code,'inputs/counts_CD163hi.mtx.gz'),'rt');m<-tryCatch(as(Matrix::readMM(con),'CsparseMatrix'),finally=try(close(con),silent=TRUE))
 stopifnot(nrow(m)==nrow(genes),ncol(m)==nrow(u),nrow(u)==200,!anyDuplicated(u$individual_id),!anyDuplicated(u$unit_key),!anyDuplicated(genes$gene_id),all(u$n_cells>=15),all(is.finite(m@x)),all(m@x>=0),all(m@x==floor(m@x)))
 stopifnot(identical(as.integer(table(factor(u$clinical_group,levels=GROUPS))),c(113L,37L,50L)))
 stopifnot(all(vapply(TARGETS,function(g)sum(genes$gene_symbol==g,na.rm=TRUE)==1L,logical(1))))
 rownames(m)<-genes$gene_id;colnames(m)<-u$unit_key
 fit_one<-function(index,model_id,age_factor=FALSE,robust=FALSE,voom=TRUE,full=FALSE){
  z<-u[index,,drop=FALSE];z$group<-factor(z$clinical_group,levels=GROUPS);z$sex<-factor(z$sex,levels=c('female','male'));z$cohort_factor<-factor(z$cohort,levels=c('Discovery','Replication'));z$age_decade<-z$age_binned_10/10
  if(age_factor){z$age_factor<-factor(z$age_binned_10,ordered=FALSE);form<-~sex+age_factor+cohort_factor+group}else form<-~sex+age_decade+cohort_factor+group
  X<-model.matrix(form,z);rownames(X)<-z$unit_key
  stopifnot(min(table(z$group))>=4L,qr(X)$rank==ncol(X),nrow(X)-ncol(X)>=2)
  y<-edgeR::DGEList(counts=m[,index,drop=FALSE]);keep<-edgeR::filterByExpr(y,group=z$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
  y<-edgeR::calcNormFactors(y[keep,,keep.lib.sizes=FALSE]);gm<-abs(mean(base::log(y$samples$norm.factors)));stopifnot(gm<1e-10)
  y<-edgeR::estimateDisp(y,design=X,robust=robust);qfit<-edgeR::glmQLFit(y,design=X,robust=robust)
  C<-matrix(0,ncol(X),3,dimnames=list(colnames(X),c('I_vs_H','U_vs_H','I_vs_U')))
  C['groupCD_inflamed',c('I_vs_H','I_vs_U')]<-1;C['groupCD_uninflamed','U_vs_H']<-1;C['groupCD_uninflamed','I_vs_U']<--1
  stopifnot(all(C[,'I_vs_H']-C[,'U_vs_H']==C[,'I_vs_U']))
  if(voom){vv<-limma::voom(y,design=X,plot=FALSE);vf<-limma::eBayes(limma::contrasts.fit(limma::lmFit(vv,X),C),robust=FALSE)}
  rows<-list();ng<-table(z$group)
  for(k in seq_len(ncol(C))){
   co<-colnames(C)[k]
   qq<-as.data.frame(edgeR::topTags(edgeR::glmQLFTest(qfit,contrast=C[,k]),n=Inf,sort.by='none')$table)
   if(voom)ww<-as.data.frame(limma::topTable(vf,coef=k,number=Inf,sort.by='none',confint=.95))
   for(be in c('edgeR_QL',if(voom)'limma_voom')){
    a<-if(be=='edgeR_QL')qq else ww
    a$gene_id<-rownames(a);a$gene_symbol<-genes$gene_symbol[match(a$gene_id,genes$gene_id)]
    a$PValue<-if(be=='edgeR_QL')a$PValue else a$P.Value;a$genome_q<-p.adjust(a$PValue,'BH')
    a$CI95_low<-if(be=='edgeR_QL')NA_real_ else a$CI.L;a$CI95_high<-if(be=='edgeR_QL')NA_real_ else a$CI.R
    stopifnot(all(is.finite(a$PValue)),all(is.finite(a$logFC)),all(a$PValue>=0&a$PValue<=1))
    ix<-match(TARGETS,a$gene_symbol)
    r<-data.frame(model_id=model_id,contrast=co,backend=be,gene_symbol=TARGETS,log2FC=a$logFC[ix],CI95_low=a$CI95_low[ix],CI95_high=a$CI95_high[ix],PValue=a$PValue[ix],genome_q=a$genome_q[ix],n_tested_genes=nrow(a),n_total=nrow(X),design_rank=ncol(X),residual_df=nrow(X)-ncol(X),status=ifelse(is.na(ix),'not_tested_expression_filter','tested'),n_case=as.integer(ng[if(co=='U_vs_H')'CD_uninflamed'else'CD_inflamed']),n_reference=as.integer(ng[if(co=='I_vs_U')'CD_uninflamed'else'Healthy']))
    rows[[length(rows)+1L]]<-r
    if(full)write_tab(a,paste0('full_transcriptome/ALL_genes_',model_id,'_',co,'_',be,'.tsv.gz'))
   }
  }
  r<-do.call(rbind,rows);r$q_exploratory_target6<-NA_real_
  for(be in unique(r$backend)){j<-which(r$backend==be);p<-r$PValue[j];q<-p.adjust(ifelse(is.finite(p),p,1),'BH');q[!is.finite(p)]<-NA_real_;r$q_exploratory_target6[j]<-q}
  diag<-data.frame(model_id=model_id,n_total=nrow(X),n_genes=nrow(y),design_rank=ncol(X),residual_df=nrow(X)-ncol(X),n_H=as.integer(ng['Healthy']),n_U=as.integer(ng['CD_uninflamed']),n_I=as.integer(ng['CD_inflamed']),TMM_log_geometric_mean_abs=gm,max_leverage=max(rowSums(qr.Q(qr(X))^2)),formula=paste(deparse(form),collapse=''))
  method<-data.frame(model_id=model_id,all_tests_finite=TRUE,QL_robust=robust,voom_fitted=voom,TMM_positive=all(y$samples$norm.factors>0),filtered_libraries_recomputed=TRUE,filter_repeated_from_all_input_genes=TRUE,n_input_genes=nrow(m))
  list(rows=r,diagnostic=diag,method=method)
 }
 logmsg('START_06N_RECOVERY_REEXECUTION','workers',Sys.getenv('BMC_WORKERS','8'))
 baseline<-fit_one(seq_len(nrow(u)),'JOINT_BASELINE',full=TRUE)
 expected<-read_tab(file.path(code,'inputs/expected_joint_candidates12.tsv'));checks<-list()
 for(i in seq_len(nrow(expected))){e<-expected[i,,drop=FALSE];z<-baseline$rows[baseline$rows$contrast==e$contrast&baseline$rows$backend==e$backend&baseline$rows$gene_symbol==e$gene_symbol,,drop=FALSE];stopifnot(nrow(z)==1)
  for(field in c('log2FC','PValue','genome_q','CI95_low','CI95_high','n_tested_genes')){delta<-if(is.na(e[[field]])&&is.na(z[[field]]))0 else abs(e[[field]]-z[[field]]);tol<-if(field=='n_tested_genes')0 else 1e-7;pass<-is.finite(delta)&&delta<=tol;checks[[length(checks)+1L]]<-data.frame(contrast=e$contrast,backend=e$backend,gene_symbol=e$gene_symbol,field=field,expected=e[[field]],observed=z[[field]],absolute_difference=delta,tolerance=tol,passed=pass)}}
 audit<-do.call(rbind,checks);write_tab(audit,'joint_baseline_reproduction72.tsv');stopifnot(nrow(audit)==72,all(audit$passed));logmsg('FROZEN_BASELINE_72_REPRODUCED','maximum difference',max(audit$absolute_difference))
 variants<-list(JOINT_BASELINE=baseline,AGE_FACTOR=fit_one(seq_len(nrow(u)),'AGE_FACTOR',age_factor=TRUE,full=TRUE),ROBUST_QL=fit_one(seq_len(nrow(u)),'ROBUST_QL',robust=TRUE,voom=FALSE,full=TRUE),MIN30=fit_one(which(u$n_cells>=30),'MIN30',full=TRUE),MIN50=fit_one(which(u$n_cells>=50),'MIN50',full=TRUE))
 vr<-do.call(rbind,lapply(variants,'[[','rows'));stopifnot(nrow(vr)==54);write_tab(vr,'joint_variant_candidate_results54.tsv');write_tab(do.call(rbind,lapply(variants,'[[','diagnostic')),'joint_model_diagnostics.tsv');write_tab(do.call(rbind,lapply(variants,'[[','method')),'joint_variant_method_audit.tsv')
 composition<-list()
 for(model in names(variants)){
  index<-if(model=='MIN30')which(u$n_cells>=30)else if(model=='MIN50')which(u$n_cells>=50)else seq_len(nrow(u))
  for(g in GROUPS){z<-u[index,,drop=FALSE];z<-z[z$clinical_group==g,,drop=FALSE];ages<-table(factor(z$age_binned_10,levels=sort(unique(u$age_binned_10))));composition[[length(composition)+1L]]<-data.frame(model_id=model,clinical_group=g,n_donors=nrow(z),n_in_original_200=sum(u$clinical_group==g),retained_fraction=nrow(z)/sum(u$clinical_group==g),female_count=sum(z$sex=='female'),female_fraction=mean(z$sex=='female'),replication_count=sum(z$cohort=='Replication'),replication_fraction=mean(z$cohort=='Replication'),age_median=median(z$age_binned_10),age_Q1=unname(quantile(z$age_binned_10,.25)),age_Q3=unname(quantile(z$age_binned_10,.75)),age_bin_counts=paste(names(ages),as.integer(ages),sep=':',collapse=';'),cell_count_median=median(z$n_cells))}
 }
 write_tab(do.call(rbind,composition),'joint_population_composition15.tsv');logmsg('ALL_54_VARIANT_ROWS_COMPLETED')
 checkpoint<-file.path(out,'loo_checkpoint');dir.create(checkpoint,showWarnings=FALSE)
 one_delete<-function(i){
  file<-file.path(checkpoint,sprintf('donor_%03d.rds',i))
  if(file.exists(file))return(readRDS(file))
  ans<-tryCatch(fit_one(setdiff(seq_len(nrow(u)),i),paste0('DELETE_DONOR_',sprintf('%03d',i))),error=function(e){stop(paste('Deletion',i,'failed:',conditionMessage(e)))})
  ans$rows$omitted_index<-i;ans$rows$omitted_individual_id<-u$individual_id[i];ans$rows$omitted_clinical_group<-u$clinical_group[i]
  ans$diagnostic$omitted_index<-i;ans$diagnostic$omitted_individual_id<-u$individual_id[i];ans$diagnostic$omitted_clinical_group<-u$clinical_group[i]
  ans$method$omitted_index<-i
  saveRDS(ans,file);logmsg('DONOR_DELETION_COMPLETED',i);ans
 }
 workers<-max(1L,min(16L,as.integer(Sys.getenv('BMC_WORKERS','8'))))
 deletions<-parallel::mclapply(seq_len(nrow(u)),one_delete,mc.cores=workers,mc.preschedule=TRUE)
 stopifnot(!any(vapply(deletions,inherits,logical(1),'try-error')))
 dr<-do.call(rbind,lapply(deletions,'[[','rows'));dd<-do.call(rbind,lapply(deletions,'[[','diagnostic'));dm<-do.call(rbind,lapply(deletions,'[[','method'))
 stopifnot(nrow(dr)==2400,nrow(dd)==200,nrow(dm)==200,!anyDuplicated(paste(dr$omitted_index,dr$contrast,dr$backend,dr$gene_symbol)))
 write_tab(dr,'joint_leave_one_out_candidates2400.tsv');write_tab(dd,'joint_leave_one_out_design_audit200.tsv');write_tab(dm,'joint_leave_one_out_method_audit200.tsv');write_tab(merge(dd,dm,by=c('model_id','omitted_index'),sort=FALSE),'joint_leave_one_out_design_method_audit200.tsv')
 ss<-list()
 for(co in c('I_vs_H','U_vs_H','I_vs_U'))for(be in c('edgeR_QL','limma_voom'))for(g in TARGETS){
  z<-dr[dr$contrast==co&dr$backend==be&dr$gene_symbol==g,,drop=FALSE];b<-baseline$rows[baseline$rows$contrast==co&baseline$rows$backend==be&baseline$rows$gene_symbol==g,,drop=FALSE];stopifnot(nrow(z)==200,nrow(b)==1)
  ss[[length(ss)+1L]]<-data.frame(contrast=co,backend=be,gene_symbol=g,n_planned=200,n_tested=sum(z$status=='tested'),n_unavailable=sum(z$status!='tested'),baseline_log2FC=b$log2FC,baseline_genome_q=b$genome_q,log2FC_min=min(z$log2FC,na.rm=TRUE),log2FC_max=max(z$log2FC,na.rm=TRUE),genome_q_min=min(z$genome_q,na.rm=TRUE),genome_q_max=max(z$genome_q,na.rm=TRUE),same_sign_as_baseline=sum(sign(z$log2FC)==sign(b$log2FC),na.rm=TRUE),q_below_005=sum(z$genome_q<.05,na.rm=TRUE),n_genes_min=min(z$n_tested_genes),n_genes_max=max(z$n_tested_genes),rank_min=min(z$design_rank),residual_df_min=min(z$residual_df))
 }
 write_tab(do.call(rbind,ss),'joint_leave_one_out_summary12.tsv')
 logmsg('COMPLETED_06N',nrow(vr),'variant rows;',nrow(dr),'deletion rows');writeLines('COMPLETED',file.path(out,'RUN_STATUS.txt'))
}
tryCatch({main();capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))},error=function(e){capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'));writeLines(conditionMessage(e),file.path(out,'RUN_FAILED.txt'));logmsg('FAILED_06N',conditionMessage(e));quit(status=1)})
