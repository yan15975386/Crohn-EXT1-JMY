#!/usr/bin/env python3
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,zipfile
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        while c:=f.read(1024*1024):h.update(c)
    return h.hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--module',default=str(Path(__file__).resolve().parent));p.add_argument('--rscript',default=os.environ.get('RSCRIPT','Rscript'));p.add_argument('--workers',type=int,default=int(os.environ.get('BMC_WORKERS','4')));a=p.parse_args()
    mod=Path(a.module).resolve();out=Path(a.out).resolve()
    if out.exists() and any(out.iterdir()):raise RuntimeError('Choose a new empty output directory')
    out.mkdir(parents=True,exist_ok=True);rc=1
    try:
        plan=mod/'FROZEN_06N_PLAN.json';assert sha(plan)==(mod/'FROZEN_06N_PLAN.sha256').read_text().strip(),'Frozen plan identity mismatch'
        for item in json.loads(plan.read_text())['source_identity']:
            f=mod/item['path'];assert f.stat().st_size==item['bytes'] and sha(f)==item['sha256'],'Input identity mismatch: '+item['path']
        rscript=shutil.which(a.rscript)
        if not rscript:raise RuntimeError('Rscript unavailable; set RSCRIPT to an existing installation with Matrix, edgeR, limma and statmod')
        env=os.environ.copy();env.update({'BMC_WORKERS':str(max(1,min(16,a.workers))),'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
        (out/'execution_identity.json').write_text(json.dumps({'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':sha(plan),'analysis_script_sha256':sha(mod/'06N_analysis.R'),'source_hashes_verified':True,'workers':int(env['BMC_WORKERS']),'Rscript':rscript},indent=2))
        print('SOURCE_HASHES_VERIFIED',flush=True)
        rc=subprocess.run([rscript,'--vanilla',str(mod/'06N_analysis.R'),str(mod),str(out)],env=env).returncode
    except Exception as e:
        (out/'RUN_FAILED.txt').write_text(str(e)+'\n');print('FAILED_06N_DRIVER '+str(e),file=sys.stderr,flush=True)
    completed=rc==0 and (out/'RUN_STATUS.txt').exists() and (out/'RUN_STATUS.txt').read_text().strip()=='COMPLETED'
    archive=out.parent/('CD_06N_'+('COMPLETE' if completed else 'PARTIAL')+'_'+out.name+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(out.rglob('*')):
            if f.is_file():z.write(f,Path(out.name)/f.relative_to(out))
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None
    print('RETURN_ZIP='+str(archive),flush=True);print('EXIT_CODE='+str(rc),flush=True)
    return rc
if __name__=='__main__':sys.exit(main())
