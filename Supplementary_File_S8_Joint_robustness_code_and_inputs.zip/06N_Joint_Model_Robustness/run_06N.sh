#!/usr/bin/env bash
set -eu
bmc_module=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "${PYTHON:-python3}" "$bmc_module/run_driver.py" --module "$bmc_module" --out "$1"
