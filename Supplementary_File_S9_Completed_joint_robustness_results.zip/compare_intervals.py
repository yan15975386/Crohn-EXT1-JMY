from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
R=Path(__file__).resolve().parent;T=R/'tables/Frozen_TSV';O=R/'06N_completed_results'
def read(prefix):return pd.read_csv(next(T.glob(prefix+'*.tsv')),sep='\t')
a,b,c=read('Table_S69_'),read('Table_S24_'),read('Table_S76_')
rows=[]
for study,comp,df in [('IBDverse','CD163-hi',a.loc[a.contrast.eq('I_vs_H')]),('Kong','AUTHOR_MACROPHAGES',b.loc[b.model_id.eq('AUTHOR_MACROPHAGES__CHEM')]),('Kong','POOLED_AUTHOR_MACROPHAGES',b.loc[b.model_id.eq('POOLED_AUTHOR_MACROPHAGES__CHEM')]),('Zheng','STRICT_MAC',c.loc[c.compartment.eq('STRICT_MAC')&c.model_id.eq('CLINICAL')])]:
    for gene in ['EXT1','JMY']:
        z=df.loc[df.backend.eq('limma_voom')&df.gene_symbol.eq(gene)];assert len(z)==1;z=z.iloc[0]
        source=a.loc[a.contrast.eq('I_vs_H')&a.backend.eq('limma_voom')&a.gene_symbol.eq(gene)].iloc[0]
        tested=z.status=='tested'
        row={'study':study,'compartment':comp,'contrast':z.contrast,'backend':'limma_voom','gene_symbol':gene,'status':z.status,'log2FC':z.log2FC,'CI95_low':z.CI95_low,'CI95_high':z.CI95_high,'PValue':z.PValue,'genome_q':z.genome_q,'fold_ratio':2**z.log2FC if tested else np.nan,'ratio_CI95_low':2**z.CI95_low if tested else np.nan,'ratio_CI95_high':2**z.CI95_high if tested else np.nan,'CI_contains_null':bool(z.CI95_low<=0<=z.CI95_high) if tested else None,'source_point_log2FC':source.log2FC,'source_point_in_interval':bool(z.CI95_low<=source.log2FC<=z.CI95_high) if tested else None,'source_interval_overlap':bool(max(z.CI95_low,source.CI95_low)<=min(z.CI95_high,source.CI95_high)) if tested else None,'interval_method':'own voom nominal moderated-t 95% interval','pooling_or_heterogeneity_test':'none'}
        rows.append(row)
out=pd.DataFrame(rows);assert len(out)==8
out.to_csv(O/'cross_study_interval_comparison8.tsv',sep='\t',index=False,na_rep='NA',float_format='%.17g')
print(out.loc[out.gene_symbol.eq('JMY'),['study','compartment','status','fold_ratio','ratio_CI95_low','ratio_CI95_high']].to_string(index=False),flush=True)
