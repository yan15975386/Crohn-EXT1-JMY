from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
R=Path(__file__).resolve().parent;M=R/'06N_Joint_Model_Robustness';D=R/'06N_completed_results';checks=[]
assert (D/'RUN_STATUS.txt').read_text().strip()=='COMPLETED'
def test(name,passed,detail=None):
    checks.append({'check':name,'passed':bool(passed),'detail':detail})
    if not passed:raise AssertionError(name+': '+str(detail))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bh(p):
    p=np.asarray(p,dtype=float);order=np.argsort(p,kind='stable');q=np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];z=np.empty(len(p));z[order]=np.minimum(q,1);return z
plan=json.loads((M/'FROZEN_06N_PLAN.json').read_text())
test('input_sha256',all(sha(M/i['path'])==i['sha256'] and (M/i['path']).stat().st_size==i['bytes'] for i in plan['source_identity']))
test('plan_sha256',sha(M/'FROZEN_06N_PLAN.json')==(M/'FROZEN_06N_PLAN.sha256').read_text().strip())
b=pd.read_csv(D/'joint_baseline_reproduction72.tsv',sep='\t');test('baseline_72_fields',len(b)==72 and b.passed.all() and (b.absolute_difference<=b.tolerance).all())
v=pd.read_csv(D/'joint_variant_candidate_results54.tsv',sep='\t');test('variant_54_unique_rows',len(v)==54 and not v.duplicated(['model_id','contrast','backend','gene_symbol']).any() and v.status.eq('tested').all())
files=sorted((D/'full_transcriptome').glob('*.tsv.gz'));assert len(files)==27
for p in files:
    t=pd.read_csv(p,sep='\t');test('BH_'+p.stem,np.allclose(bh(t.PValue),t.genome_q,atol=5e-13,rtol=5e-13))
    stem=p.name.removeprefix('ALL_genes_').removesuffix('.tsv.gz');found=[]
    for (model,contrast,backend),z in v.groupby(['model_id','contrast','backend']):
        if stem==model+'_'+contrast+'_'+backend:
            for _,row in z.iterrows():
                tt=t.loc[t.gene_symbol.eq(row.gene_symbol)];assert len(tt)==1;tt=tt.iloc[0]
                found.append(all(np.isclose(row[k],tt[f],equal_nan=True,atol=5e-13,rtol=5e-13) for k,f in [('log2FC','logFC'),('PValue','PValue'),('genome_q','genome_q'),('CI95_low','CI95_low'),('CI95_high','CI95_high')]) and row.n_tested_genes==len(t))
    test('candidate_alignment_'+p.stem,len(found)==2 and all(found))
d=pd.read_csv(D/'joint_leave_one_out_candidates2400.tsv',sep='\t');s=pd.read_csv(D/'joint_leave_one_out_summary12.tsv',sep='\t')
test('all_2400_deletion_rows',len(d)==2400 and not d.duplicated(['omitted_index','contrast','backend','gene_symbol']).any() and d.status.eq('tested').all())
test('all_200_donors_deleted',set(d.omitted_index)==set(range(1,201)))
valid=[]
for _,row in s.iterrows():
    z=d.loc[d.contrast.eq(row.contrast)&d.backend.eq(row.backend)&d.gene_symbol.eq(row.gene_symbol)]
    bb=v.loc[v.model_id.eq('JOINT_BASELINE')&v.contrast.eq(row.contrast)&v.backend.eq(row.backend)&v.gene_symbol.eq(row.gene_symbol)].iloc[0]
    nums={'log2FC_min':z.log2FC.min(),'log2FC_max':z.log2FC.max(),'genome_q_min':z.genome_q.min(),'genome_q_max':z.genome_q.max(),'same_sign_as_baseline':(np.sign(z.log2FC)==np.sign(bb.log2FC)).sum(),'q_below_005':z.genome_q.lt(.05).sum(),'n_genes_min':z.n_tested_genes.min(),'n_genes_max':z.n_tested_genes.max()}
    valid.append(len(z)==200 and all(np.isclose(row[k],x,atol=5e-13,rtol=5e-13) for k,x in nums.items()))
test('all_12_deletion_summaries',len(s)==12 and all(valid))
u=pd.read_csv(M/'inputs/units_CD163hi.tsv',sep='\t');comp=pd.read_csv(D/'joint_population_composition15.tsv',sep='\t');valid=[]
for _,row in comp.iterrows():
    z=u.loc[u.clinical_group.eq(row.clinical_group)];threshold=30 if row.model_id=='MIN30' else 50 if row.model_id=='MIN50' else 15;zz=z.loc[z.n_cells>=threshold]
    valid.append(len(zz)==row.n_donors and np.isclose((zz.sex=='female').mean(),row.female_fraction) and np.isclose((zz.cohort=='Replication').mean(),row.replication_fraction))
test('population_composition_15_rows',len(comp)==15 and all(valid))
assert len(checks)==62
report={'all_passed':all(x['passed'] for x in checks),'number_of_checks':len(checks),'recovery_reexecution':True,'checks':checks}
(D/'independent_python_verification.json').write_text(json.dumps(report,indent=2))
print('ALL_62_INDEPENDENT_CHECKS_PASSED',flush=True)
