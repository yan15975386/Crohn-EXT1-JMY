#!/usr/bin/env Rscript
# Frozen reviewer follow-up. Public inputs are bundled; no installation or downloads.
options(stringsAsFactors=FALSE,warn=1,contrasts=c('contr.treatment','contr.poly'))
argv<-commandArgs(trailingOnly=TRUE)
self<-normalizePath(sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),mustWork=TRUE)
code<-dirname(self)
TARGETS<-c('EXT1','JMY');IFN7<-c('STAT1','IRF1','ISG15','MX2','GBP1','GBP2','GBP5')
BACKENDS<-c('edgeR_QL','limma_voom')
VARIANTS<-c('COHORT','IFN7','TNFR1_NFKB','HYPOXIA','IFN7_TNFR1_NFKB','IFN7_HYPOXIA')
IMPORTS<-c('rd','wt','strict_bool','read_counts','fit_one')
found<-character()
for(term in parse(file.path(code,'frozen','06I_analysis_executed.R'))){
  if(is.call(term)&&identical(term[[1L]],as.name('<-'))&&is.symbol(term[[2L]])){
    name<-as.character(term[[2L]])
    if(name%in%IMPORTS){
      if(!is.call(term[[3L]])||!identical(term[[3L]][[1L]],as.name('function')))stop('Invalid frozen function import')
      eval(term,envir=.GlobalEnv);found<-c(found,name)
    }
  }
}
stopifnot(setequal(found,IMPORTS),!anyDuplicated(found))
log_msg<-function(...)cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),paste(...,collapse=' '),'\n')
information<-function(X,index,weights=rep(1,nrow(X))){
  stopifnot(length(weights)==nrow(X),all(is.finite(weights)),all(weights>0))
  Xw<-X*sqrt(weights);nuisance<-Xw[,-index,drop=FALSE]
  residual<-qr.resid(qr(nuisance),Xw[,index]);total<-sum(residual^2)
  if(!is.finite(total)||total<1e-12)stop('Disease contrast has no residual information')
  list(residual=residual,fraction=residual^2/total,leverage=rowSums(qr.Q(qr(Xw))^2))
}
self_tests<-function(){
  stopifnot(identical(strict_bool(c('False','TRUE',' true ')),c(FALSE,TRUE,TRUE)))
  f<-matrix(c(1,1,1,1,0,0,1,1),ncol=2);a<-information(f,2)
  stopifnot(abs(sum(a$fraction)-1)<1e-12,max(abs(a$fraction-.25))<1e-12)
  p<-c(.01,.04,1,1);stopifnot(max(abs(p.adjust(p,'BH')-c(.04,.08,1,1)))<1e-12)
  b<-c(.1,-.2);c<-c(-.1,-.1)
  stopifnot(max(abs(c-b-c(-.2,.1)))<1e-12,max(abs(abs(b)-abs(c)-c(0,.1)))<1e-12)
  log_msg('R_SELF_TESTS_PASSED','synthetic logic only')
}
if(identical(argv,'--self-test')){self_tests();quit(status=0)}
if(length(argv)!=1L)stop('Usage: Rscript 06J_analysis.R OUTPUT_DIRECTORY')
out<-normalizePath(argv[1],mustWork=TRUE)
workers<-as.integer(Sys.getenv('CD06J_WORKERS','4'))
if(is.na(workers)||workers<1L||workers>16L)stop('CD06J_WORKERS must be 1..16')

check_full<-function(current,expected,key){
  if(nrow(current)!=nrow(expected)||anyDuplicated(current$gene_id)||!setequal(current$gene_id,expected$gene_id))stop('Baseline gene universe differs: ',key)
  a<-current[match(expected$gene_id,current$gene_id),,drop=FALSE];rows<-list()
  for(field in c('logFC','PValue','genome_q','CI95_low','CI95_high')){
    x<-a[[field]];y<-expected[[field]];finite<-is.finite(x)&is.finite(y)
    difference<-if(any(finite))max(abs(x[finite]-y[finite]))else NA_real_
    pass<-identical(is.na(x),is.na(y))&&!any(is.infinite(x))&&(is.na(difference)||difference<1e-7)
    rows[[field]]<-data.frame(key=key,field=field,n_genes=nrow(expected),difference=difference,passed=pass)
  }
  do.call(rbind,rows)
}
make_main<-function(m,u,keep,sets){
  y<-edgeR::DGEList(m[keep,,drop=FALSE])
  if(any(colSums(y$counts)<=0)||any(rowSums(y$counts)<=0))stop('Zero count row/library in fixed main universe')
  y<-edgeR::calcNormFactors(y);lib<-y$samples$lib.size*y$samples$norm.factors
  for(name in names(sets)){
    score<-colMeans(log2(1+sweep(as.matrix(m[sets[[name]],,drop=FALSE]),2,lib/1e6,'/')))
    if(!is.finite(sd(score))||sd(score)<=0)stop('Score has no variation: ',name)
    u[[name]]<-as.numeric(scale(score))
  }
  formulas<-list(COHORT=~sex+age_decade+cohort_factor+group,
    IFN7=~sex+age_decade+cohort_factor+IFN7+group,
    TNFR1_NFKB=~sex+age_decade+cohort_factor+TNFR1_NFKB+group,
    HYPOXIA=~sex+age_decade+cohort_factor+HYPOXIA+group,
    IFN7_TNFR1_NFKB=~sex+age_decade+cohort_factor+IFN7+TNFR1_NFKB+group,
    IFN7_HYPOXIA=~sex+age_decade+cohort_factor+IFN7+HYPOXIA+group)
  designs<-lapply(formulas,function(f){X<-model.matrix(f,u);rownames(X)<-colnames(m);X})
  for(X in designs)if(qr(X)$rank!=ncol(X)||nrow(X)-ncol(X)<2L)stop('Unavailable main design')
  list(y=y,units=u,designs=designs)
}
target_coef<-function(fits,variant){
  rows<-list()
  for(method in BACKENDS)for(g in TARGETS){
    z<-fits[[method]];id<-main_genes$gene_id[main_genes$gene_symbol==g]
    j<-match(id,z$gene_id)
    if(length(j)!=1L||is.na(j)||!is.finite(z$logFC[j]))stop('Target unavailable: ',variant,' ',method,' ',g)
    rows[[paste(method,g)]]<-data.frame(variant=variant,backend=method,gene_symbol=g,log2FC=z$logFC[j])
  }
  do.call(rbind,rows)
}
comparisons<-data.frame(from=c('COHORT','COHORT','TNFR1_NFKB','HYPOXIA','TNFR1_NFKB','HYPOXIA'),
  to=c('TNFR1_NFKB','HYPOXIA','IFN7','IFN7','IFN7_TNFR1_NFKB','IFN7_HYPOXIA'))
paired_changes<-function(x){
  result<-list()
  for(i in seq_len(nrow(comparisons)))for(method in BACKENDS)for(g in TARGETS){
    a<-x$log2FC[x$variant==comparisons$from[i]&x$backend==method&x$gene_symbol==g]
    b<-x$log2FC[x$variant==comparisons$to[i]&x$backend==method&x$gene_symbol==g]
    stopifnot(length(a)==1L,length(b)==1L,is.finite(a),is.finite(b))
    key<-paste(comparisons$from[i],comparisons$to[i],method,g)
    result[[key]]<-data.frame(comparison=paste(comparisons$from[i],comparisons$to[i],sep='_to_'),backend=method,gene_symbol=g,
      from_log2FC=a,to_log2FC=b,delta_signed=b-a,absolute_reduction=abs(a)-abs(b))
  }
  do.call(rbind,result)
}
main_analysis<-function(){
  main_genes<<-rd(file.path(code,'inputs','main','genes.tsv'));units<-rd(file.path(code,'inputs','main','units_CD163hi.tsv'))
  stopifnot(!anyDuplicated(units$individual_id))
  counts<-read_counts(file.path(code,'inputs','main','counts_CD163hi.mtx.gz'),main_genes,units)
  u<-units[units$clinical_group%in%c('Healthy','CD_inflamed')&units$n_cells>=15L,,drop=FALSE]
  stopifnot(nrow(u)==163L,sum(u$clinical_group=='CD_inflamed')==50L,sum(u$clinical_group=='Healthy')==113L)
  u$group<-factor(u$clinical_group,levels=c('Healthy','CD_inflamed'));u$sex<-factor(u$sex,levels=c('female','male'))
  u$age_decade<-u$age_binned_10/10;u$cohort_factor<-factor(u$cohort,levels=c('Discovery','Replication'))
  m<-counts[,match(u$unit_key,colnames(counts)),drop=FALSE];rm(counts)
  keep<-edgeR::filterByExpr(edgeR::DGEList(m),group=u$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
  oldkeep<-rd(file.path(code,'reference_06I','main_fixed_gene_universe.tsv.gz'))
  stopifnot(sum(keep)==8335L,identical(main_genes$gene_id,oldkeep$gene_id),identical(as.logical(keep),strict_bool(oldkeep$original_filter_passed)))
  membership<-rd(file.path(code,'inputs','fixed_score_members.tsv'))
  sets<-list(IFN7=match(IFN7,main_genes$gene_symbol))
  for(name in c('TNFR1_NFKB','HYPOXIA')){
    requested<-membership$gene_symbol[membership$score==name];j<-match(requested,main_genes$gene_symbol)
    if(anyNA(j)||anyDuplicated(j)||any(vapply(requested,function(g)sum(main_genes$gene_symbol==g)!=1L,logical(1)))||any(requested%in%TARGETS)||length(intersect(requested,IFN7)))stop('Frozen control membership differs')
    sets[[name]]<-j
  }
  p<-make_main(m,u,keep,sets);fits<-list();checks<-list();ledger<-list();vifs<-list()
  for(variant in VARIANTS){
    log_msg('MAIN_MODEL',variant);X<-p$designs[[variant]]
    f<-fit_one(p$y,X,main_genes,TRUE);fits[[variant]]<-f
    wt(data.frame(unit_key=rownames(X),X,check.names=FALSE),file.path(out,paste0('design_main_',variant,'.tsv')))
    for(method in BACKENDS){
      z<-f[[method]];wt(z,file.path(out,paste0('ALL_genes_main_',variant,'_',method,'.tsv.gz')))
      if(variant%in%c('COHORT','IFN7')){
        e<-rd(file.path(code,'reference_main',paste0('ALL_genes_',variant,'_A_vs_H_',method,'.tsv.gz')))
        checks[[paste(variant,method)]]<-check_full(z,e,paste(variant,method))
        wt(do.call(rbind,checks),file.path(out,'main_baseline_checks20.tsv'))
        if(!all(do.call(rbind,checks)$passed))stop('Main baseline did not reproduce; control interpretation stopped')
      }
      for(g in TARGETS){
        j<-which(z$gene_symbol==g);stopifnot(length(j)==1L)
        ledger[[paste(variant,method,g)]]<-data.frame(variant=variant,backend=method,gene_symbol=g,log2FC=z$logFC[j],CI95_low=z$CI95_low[j],CI95_high=z$CI95_high[j],PValue=z$PValue[j],genome_q=z$genome_q[j],status='tested',n_donors=163L,n_genes=8335L)
      }
    }
    for(j in 2:ncol(X)){
      res<-qr.resid(qr(X[,-j,drop=FALSE]),X[,j]);vifs[[paste(variant,j)]]<-data.frame(variant=variant,term=colnames(X)[j],VIF=sum((X[,j]-mean(X[,j]))^2)/sum(res^2))
    }
  }
  stopifnot(nrow(do.call(rbind,checks))==20L)
  ledger<-do.call(rbind,ledger);ledger$q_new_controls16<-NA_real_;new<-!ledger$variant%in%c('COHORT','IFN7')
  stopifnot(sum(new)==16L);ledger$q_new_controls16[new]<-p.adjust(ledger$PValue[new],'BH')
  wt(ledger,file.path(out,'main_candidate_rows24.tsv'));wt(do.call(rbind,vifs),file.path(out,'main_design_VIF.tsv'))
  wt(p$units,file.path(out,'main_scores163.tsv'))
  correlations<-cor(p$units[,c('IFN7','TNFR1_NFKB','HYPOXIA')])
  wt(data.frame(score=rownames(correlations),correlations,check.names=FALSE),file.path(out,'score_correlations3.tsv'))
  point<-paired_changes(do.call(rbind,lapply(names(fits),function(name)target_coef(fits[[name]],name))))
  wt(point,file.path(out,'main_paired_point_changes24.tsv'))
  draws<-rd(file.path(code,'reference_06I','bootstrap_draws.tsv.gz'));previous<-rd(file.path(code,'reference_06I','bootstrap_paired_effects_all.tsv.gz'))
  stopifnot(nrow(draws)==163000L,nrow(previous)==4000L,identical(sort(unique(draws$replicate)),seq_len(1000L)))
  checkdir<-file.path(out,'main_bootstrap_checkpoints');dir.create(checkdir,showWarnings=FALSE)
  one<-function(i){
    path<-file.path(checkdir,sprintf('replicate_%05d.rds',i));if(file.exists(path))return(readRDS(path))
    d<-draws[draws$replicate==i,,drop=FALSE];d<-d[order(d$draw_position),,drop=FALSE]
    j<-match(d$source_unit_key,u$unit_key);stopifnot(nrow(d)==163L,!anyNA(j),identical(as.character(u$group[j]),d$group),identical(as.character(u$cohort_factor[j]),d$cohort))
    result<-tryCatch({
      bu<-u[j,,drop=FALSE];bm<-m[,j,drop=FALSE];colnames(bm)<-paste0('draw_',seq_len(ncol(bm)))
      pp<-make_main(bm,bu,keep,sets);est<-list()
      # Reuse the exact completed baseline coefficients from the same 06I draw.
      old<-previous[previous$replicate==i,,drop=FALSE];stopifnot(nrow(old)==4L)
      for(name in c('COHORT','IFN7'))est[[name]]<-data.frame(variant=name,backend=old$backend,gene_symbol=old$gene_symbol,log2FC=if(name=='COHORT')old$cohort_log2FC else old$IFN7_log2FC)
      if(i%in%c(1L,250L,500L,1000L))for(name in c('COHORT','IFN7')){
        actual<-target_coef(fit_one(pp$y,pp$designs[[name]],main_genes,FALSE),name)
        k<-match(paste(actual$backend,actual$gene_symbol),paste(est[[name]]$backend,est[[name]]$gene_symbol))
        if(anyNA(k)||max(abs(actual$log2FC-est[[name]]$log2FC[k]))>1e-7)stop('Reused draw baseline did not reproduce')
        wt(data.frame(replicate=i,actual,expected_log2FC=est[[name]]$log2FC[k],difference=actual$log2FC-est[[name]]$log2FC[k]),file.path(checkdir,paste0('baseline_recheck_',i,'_',name,'.tsv')))
      }
      for(name in setdiff(VARIANTS,c('COHORT','IFN7')))est[[name]]<-target_coef(fit_one(pp$y,pp$designs[[name]],main_genes,FALSE),name)
      rows<-paired_changes(do.call(rbind,est));rows$replicate<-i
      list(replicate=i,status='SUCCESS',message='',rows=rows)
    },error=function(e)list(replicate=i,status='UNAVAILABLE',message=conditionMessage(e),rows=NULL))
    tmp<-paste0(path,'.tmp_',Sys.getpid());saveRDS(result,tmp);if(!file.rename(tmp,path))stop('Checkpoint save failed');result
  }
  results<-vector('list',1000L);batch<-workers*5L
  for(start in seq.int(1L,1000L,by=batch)){
    ids<-seq.int(start,min(1000L,start+batch-1L))
    r<-if(workers==1L)lapply(ids,one)else parallel::mclapply(ids,one,mc.cores=workers,mc.preschedule=FALSE,mc.set.seed=FALSE)
    for(k in seq_along(ids)){if(!is.list(r[[k]])||inherits(r[[k]],'try-error'))stop('Worker failure');results[[ids[k]]]<-r[[k]]}
    gate<-intersect(ids,c(1L,250L,500L,1000L))
    for(i in gate)if(results[[i]]$status!='SUCCESS')stop('Required baseline-pairing audit draw failed: ',i,' ',results[[i]]$message)
    log_msg('COMPARATOR_BOOTSTRAP',max(ids),'/1000')
  }
  status<-do.call(rbind,lapply(results,function(x)data.frame(replicate=x$replicate,status=x$status,message=x$message)))
  raw<-do.call(rbind,lapply(results,function(x)x$rows));success<-sum(status$status=='SUCCESS')
  wt(status,file.path(out,'comparator_bootstrap_status1000.tsv'))
  if(is.null(raw)){raw<-point[FALSE,];raw$replicate<-integer()}
  wt(raw,file.path(out,'comparator_bootstrap_changes_all.tsv.gz'))
  summary<-point;summary$successful_replicates<-success;summary$interval_status<-if(success>=950L)'AVAILABLE_NOMINAL_PERCENTILE_95'else'UNAVAILABLE_INSUFFICIENT_DRAWS'
  for(field in c('delta_signed','absolute_reduction')){
    summary[[paste0(field,'_CI95_low')]]<-NA_real_;summary[[paste0(field,'_CI95_high')]]<-NA_real_
    if(success>=950L)for(i in seq_len(nrow(summary))){
      x<-raw[raw$comparison==summary$comparison[i]&raw$backend==summary$backend[i]&raw$gene_symbol==summary$gene_symbol[i],field]
      stopifnot(length(x)==success,all(is.finite(x)));q<-quantile(x,c(.025,.975),type=7,names=FALSE)
      summary[i,paste0(field,c('_CI95_low','_CI95_high'))]<-as.list(q)
    }
  }
  wt(summary,file.path(out,'comparator_bootstrap_summary24.tsv'))
  success
}

make_external<-function(m,u,keep,conditioned,clinical){
  u$group<-factor(u$Type,levels=c('Heal','Infl'));u$Chem<-factor(u$Chem,levels=c('v2','v3'))
  u$Sex<-factor(u$Sex,levels=c('Female','Male'));ages<-sort(unique(as.character(u$Age_band)))
  ages<-ages[order(as.numeric(sub('-.*','',ages)))];u$Age_band<-factor(u$Age_band,levels=ages)
  active<-keep&Matrix::rowSums(m)>0;y<-edgeR::calcNormFactors(edgeR::DGEList(m[active,,drop=FALSE]))
  lib<-y$samples$lib.size*y$samples$norm.factors
  if(conditioned){
    positions<-match(IFN7,external_genes$gene_symbol);stopifnot(!anyNA(positions))
    score<-colMeans(log2(1+sweep(as.matrix(m[positions,,drop=FALSE]),2,lib/1e6,'/')))
    if(!is.finite(sd(score))||sd(score)<=0)stop('External IFN7 has no variation')
    u$IFN7_z<-as.numeric(scale(score))
  }
  formula<-if(clinical){if(conditioned)~Chem+Sex+Age_band+IFN7_z+group else ~Chem+Sex+Age_band+group}else{if(conditioned)~Chem+IFN7_z+group else ~Chem+group}
  X<-model.matrix(formula,u);rownames(X)<-u$unit_key;index<-match('groupInfl',colnames(X))
  if(is.na(index)||qr(X)$rank!=ncol(X)||nrow(X)-ncol(X)<2L)stop('Unavailable deletion design: rank or residual degrees of freedom')
  # The imported main helper expects the equivalent disease-column name.
  colnames(X)[index]<-'groupCD_inflamed'
  list(y=y,units=u,X=X,index=index,active=active)
}
external_analysis<-function(){
  external_genes<<-rd(file.path(code,'inputs','external','genes.tsv'))
  original<-rd(file.path(code,'inputs','external','units_POOLED_AUTHOR_MACROPHAGES.tsv'))
  u<-rd(file.path(code,'inputs','external','units_corrected_clinical.tsv'))
  u<-u[match(original$unit_key,u$unit_key),,drop=FALSE]
  stopifnot(nrow(u)==17L,identical(u$unit_key,original$unit_key),sum(u$Type=='Infl')==9L,sum(u$Type=='Heal')==8L)
  m<-read_counts(file.path(code,'inputs','external','counts_POOLED_AUTHOR_MACROPHAGES.mtx.gz'),external_genes,original)
  keep<-edgeR::filterByExpr(edgeR::DGEList(m),group=factor(u$Type,levels=c('Heal','Infl')),min.count=10,min.total.count=15,large.n=10,min.prop=.7)
  stopifnot(sum(keep)==5678L,keep[match('JMY',external_genes$gene_symbol)],!keep[match('EXT1',external_genes$gene_symbol)])
  names<-c('CHEM','CHEM_IFN7','CHEM_SEX_AGEBAND','CHEM_SEX_AGEBAND_IFN7');checks<-list();baselines<-list();information_rows<-list();deletions<-list()
  for(name in names){
    conditioned<-grepl('IFN7',name,fixed=TRUE);clinical<-grepl('SEX',name,fixed=TRUE);key<-paste0('POOLED_AUTHOR_MACROPHAGES__',name)
    p<-make_external(m,u,keep,conditioned,clinical);fit<-fit_one(p$y,p$X,external_genes,TRUE)
    expected_design<-rd(file.path(code,'reference_external',paste0('design_',key,'.tsv')))
    Xcheck<-p$X;colnames(Xcheck)[p$index]<-'groupInfl'
    stopifnot(identical(rownames(Xcheck),expected_design$unit_key),identical(colnames(Xcheck),names(expected_design)[-1L]),max(abs(Xcheck-as.matrix(expected_design[,-1L,drop=FALSE])))<1e-8)
    for(method in BACKENDS){
      e<-rd(file.path(code,'reference_external',paste0('ALL_genes_',key,'_',method,'.tsv')))
      checks[[paste(name,method)]]<-check_full(fit[[method]],e,paste(name,method))
      wt(do.call(rbind,checks),file.path(out,'external_baseline_checks40.tsv'))
      if(!all(do.call(rbind,checks)$passed))stop('External baseline did not reproduce')
      wt(fit[[method]],file.path(out,paste0('ALL_genes_external_baseline_',name,'_',method,'.tsv.gz')))
    }
    j<-match('JMY',fit$limma_voom$gene_symbol);qj<-match('JMY',fit$edgeR_QL$gene_symbol)
    # Recover target-specific voom quantities and check the coefficient independently.
    yy<-edgeR::estimateDisp(p$y,design=p$X);v<-limma::voom(yy,p$X,plot=FALSE);vf<-limma::eBayes(limma::lmFit(v,p$X),robust=FALSE)
    pos<-match(external_genes$gene_id[external_genes$gene_symbol=='JMY'],rownames(v$E))
    beta<-vf$coefficients[pos,p$index];se<-vf$stdev.unscaled[pos,p$index]*sqrt(vf$s2.post[pos])
    stopifnot(is.finite(se),se>0,abs(beta-fit$limma_voom$logFC[j])<1e-10)
    info<-information(p$X,p$index,v$weights[pos,])
    information_rows[[name]]<-data.frame(model_id=key,unit_key=u$unit_key,PubID=u$PubID,Type=u$Type,Age_band=u$Age_band,
      JMY_voom_weight=v$weights[pos,],JMY_weighted_leverage=info$leverage,JMY_weighted_disease_information_fraction=info$fraction)
    for(method in BACKENDS){z<-fit[[method]];jj<-which(z$gene_symbol=='JMY');baselines[[paste(name,method)]]<-data.frame(model=name,backend=method,log2FC=z$logFC[jj],PValue=z$PValue[jj],genome_q=z$genome_q[jj],voom_moderated_SE=if(method=='limma_voom')se else NA_real_)}
    for(i in seq_len(nrow(u))){
      log_msg('EXTERNAL_JMY_DELETE',name,i,'/17',u$unit_key[i]);dkey<-paste(name,i)
      result<-tryCatch({
        pu<-u[-i,,drop=FALSE];pm<-m[,-i,drop=FALSE];pp<-make_external(pm,pu,keep,conditioned,clinical);f<-fit_one(pp$y,pp$X,external_genes,TRUE)
        refreshed<-edgeR::filterByExpr(edgeR::DGEList(pm),group=factor(pu$Type,levels=c('Heal','Infl')),min.count=10,min.total.count=15,large.n=10,min.prop=.7)
        result<-list()
        for(method in BACKENDS){
          z<-f[[method]];stopifnot(all(is.finite(z$PValue)))
          # Zero-total deleted genes are retained internally as P=1 in the original BH universe.
          pfull<-rep(1,sum(keep));ids<-external_genes$gene_id[keep];positions<-match(z$gene_id,ids);stopifnot(!anyNA(positions))
          pfull[positions]<-z$PValue;z$genome_q<-p.adjust(pfull,'BH')[positions]
          z$gene_status<-'estimated';zero_ids<-setdiff(ids,z$gene_id)
          if(length(zero_ids)){
            missing<-z[rep(NA_integer_,length(zero_ids)),,drop=FALSE]
            missing$gene_id<-zero_ids;missing$gene_symbol<-external_genes$gene_symbol[match(zero_ids,external_genes$gene_id)]
            missing$gene_status<-'zero_total_after_deletion_no_displayed_test'
            z<-rbind(z,missing)
          }
          z<-z[match(ids,z$gene_id),,drop=FALSE]
          z$BH_internal_P<-pfull;z$BH_internal_q<-p.adjust(pfull,'BH')
          wt(z,file.path(out,paste0('ALL_genes_external_delete_',name,'_',sprintf('%02d',i),'_',method,'.tsv.gz')))
          jj<-which(z$gene_symbol=='JMY');if(length(jj)!=1L)stop('JMY unavailable after deletion')
          b<-baselines[[paste(name,method)]]$log2FC;delta<-z$logFC[jj]-b
          result[[method]]<-data.frame(model=name,backend=method,deleted_unit_key=u$unit_key[i],deleted_PubID=u$PubID[i],status='ESTIMATED_CONDITIONAL_INFLUENCE',detail='',log2FC=z$logFC[jj],delta_from_baseline=delta,
            delta_over_baseline_voom_moderated_SE=if(method=='limma_voom')delta/se else NA_real_,PValue=z$PValue[jj],genome_q=z$genome_q[jj],refreshed_JMY_expression_eligible=as.logical(refreshed[match('JMY',external_genes$gene_symbol)]),
            n_donors=nrow(pp$X),rank=qr(pp$X)$rank,residual_df=nrow(pp$X)-ncol(pp$X),fixed_BH_universe=sum(keep))
        }
        do.call(rbind,result)
      },error=function(e)data.frame(model=name,backend=BACKENDS,deleted_unit_key=u$unit_key[i],deleted_PubID=u$PubID[i],status='UNAVAILABLE',detail=conditionMessage(e),log2FC=NA_real_,delta_from_baseline=NA_real_,delta_over_baseline_voom_moderated_SE=NA_real_,PValue=NA_real_,genome_q=NA_real_,refreshed_JMY_expression_eligible=NA,n_donors=16L,rank=NA_integer_,residual_df=NA_integer_,fixed_BH_universe=sum(keep)))
      deletions[[dkey]]<-result;wt(do.call(rbind,deletions),file.path(out,'external_JMY_deletions136.tsv'))
    }
  }
  stopifnot(nrow(do.call(rbind,checks))==40L,nrow(do.call(rbind,deletions))==136L)
  wt(do.call(rbind,baselines),file.path(out,'external_JMY_baselines8.tsv'));wt(do.call(rbind,information_rows),file.path(out,'external_JMY_weighted_information68.tsv'))
  sum(do.call(rbind,deletions)$status=='UNAVAILABLE')
}
main<-function(){
  required<-c('Matrix','edgeR','limma');missing<-required[!vapply(required,requireNamespace,logical(1),quietly=TRUE)]
  if(length(missing))stop('Missing installed R packages: ',paste(missing,collapse=', '),'; no installation attempted')
  self_tests();success<-main_analysis();unavailable<-external_analysis()
  writeLines(c('All comparisons are post hoc reviewer-requested expression analyses, not causal or signaling-activity tests.',
    'Control scores were frozen before their new coefficient outputs and do not overlap IFN7 or either target.',
    'The same 1000 completed 06I donor draws pair comparator changes; intervals remain nominal and conditional on the observed universe.',
    'Existing cohort/IFN7 bootstrap estimates are reused from each exact draw, with four draw-level refitting checks.',
    'External deletions assess JMY influence conditional on the original pooled compartment and tested-gene universe.',
    'Rank-deficient or low-df deletions remain unavailable. Weighted information concentration is not an independent sample count.',
    'No new cohort is created; no filter relaxation, target substitution or retrospective selection correction is implied.'),file.path(out,'INTERPRETATION.txt'))
  status<-if(success<950L)'COMPLETED_WITH_INSUFFICIENT_BOOTSTRAP_DRAWS'else if(success<1000L||unavailable>0L)'COMPLETED_WITH_UNAVAILABLE_ROWS'else'COMPLETED'
  writeLines(status,file.path(out,'RUN_STATUS.txt'));log_msg('DONE_06J',status,'successful_bootstraps=',success,'unavailable_deletion_rows=',unavailable)
}
tryCatch({main();capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))},error=function(e){writeLines(conditionMessage(e),file.path(out,'RUN_FAILED.txt'));capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'));log_msg('FAILED_06J',conditionMessage(e));quit(status=1)})
