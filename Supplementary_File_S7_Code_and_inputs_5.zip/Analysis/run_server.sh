#!/usr/bin/env bash
set -Eeuo pipefail
root="${1:-/media/desk16/iy12923/消化/scmore/CD_scMORE}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
run_id="$(date +%Y%m%d_%H%M%S)_$$"
out_parent="$root/results/06E_independent_validation_20261106"
out="$out_parent/$run_id"
mkdir -p "$out"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
finish() {
  rc=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\nOUTPUT=%s\n' "$rc" "$out"
  if command -v zip >/dev/null 2>&1; then
    kind=RESULTS
    if [ "$rc" -ne 0 ]; then kind=PARTIAL; fi
    archive="$root/CD_06E_${kind}_${run_id}.zip"
    if (cd "$out_parent" && zip -q -r "$archive" "$run_id"); then printf 'RETURN_ZIP=%s\n' "$archive"; fi
  fi
  exit "$rc"
}
trap finish EXIT
printf 'START_06E=%s\nOUTPUT=%s\n' "$run_id" "$out"
rscript="${RSCRIPT_BIN:-}"
if [ -z "$rscript" ]; then rscript="$(command -v Rscript || true)"; fi
if [ -z "$rscript" ] || [ ! -x "$rscript" ]; then printf 'Rscript unavailable\n' >&2; exit 1; fi
printf 'RSCRIPT=%s\n' "$rscript"
mkdir -p "$out/executed_code"
cp -a "$script_dir/06E_external_validation.R" "$script_dir/collect_candidate_provenance.py" "$script_dir/run_server.sh" "$script_dir/inputs" "$out/executed_code/"
(cd "$script_dir/inputs" && sha256sum --check SHA256SUMS) > "$out/frozen_input_hash_check.log" 2>&1
printf 'FROZEN_INPUT_HASHES_PASSED\n'
if command -v python3 >/dev/null 2>&1; then
  if ! python3 "$script_dir/collect_candidate_provenance.py" "$root" "$out/candidate_provenance"; then printf 'CANDIDATE_RECORD_AUDIT_INCOMPLETE see console.log\n'; fi
else
  printf 'CANDIDATE_RECORD_AUDIT_UNAVAILABLE python3 unavailable\n'
fi
"$rscript" -e 'invisible(parse(file=commandArgs(TRUE)[1L]));cat("R_SYNTAX_OK\n")' "$script_dir/06E_external_validation.R" > "$out/R_parse.log" 2>&1
"$rscript" "$script_dir/06E_external_validation.R" "$script_dir/inputs" "$out"
