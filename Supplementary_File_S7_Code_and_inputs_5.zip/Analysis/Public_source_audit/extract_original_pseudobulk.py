#!/usr/bin/env python3
"""Read the unmodified published Table 4 using Python standard library only."""
import argparse, collections, csv, hashlib, json, posixpath, re, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

MAIN='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
OFFICE_REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
NS={'m':MAIN}
TARGET='pseudo-no_CD_uninflamed-disease'
LABELS=['Macrophages CD163++','Macrophages CD163+','Macrophages ITGA4+','Macrophages CCL3/4+ CXCL9/10+']

def tsv(path,fields,rows):
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n')
        w.writeheader();w.writerows(rows)

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(a.input) as z:
        assert z.testzip() is None
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            for event,e in ET.iterparse(z.open('xl/sharedStrings.xml'),events=['end']):
                if e.tag=='{'+MAIN+'}si':
                    strings.append(''.join(x.text or '' for x in e.iter('{'+MAIN+'}t')));e.clear()
        relations={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        sheets={}
        for s in ET.fromstring(z.read('xl/workbook.xml')).find('m:sheets',NS):
            target=relations[s.attrib['{'+OFFICE_REL+'}id']]
            sheets[s.attrib['name']]=target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)
        assert TARGET in sheets
        header=None;rows=[];flags=collections.Counter();cohorts=collections.Counter();labels=collections.Counter();total=0;q=[];full_mast=[]
        def read_rows(sheet):
            for event,e in ET.iterparse(z.open(sheets[sheet]),events=['end']):
                if e.tag!='{'+MAIN+'}row':continue
                values={}
                for c in e.findall('m:c',NS):
                    letters=re.match('[A-Z]+',c.attrib['r']).group();index=0
                    for letter in letters:index=index*26+ord(letter)-64
                    kind=c.attrib.get('t');v=c.find('m:v',NS)
                    if kind=='inlineStr':value=''.join(n.text or '' for n in c.iter('{'+MAIN+'}t'))
                    elif v is None:value=None
                    elif kind=='s':value=strings[int(v.text)]
                    elif kind=='b':value=v.text=='1'
                    elif kind in ('str','e'):value=v.text
                    else:
                        raw=v.text
                        value=float(raw)
                        if value.is_integer():value=int(value)
                    values[index-1]=value
                yield int(e.attrib['r']),[values.get(i) for i in range(max(values,default=-1)+1)]
                e.clear()
        for excel_row,values in read_rows(TARGET):
            if header is None:header=values;continue
            d=dict(zip(header,values));total+=1
            flags[str(d['significant'])]+=1;cohorts[d['cohort']]+=1
            q.append(float(d['qvalue_bh_allcelltypes']))
            if 'macrophage' in str(d['manual_annotation']).lower():labels[d['manual_annotation']]+=1
            if d['gene_symbol'] in ('EXT1','JMY'):d['excel_row']=excel_row;rows.append(d)
        h=None
        for excel_row,values in read_rows('no_CD_uninflamed-disease'):
            if h is None:h=values;continue
            d=dict(zip(h,values))
            if d.get('cohort')=='Full' and d.get('gene_symbol')=='EXT1' and d.get('manual_annotation')=='Macrophages CD163++':
                d['excel_row']=excel_row;full_mast.append(d)
    macro=[r for r in rows if r['manual_annotation'] in LABELS]
    matrix=[]
    for cohort in ['Discovery','Full','Replication']:
        for label in LABELS:
            for gene in ['EXT1','JMY']:
                found=[r for r in rows if r['cohort']==cohort and r['manual_annotation']==label and r['gene_symbol']==gene]
                assert len(found)<=1
                d={'cohort':cohort,'manual_annotation':label,'gene_symbol':gene,
                   'status':'LISTED_SIGNIFICANT' if found else 'NOT_LISTED_IN_SIGNIFICANT_TABLE',
                   'log2fc':'NA','qvalue_bh_allcelltypes':'NA','test_statistic':'NA','n_samples':'NA','excel_row':'NA',
                   'raw_P':'NA','raw_P_availability':'NOT_PROVIDED_IN_WORKSHEET'}
                if found:
                    for key in ['log2fc','qvalue_bh_allcelltypes','test_statistic','n_samples','excel_row']:d[key]=found[0][key]
                matrix.append(d)
    assert total==52952 and len(macro)==2
    assert all(r['gene_symbol']=='EXT1' and r['manual_annotation']=='Macrophages CD163++' for r in macro)
    assert flags=={'True':52952} and max(q)<.05
    assert len(full_mast)==1 and abs(full_mast[0]['log2fc']-.171228428901753)<1e-14
    tsv(a.out/'Original_pseudobulk_EXT1_JMY_all_observed_rows.tsv',header+['excel_row'],rows)
    tsv(a.out/'Original_pseudobulk_macrophage_candidates24.tsv',list(matrix[0]),matrix)
    tsv(a.out/'Original_Table4_Full_MAST_EXT1_annotation_check.tsv',list(full_mast[0]),full_mast)
    result={'source_doi':'10.1038/s41588-026-02634-7','download_url':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13364666/supplementaryFiles',
            'source_filename':'41588_2026_2634_MOESM5_ESM.xlsx','source_SHA256':hashlib.sha256(a.input.read_bytes()).hexdigest(),
            'worksheet':TARGET,'rows':total,'cohorts':cohorts,'significant_flags':flags,'q_min':min(q),'q_max':max(q),
            'macrophage_labels':labels,'observed_target_records_all_celltypes':len(rows),'observed_target_records_macrophages':macro,
            'planned_macrophage_cohort_gene_combinations':24,'not_listed_combinations':sum(r['status']!='LISTED_SIGNIFICANT' for r in matrix),
            'raw_P_available':False,'full_tested_gene_output_available':False,'new_RNA_models_fitted':False,
            'method_attribution':'Pseudobulk worksheet; original article Methods specifies DESeq2 v1.42.1. Method is not a separate worksheet column.',
            'missing_interpretation':'Not listed in the published significant-only worksheet; does not distinguish nonsignificance, filtering, or absent fit.',
            'annotation_crosscheck':full_mast}
    (a.out/'Original_DESeq2_source_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'completed':True,'source_rows':total,'all_target_records':len(rows),'macrophage_records':len(macro),'missing_combinations':result['not_listed_combinations']},ensure_ascii=False))

if __name__=='__main__':main()
