原始DESeq2候选结果核查，2026-11-06

结论
已取得原文补充表4，不再是“全部原始DESeq2数值未取得”。该工作簿第8页pseudo-no_CD_uninflamed-disease对应CD炎症对健康的pseudobulk结果；原文Methods说明pseudobulk使用DESeq2 v1.42.1。
这页共有52,952条数据记录，全部significant=True，所有qvalue_bh_allcelltypes均<0.05。它是显著结果列表，不是完整未筛选的模型输出，没有原始P值列。

原始巨噬细胞记录
Full，Macrophages CD163++，EXT1：log2fc=0.418230881690405，跨细胞类型BH q=0.00237951717419753，n_samples=291，Excel第29829行。
Replication，同一原注释，EXT1：log2fc=0.523963318200600，跨细胞类型BH q=0.0106257187028856，n_samples=150，Excel第48367行。
Discovery中该巨噬细胞EXT1未列入这页。JMY在这页三个队列、四个巨噬细胞注释中均未列入。
未列出不等于未表达、不显著或未检验；本表不足以区分这些原因，不能给缺失项填P=1或推算原始P值。
同一工作簿的单细胞MAST页中，Full/Macrophages CD163++的EXT1系数为0.171228428901753，和先前源文件Macrophages_CD163minushi记录一致，支持注释对应。
JMY在该pseudobulk页的Tuft cells中有Full及Replication记录，不能把巨噬细胞中缺失推广为原研究完全没有该基因结果。

取得方法
1. 原始论文：https://doi.org/10.1038/s41588-026-02634-7
2. 原文PMC入口：https://pmc.ncbi.nlm.nih.gov/articles/PMC13364666/
3. 若PMC单文件下载出现等待页、出版社下载报503，可用欧洲PMC的公开补充文件接口：https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13364666/supplementaryFiles
4. 从接口ZIP提取41588_2026_2634_MOESM5_ESM.xlsx；本包Original_Supplementary_Table4.xlsx保留该文件原始字节，没有重存或改动。
原始XLSX SHA256：12f64d9f0e7b074aac54885ed3bf6760313901dc7d98226863ec1c5b45b77952

本包内容
Original_Supplementary_Table4.xlsx：完整原始工作簿。
Original_pseudobulk_EXT1_JMY_all_observed_rows.tsv：两候选在所有细胞类型的31条实际公开记录，保留Excel行号。
Original_pseudobulk_macrophage_candidates24.tsv：三队列×四个原始巨噬细胞注释×两基因的24项核对清单；两项列出，22项仅标记未列入显著结果表。
Original_Table4_Full_MAST_EXT1_annotation_check.tsv：原工作簿的MAST标签对应核对。
Original_DESeq2_source_audit.json：来源、范围、字节校验和可用性。
extract_original_pseudobulk.py：Python标准库只读提取脚本，无需安装包、不重跑模型、不生成疾病P值。需Python>=3.8，以--input指定原XLSX，--out指定尚不存在的新目录。
independent_reader_verification.json：标准库ZIP/XML解析与openpyxl只读解析相互核对一致。

公开数据范围
本轮仅使用公开可下载的数据、原始补充表及公开代码，不依赖作者私下提供输出或受控访问数据。
未公开的原始P、未列出组合的效应/q及其缺失原因继续保留为不可用，不根据q反推P，也不以P=1填补原作者未公开记录。
公开表足以确认EXT1的既有报告，但不能确认巨噬细胞JMY的未列出原因。该限制写入正文、补充方法和修改说明。

文稿解释
原研究已通过单细胞混合模型和DESeq2 pseudobulk报告EXT1在相应巨噬细胞中的同方向关联。本文贡献应集中在重新定义人群与估计目标、协变量条件关联、不确定性以及独立表达覆盖，不宜把EXT1本身作为新发现。
本次06F公开数据修订稿已纳入上述结果：公开显著结果提供EXT1系数及跨细胞类型BH q，原始P、未列出项及完整输出不在该公开表中，继续保留为不可用。
自行用Full_cohort_fresh.h5ad重跑属于方法复现，不能标成原作者的原始输出。
