from pathlib import Path
import sys,json,hashlib
root=Path(sys.argv[1]);manifest=json.loads((root/'CODE_SHA256.json').read_text())
for name,expected in manifest.items():
 p=root/name;h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h!=expected:raise SystemExit('Input/code hash mismatch: '+name)
print('CODE_AND_INPUT_HASHES_VERIFIED',len(manifest),flush=True)
