#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C.UTF-8
CD06L_CODE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CD06L_OUT="${1:?Supply a new output directory}"
if [[ -e "$CD06L_OUT" ]]; then printf 'Output already exists: %s\n' "$CD06L_OUT" >&2; exit 2; fi
mkdir -p -- "$CD06L_OUT"
CD06L_OUT="$(cd -- "$CD06L_OUT" && pwd)"
finish_06l() {
  CD06L_RC=$?
  trap - EXIT
  set +e
  if [[ "$CD06L_RC" == 0 ]]; then printf 'COMPLETED\n' > "$CD06L_OUT/RUN_STATUS_06L.txt"; else printf 'FAILED EXIT_CODE=%s\n' "$CD06L_RC" > "$CD06L_OUT/RUN_STATUS_06L.txt"; fi
  python3 - "$CD06L_OUT" "$CD06L_RC" <<'PYZIP'
import pathlib,sys,zipfile
p=pathlib.Path(sys.argv[1]);rc=int(sys.argv[2]);tag='RESULTS' if rc==0 else 'PARTIAL'
z=p.parent/('CD_06L_'+tag+'_'+p.parent.name+'.zip')
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for f in sorted(p.rglob('*')):
  if f.is_file() and f.suffix!='.rds':out.write(f,p.name+'/'+str(f.relative_to(p)))
print('ARCHIVE_COMPLETE',str(z),flush=True)
print('RETURN_ZIP='+str(z),flush=True)
PYZIP
  CD06L_ARC_RC=$?
  if [[ "$CD06L_ARC_RC" != 0 && "$CD06L_RC" == 0 ]]; then CD06L_RC=$CD06L_ARC_RC; fi
  printf 'EXIT_CODE=%s\nOUTPUT=%s\n' "$CD06L_RC" "$CD06L_OUT"
  exit "$CD06L_RC"
}
trap finish_06l EXIT
CD06L_RSCRIPT="${CD06L_RSCRIPT:-$(command -v Rscript || true)}"
[[ -n "$CD06L_RSCRIPT" && -x "$CD06L_RSCRIPT" ]] || { printf 'An existing Rscript is required.\n' >&2; exit 2; }
printf 'START_06L=%s\nRSCRIPT=%s\nOUTPUT=%s\n' "$(date +%Y%m%d_%H%M%S)_$$" "$CD06L_RSCRIPT" "$CD06L_OUT"
python3 "$CD06L_CODE/verify_code_inputs.py" "$CD06L_CODE"
"$CD06L_RSCRIPT" "$CD06L_CODE/baseline_06K/06K_analysis.R" "$CD06L_CODE/baseline_06K" "$CD06L_OUT/baseline_reexecution"
"$CD06L_RSCRIPT" "$CD06L_CODE/06L_analysis.R" "$CD06L_CODE" "$CD06L_OUT/independent_study"
printf 'COMPLETED_06L\n'
