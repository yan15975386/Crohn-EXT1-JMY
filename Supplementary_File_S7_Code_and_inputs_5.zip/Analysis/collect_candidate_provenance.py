"""Read-only search of this project's earlier text records; no chronology inferred from mtimes."""
from pathlib import Path
import csv,gzip,hashlib,io,json,re,sys

root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
target=re.compile(r'(?<![A-Za-z0-9_])(?:EXT1|JMY)(?![A-Za-z0-9_])')
later=re.compile(r'^(?:06[A-Z_]|05[U-Z](?:_|\b))',re.I)
extensions={'.R','.r','.py','.sh','.txt','.md','.Rmd','.tsv','.csv','.json'}
MAX_FILE_BYTES=20*1024*1024;MAX_LINES=150000;MAX_MATCHES_PER_FILE=40
MAX_DECOMPRESSED_BYTES=32*1024*1024;MAX_TOTAL_READ_BYTES=256*1024*1024
early_directory=re.compile(r'^(?:0[0-4](?:[A-Za-z_-]|$)|05[A-T](?:_|\b))',re.I)
early_roots=[p for p in sorted(root.iterdir()) if p.is_dir() and not p.is_symlink() and early_directory.match(p.name)]
roots=[p for p in [root/'scripts',*early_roots,root/'results'] if p.is_dir()]
root_files=[p for p in sorted(root.iterdir()) if p.is_file() and not p.is_symlink()]
paths=root_files+[p for base in roots for p in sorted(base.rglob('*'))]
records=[];hits=[];total_read_bytes=0
for path in dict.fromkeys(paths):
        if not path.is_file() or path.is_symlink():continue
        rel=path.relative_to(root)
        if any(later.match(p) for p in rel.parts):continue
        if path.suffix not in extensions and not (path.name.endswith('.tsv.gz') or path.name.endswith('.csv.gz')):continue
        stat=path.stat();record={'relative_path':str(rel),'bytes':stat.st_size,'mtime_unix_NOT_creation_time':stat.st_mtime,'status':'scanned','sha256':None,'matched_lines':0,'reported_lines':0}
        if stat.st_size>MAX_FILE_BYTES:
            record['status']='skipped_size_limit';records.append(record);continue
        if total_read_bytes+stat.st_size>MAX_TOTAL_READ_BYTES:
            record['status']='skipped_total_read_budget';records.append(record);continue
        try:
            payload=path.read_bytes();total_read_bytes+=len(payload);record['sha256']=hashlib.sha256(payload).hexdigest()
            raw=gzip.GzipFile(fileobj=io.BytesIO(payload)) if path.suffix=='.gz' else io.BytesIO(payload)
            stream=io.TextIOWrapper(raw,encoding='utf-8',errors='replace');header='';decompressed_bytes=0
            for number,line in enumerate(stream,1):
                if number==1:header=line.rstrip('\r\n')
                decompressed_bytes+=len(line.encode('utf-8'))
                if number>MAX_LINES or decompressed_bytes>MAX_DECOMPRESSED_BYTES:
                    record['status']='partial_line_or_decompressed_limit';break
                if not target.search(line):continue
                record['matched_lines']+=1
                if record['reported_lines']<MAX_MATCHES_PER_FILE:
                    # Only matching lines and the header: no arbitrary neighbouring credentials.
                    hits.append({'relative_path':str(rel),'line_number':number,'line_text':line.rstrip('\r\n')[:3000],'header_if_table':header[:3000] if path.name.endswith(('.tsv','.csv','.tsv.gz','.csv.gz')) else '', 'file_sha256':record['sha256'],'line_truncated':len(line)>3000})
                    record['reported_lines']+=1
            stream.close()
            if record['matched_lines']>record['reported_lines']:record['status']+=';matches_truncated'
        except Exception as error:
            record['status']='read_error:'+str(error)[:250]
        records.append(record)
def table(name,rows,fields):
    with (out/name).open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields,delimiter='\t');writer.writeheader();writer.writerows(rows)
table('earlier_candidate_file_inventory.tsv',records,['relative_path','bytes','mtime_unix_NOT_creation_time','status','sha256','matched_lines','reported_lines'])
table('earlier_candidate_exact_symbol_hits.tsv',hits,['relative_path','line_number','line_text','header_if_table','file_sha256','line_truncated'])
summary={'scanned_roots':[str(root)+' (root text files only)']+[str(p) for p in roots],'n_files':len(records),'n_files_with_hits':sum(r['matched_lines']>0 for r in records),'reported_matching_lines':len(hits),'total_read_bytes':total_read_bytes,'source_files_modified':False,'interpretation':'These are available record hits, not proof of the first selection date or a prospective selection rule. Full original candidate pool and human decisions require author review. Mtimes are not treated as creation or selection dates.','limitations':'Root text, early 00-05T phase directories and scripts/results text were considered; phases 05U-05Z and 06 were excluded. A 256 MiB total read budget, compressed/decompressed size, line and per-file output limits are explicit in the inventory.'}
(out/'candidate_provenance_audit_status.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('CANDIDATE_RECORD_AUDIT',json.dumps(summary,ensure_ascii=False))
