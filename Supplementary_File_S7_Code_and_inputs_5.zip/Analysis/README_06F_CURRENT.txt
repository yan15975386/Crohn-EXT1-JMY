当前扩展位于06F_Offline_Revision/。它只用Python>=3.8标准库，输入已附，计算已完成；服务器执行为可选复现留档。请使用根目录RUN_06F_ONE_LINE.txt。
本目录原有06E_external_validation.R、run_server.sh及inputs/是已完成的独立队列RNA模型历史代码，不是本轮06F启动入口。
