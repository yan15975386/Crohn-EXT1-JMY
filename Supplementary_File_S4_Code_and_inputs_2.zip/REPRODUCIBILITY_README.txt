Analysis code and frozen inputs

Extract every Additional_file_*_Code_and_inputs_*.zip into the SAME directory. Each ZIP is an ordinary standalone archive; do not concatenate the ZIPs. Original relative paths are preserved across archives. Code is in the original analysis modules. Stage order is 06F, 06G, 06H2, 06I_Uncertainty_Coverage_R1, 06J, 06K, then 06L. The earlier 06I module is retained as historical provenance, not a replacement for its R1 version.

The environment and model formulas are documented in Supplementary Methods SM1-SM24 and module README/session files. The present submission adaptation did not rerun the statistical analyses. Original publisher article PDFs and original clinical workbooks are not redistributed; source accessions, source identities, corrected derived clinical crosswalks and numerical inputs are retained. Some audit steps require the original public source files from their repositories. No new environment installation or network download is run automatically by this package.

Use the original stage-specific launcher after setting paths for the local project and checking its README. Commands supplied to the authors retain the single-line nohup and tail -f convention. A frozen input archive is not a claim that every historical stage has been re-executed in the recipient's environment.
