#!/usr/bin/env Rscript
# Frozen exploratory score sensitivities. No downloads or package installation.
options(stringsAsFactors=FALSE,warn=1)
args<-commandArgs(trailingOnly=TRUE)
if(length(args)!=2L)stop('Usage: Rscript 06G_IFN_sensitivity.R PROJECT_ROOT NEW_OUTPUT_DIRECTORY')
root<-normalizePath(args[1],mustWork=TRUE);out<-normalizePath(args[2],mustWork=TRUE)
self<-normalizePath(sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),mustWork=TRUE)
code<-dirname(self)
required<-c('Matrix','edgeR','limma')
miss<-required[!vapply(required,requireNamespace,logical(1),quietly=TRUE)]
if(length(miss))stop('Missing installed packages: ',paste(miss,collapse=', '),'. No installation attempted.')
read_tab<-function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE)
write_tab<-function(x,name){
  p<-file.path(out,name)
  con<-if(grepl('\\.gz$',p))gzfile(p,'wt')else file(p,'wt')
  tryCatch(write.table(x,con,sep='\t',quote=FALSE,row.names=FALSE,na='NA'),finally=try(close(con),silent=TRUE))
}
log_msg<-function(...)cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),paste(...,collapse=' '),'\n')
IFN7<-c('STAT1','IRF1','ISG15','MX2','GBP1','GBP2','GBP5')
TARGETS<-c('EXT1','JMY')
external<-sort(unique(readLines(file.path(code,'inputs','Reactome_IFNG_genes.txt'),warn=FALSE)))
if(length(external)<10L||length(intersect(external,TARGETS)))stop('Invalid frozen external gene set')
expected<-read_tab(file.path(code,'inputs','expected_baselines16.tsv'))

resolve_cache<-function(){
  explicit<-Sys.getenv('CD06G_PB_DIR',unset='')
  candidates<-if(nzchar(explicit))explicit else file.path(root,'intermediate','05X_IBDverse_pseudobulk_20261030','counts_c9d0dbadfef2bb908699')
  manifest<-read_tab(file.path(code,'inputs','SOURCE_PB_manifest.tsv'))
  need<-c('genes.tsv','units_CD163hi.tsv','counts_CD163hi.mtx.gz')
  k<-match(need,manifest$path)
  if(anyNA(k))stop('Frozen source manifest is incomplete')
  for(d in unique(candidates)){
    p<-file.path(d,need)
    if(all(file.exists(p))&&identical(unname(tools::md5sum(p)),as.character(manifest$md5[k])))return(normalizePath(d))
  }
  stop('Original cache was not found or hashes differ. Set CD06G_PB_DIR to the existing frozen cache. Do not re-download H5AD.')
}

fit_tables<-function(y,X,coef,key,genes){
  if(qr(X)$rank!=ncol(X)||nrow(X)-ncol(X)<2L)stop('Nonidentifiable design: ',key)
  write_tab(data.frame(unit_key=rownames(X),X,check.names=FALSE),paste0('design_',key,'.tsv'))
  yy<-edgeR::estimateDisp(y,design=X)
  qfit<-edgeR::glmQLFit(yy,design=X,robust=FALSE)
  qt<-edgeR::topTags(edgeR::glmQLFTest(qfit,coef=coef),n=Inf,sort.by='none')$table
  qt$gene_id<-rownames(qt);qt$gene_symbol<-genes$gene_symbol[match(qt$gene_id,genes$gene_id)]
  qt$genome_q<-p.adjust(qt$PValue,'BH');qt$CI95_low<-NA_real_;qt$CI95_high<-NA_real_
  vv<-limma::voom(yy,design=X,plot=FALSE)
  vf<-limma::eBayes(limma::lmFit(vv,X),robust=FALSE)
  vt<-limma::topTable(vf,coef=coef,number=Inf,sort.by='none',confint=.95)
  vt$gene_id<-rownames(vt);vt$gene_symbol<-genes$gene_symbol[match(vt$gene_id,genes$gene_id)]
  vt$PValue<-vt$P.Value;vt$genome_q<-p.adjust(vt$PValue,'BH')
  vt$CI95_low<-vt$CI.L;vt$CI95_high<-vt$CI.R
  for(method in c('edgeR_QL','limma_voom')){
    z<-if(method=='edgeR_QL')qt else vt
    if(any(!is.finite(z$PValue))||anyDuplicated(z$gene_id))stop('Invalid full transcriptome output')
    write_tab(z,paste0('ALL_genes_',key,'_',method,'.tsv.gz'))
  }
  list(edgeR_QL=qt,limma_voom=vt)
}

extract_targets<-function(tables,variant,contrast,u,key){
  ans<-list()
  for(method in names(tables)){
    z<-tables[[method]]
    for(g in TARGETS){
      j<-which(z$gene_symbol==g);if(length(j)>1L)stop('Ambiguous target symbol')
      ans[[paste(method,g)]]<-data.frame(model_id=key,variant=variant,contrast=contrast,backend=method,gene_symbol=g,
        n_case=sum(u$group=='CD_inflamed'),n_reference=sum(u$group!='CD_inflamed'),n_tested_genes=nrow(z),
        log2FC=if(length(j))z$logFC[j]else NA_real_,CI95_low=if(length(j))z$CI95_low[j]else NA_real_,
        CI95_high=if(length(j))z$CI95_high[j]else NA_real_,PValue=if(length(j))z$PValue[j]else NA_real_,
        genome_q=if(length(j))z$genome_q[j]else NA_real_,
        status=if(length(j))'tested'else'not_tested_expression_filter',detail='',
        interval_method=if(method=='limma_voom')'moderated_t_for_its_own_voom_coefficient'else'not_reported_for_QL')
    }
  }
  do.call(rbind,ans)
}

missing_variant<-function(variant,contrast,u,key,reason,n_genes){
  z<-expand.grid(backend=c('edgeR_QL','limma_voom'),gene_symbol=TARGETS,stringsAsFactors=FALSE)
  data.frame(model_id=key,variant=variant,contrast=contrast,backend=z$backend,gene_symbol=z$gene_symbol,
    n_case=sum(u$group=='CD_inflamed'),n_reference=sum(u$group!='CD_inflamed'),n_tested_genes=n_genes,
    log2FC=NA_real_,CI95_low=NA_real_,CI95_high=NA_real_,PValue=NA_real_,genome_q=NA_real_,
    status='unavailable_score_coverage',detail=reason,interval_method='unavailable')
}

main<-function(){
  pb<-resolve_cache();writeLines(pb,file.path(out,'PSEUDOBULK_CACHE_LOCATION.txt'))
  genes<-read_tab(file.path(pb,'genes.tsv'));units<-read_tab(file.path(pb,'units_CD163hi.tsv'))
  con<-gzfile(file.path(pb,'counts_CD163hi.mtx.gz'),'rt')
  counts<-tryCatch(as(Matrix::readMM(con),'dgCMatrix'),finally=try(close(con),silent=TRUE))
  stopifnot(nrow(counts)==nrow(genes),ncol(counts)==nrow(units),!anyDuplicated(genes$gene_id),
            !anyDuplicated(units$unit_key),!anyDuplicated(units$individual_id))
  if(any(!is.finite(counts@x))||any(counts@x<0)||any(counts@x!=floor(counts@x)))stop('Counts are not raw nonnegative integers')
  rownames(counts)<-genes$gene_id;colnames(counts)<-units$unit_key
  sets<-c(list(COHORT=character(),IFN7=IFN7),setNames(lapply(IFN7,function(g)setdiff(IFN7,g)),paste0('DROP_',IFN7)),list(REACTOME_IFNG=external))
  ledger<-list();coverage<-list();baseline_checks<-list();vifs<-list()
  for(phase in c('BASELINE','SENSITIVITY')){
  for(contrast in c('A_vs_H','A_vs_U')){
    ref<-if(contrast=='A_vs_H')'Healthy'else'CD_uninflamed'
    u<-units[units$clinical_group%in%c(ref,'CD_inflamed') & units$n_cells>=15L,,drop=FALSE]
    stopifnot(!anyNA(u[,c('unit_key','individual_id','sex','age_binned_10','cohort','clinical_group')]))
    u$group<-factor(u$clinical_group,levels=c(ref,'CD_inflamed'));u$sex<-factor(u$sex,levels=c('female','male'))
    u$age_decade<-u$age_binned_10/10;u$cohort_factor<-factor(u$cohort,levels=c('Discovery','Replication'))
    if(min(table(u$group))<4L)stop('Insufficient group size')
    m<-counts[,match(u$unit_key,colnames(counts)),drop=FALSE]
    y<-edgeR::DGEList(counts=m)
    keep<-edgeR::filterByExpr(y,group=u$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
    y<-edgeR::calcNormFactors(y[keep,,keep.lib.sizes=FALSE])
    effective<-y$samples$lib.size*y$samples$norm.factors
    variants<-if(phase=='BASELINE')c('COHORT','IFN7')else setdiff(names(sets),c('COHORT','IFN7'))
    for(variant in variants){
      key<-paste0(variant,'_',contrast);log_msg('FIT_06G',key)
      requested<-sets[[variant]];present<-requested[requested%in%genes$gene_symbol]
      if(length(present)&&any(vapply(present,function(g)sum(genes$gene_symbol==g)!=1L,logical(1))))stop('Ambiguous score gene')
      coverage[[key]]<-data.frame(model_id=key,variant=variant,requested_members=length(requested),present_members=length(present),
        missing_members=paste(setdiff(requested,present),collapse=';'),members=paste(present,collapse=';'))
      enough<-variant=='COHORT'||if(variant=='REACTOME_IFNG')length(present)>=10L&&length(present)/length(requested)>=.8 else length(present)==length(requested)
      if(!enough){
        if(variant%in%c('COHORT','IFN7'))stop('Required baseline score coverage failed: ',key)
        ledger[[key]]<-missing_variant(variant,contrast,u,key,'Frozen score gene coverage failed; no substitute set used.',sum(keep))
        write_tab(do.call(rbind,ledger),'candidate_progress.tsv');next
      }
      if(variant!='COHORT'){
        j<-match(present,genes$gene_symbol)
        score<-colMeans(log2(1+sweep(as.matrix(m[j,,drop=FALSE]),2,effective/1e6,'/')))
        if(!is.finite(sd(score))||sd(score)==0)stop('Score has no variation: ',key)
        u$score_z<-as.numeric(scale(score))
        X<-model.matrix(~sex+age_decade+cohort_factor+score_z+group,u)
      }else{
        u$score_z<-NA_real_
        X<-model.matrix(~sex+age_decade+cohort_factor+group,u)
      }
      rownames(X)<-u$unit_key;coef<-match('groupCD_inflamed',colnames(X));stopifnot(!is.na(coef))
      write_tab(u,paste0('units_',key,'.tsv'))
      fit<-fit_tables(y,X,coef,key,genes)
      r<-extract_targets(fit,variant,contrast,u,key);ledger[[key]]<-r
      write_tab(do.call(rbind,ledger),'candidate_progress.tsv')
      if(variant%in%c('COHORT','IFN7')){
        e<-expected[expected$variant==variant & expected$contrast==contrast,,drop=FALSE]
        for(i in seq_len(nrow(e))){
          hit<-r[r$backend==e$backend[i] & r$gene_symbol==e$gene_symbol[i],,drop=FALSE]
          ok<-nrow(hit)==1L&&hit$status=='tested'&&abs(hit$log2FC-e$log2FC[i])<1e-7&&abs(hit$genome_q-e$genome_q[i])<1e-7
          baseline_checks[[paste(key,i)]]<-data.frame(model_id=key,backend=e$backend[i],gene_symbol=e$gene_symbol[i],passed=ok,
            expected_log2FC=e$log2FC[i],observed_log2FC=if(nrow(hit))hit$log2FC else NA_real_,
            expected_genome_q=e$genome_q[i],observed_genome_q=if(nrow(hit))hit$genome_q else NA_real_)
        }
        check<-do.call(rbind,baseline_checks);write_tab(check,'baseline_reproduction16.tsv')
        if(!all(check$passed))stop('Saved cohort/IFN7 baseline did not reproduce; remaining score variants stopped')
      }
      terms<-setdiff(seq_len(ncol(X)),1L)
      for(j in terms){
        z<-X[,j];res<-lm.fit(X[,-j,drop=FALSE],z)$residuals
        rsq<-1-sum(res^2)/sum((z-mean(z))^2)
        vifs[[paste(key,j)]]<-data.frame(model_id=key,term=colnames(X)[j],VIF=1/(1-rsq),n=nrow(X),rank=qr(X)$rank)
      }
      write_tab(do.call(rbind,coverage),'score_member_coverage20.tsv')
      write_tab(do.call(rbind,vifs),'design_VIF_terms.tsv')
    }
  }
  if(phase=='BASELINE'){
    stopifnot(nrow(do.call(rbind,baseline_checks))==16L,all(do.call(rbind,baseline_checks)$passed))
    log_msg('BASELINE_REPRODUCTION_PASSED',16)
  }
  }
  result<-do.call(rbind,ledger)
  write_tab(do.call(rbind,coverage),'score_member_coverage20.tsv')
  write_tab(do.call(rbind,vifs),'design_VIF_terms.tsv')
  stopifnot(nrow(do.call(rbind,baseline_checks))==16L,all(do.call(rbind,baseline_checks)$passed))
  stopifnot(nrow(result)==80L,!anyDuplicated(result[,c('model_id','backend','gene_symbol')]))
  write_tab(result,'Table_06G_score_sensitivity80.tsv')
  writeLines(c('Exploratory score sensitivities; targets, compartments, eligibility and filters are unchanged.',
    'The cohort and full-IFN7 models must reproduce 16 stored coefficient/q rows before interpretation.',
    'Reactome IFNG is the fixed Reactome_2022 set distributed publicly by Enrichr, not an outcome-selected gene set.',
    'Each full tested transcriptome has its own BH correction. No new candidate-family correction is introduced.',
    'Unavailable planned rows remain visible and are not assigned effects or P values.',
    'QL and voom effects remain separate; only voom has its own reported confidence interval.',
    'Scores share RNA measurements; stable results would not establish mediation or causal regulation.'),file.path(out,'INTERPRETATION.txt'))
  writeLines(if(any(result$status!='tested'))'COMPLETED_WITH_UNAVAILABLE_ROWS'else'COMPLETED',file.path(out,'RUN_STATUS.txt'))
  log_msg('DONE_06G','planned_rows=',nrow(result),'tested_rows=',sum(result$status=='tested'))
}
tryCatch({main();capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))},error=function(e){
  writeLines(conditionMessage(e),file.path(out,'RUN_FAILED.txt'))
  capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))
  log_msg('FAILED_06G',conditionMessage(e));quit(status=1)
})
