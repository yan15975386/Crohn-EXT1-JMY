#!/usr/bin/env bash
set -Eeuo pipefail
project_root="${1:-/media/desk16/iy12923/消化/scmore/CD_scMORE}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
run_id="$(date +%Y%m%d_%H%M%S)_$$"
out_parent="$project_root/results/06G_IFN_score_sensitivity_20261106"
out="$out_parent/$run_id"
mkdir -p "$out"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
finish() {
  rc=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\nOUTPUT=%s\n' "$rc" "$out"
  kind=RESULTS
  if [ "$rc" -ne 0 ]; then kind=PARTIAL; fi
  archive="$project_root/CD_06G_${kind}_${run_id}.zip"
  if command -v zip >/dev/null 2>&1; then
    if (cd "$out_parent" && zip -q -r "$archive" "$run_id"); then printf 'RETURN_ZIP=%s\n' "$archive"; fi
  else
    printf 'Archive not created: zip command unavailable; result directory is retained.\n'
  fi
  exit "$rc"
}
trap finish EXIT
printf 'START_06G=%s\nOUTPUT=%s\n' "$run_id" "$out"
rscript="${RSCRIPT_BIN:-}"
if [ -z "$rscript" ]; then rscript="$(command -v Rscript || true)"; fi
if [ -z "$rscript" ] || [ ! -x "$rscript" ]; then printf 'Rscript unavailable\n' >&2; exit 1; fi
printf 'RSCRIPT=%s\n' "$rscript"
mkdir -p "$out/executed_code"
cp -a "$script_dir/06G_IFN_sensitivity.R" "$script_dir/run_server.sh" "$script_dir/inputs" "$out/executed_code/"
"$rscript" -e 'invisible(parse(file=commandArgs(TRUE)[1]));cat("R_SYNTAX_OK\n")' "$script_dir/06G_IFN_sensitivity.R" > "$out/R_parse.log" 2>&1
"$rscript" "$script_dir/06G_IFN_sensitivity.R" "$project_root" "$out"
