06G IFN评分敏感性服务器包，2026-11-06

用途和执行状态
本包用于检验已固定EXT1/JMY结果对IFN评分定义的敏感性，不负责选择新靶点。
当前环境没有R运行时。本包尚未执行新增RNA模型拟合；正文没有引用这些待运行结果。
启动器会先用R进行语法解析，再要求16条既有COHORT/IFN7系数及全转录组q复现。任何基线失败会停止其余分析并保留PARTIAL返回包。

输入和环境
项目根：/media/desk16/iy12923/消化/scmore/CD_scMORE
默认读取原有intermediate/05X_IBDverse_pseudobulk_20261030/counts_c9d0dbadfef2bb908699下的genes.tsv、units_CD163hi.tsv、counts_CD163hi.mtx.gz；逐文件核对原始MD5。
如果缓存放在其他位置，可在启动命令前设定CD06G_PB_DIR；文件内容必须匹配所附清单。
仅使用既有R及Matrix、edgeR、limma。已执行结果使用R 4.4.1、edgeR 4.4.1、limma 3.62.1；本包不安装或升级软件，不下载H5AD。BLAS/OMP线程限制为1，可与其他任务同时运行。

固定分析范围
两个临床对照：CD_inflamed对Healthy，以及CD_inflamed对CD_uninflamed。
每个对照固定10种设计：COHORT基线、完整IFN7、7种每次删除一个IFN7成员的评分，以及外部Reactome IFNG评分。
外部集合为Enrichr公开分发的Reactome_2022中Interferon Gamma Signaling R-HSA-877300，89个基因。下载源、原始GMT、提取行及SHA256均随包保存。该集合的版本明确固定，未按候选效应或显著性筛选。
评分使用原始预过滤计数和同一过滤后TMM有效文库量，取平均log2(1+CPM)后标准化。候选不加入评分。
外部集合至少10成员且至少80%成员在特征表中唯一匹配才拟合；成员覆盖不足保留计划行和原因，不替换集合。IFN7基线成员不足则停止。
患者、区室、min15细胞、表达过滤及共同协变量保持原定义。每个模型分别报告QL和voom，共80条计划候选记录。各完整转录组单独BH；不增加一个新的候选家族校正。

运行与回传
把ZIP上传至项目根，复制RUN_ONE_LINE.txt的整条单行命令。它用nohup后台运行，并用tail -f监看该任务独立日志。Ctrl+C停止日志跟随，后台任务继续。
结果位于results/06G_IFN_score_sensitivity_20261106/独立时间戳_PID目录。脚本输出RETURN_ZIP指向应回传的RESULTS或PARTIAL ZIP。
请回传该ZIP。基线复现、成员覆盖、全部候选行、完整转录组、设计、VIF和R会话信息均被保留。

解释
所有新增评分比较均属探索性敏感性分析；不会使此前的两基因选择变成前瞻筛选。
QL点估计没有借用voom区间。未检验或不可用记录保持缺失，不填P=1。
即使结果在不同评分下稳定，也不能据此建立IFN调控、中介、功能机制或独立队列重复。
