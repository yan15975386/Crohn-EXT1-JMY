#!/usr/bin/env python3
"""Offline isolated launcher. Always retain a complete or partial return ZIP."""
from pathlib import Path
import argparse,csv,datetime as dt,hashlib,json,os,shutil,subprocess,sys,traceback,zipfile

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8388608),b''):h.update(block)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('project_root',type=Path);ap.add_argument('run_directory',type=Path);a=ap.parse_args()
    root=a.project_root.resolve();run=a.run_directory.resolve();code=Path(__file__).resolve().parent
    token=dt.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+str(os.getpid());out=root/'results/06I_uncertainty_coverage_20261108'/token;out.mkdir(parents=True,exist_ok=False)
    payload=run/'06I_RESULTS';payload.mkdir(exist_ok=False);status=1
    print('START_06I='+token,flush=True);print('OUTPUT='+str(out),flush=True)
    try:
        rows=list(csv.DictReader((code/'SHA256SUMS.tsv').open(),delimiter='\t'))
        for r in rows:
            p=code/r['path']
            if not p.is_file() or p.stat().st_size!=int(r['bytes']) or sha(p)!=r['sha256']:raise RuntimeError('Package checksum mismatch: '+r['path'])
        print('PACKAGE_HASH_CHECKS_PASSED='+str(len(rows)),flush=True);shutil.copytree(code,payload/'executed_code')
        rscript=os.environ.get('CD06I_RSCRIPT') or shutil.which('Rscript')
        if not rscript:raise RuntimeError('Rscript not found. Use the existing server R; no installation attempted.')
        env=os.environ.copy();env.update({'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
        (out/'launcher_runtime.json').write_text(json.dumps({'Rscript':rscript,'bootstrap_replicates':env.get('CD06I_BOOTSTRAPS','1000'),'workers':env.get('CD06I_WORKERS','4'),'no_downloads_or_installation':True},indent=2)+'\n')
        print('RSCRIPT='+rscript,flush=True)
        subprocess.run([rscript,'--vanilla','-e','invisible(parse(file=commandArgs(trailingOnly=TRUE)[1]));cat("R_PARSE_PASSED\\n")',str(code/'06I_analysis.R')],env=env,check=True)
        status=subprocess.run([rscript,'--vanilla',str(code/'06I_analysis.R'),str(root),str(out)],env=env).returncode
        if status==0 and not (out/'RUN_STATUS.txt').exists():raise RuntimeError('R exited without final run status')
    except Exception as exc:
        status=1;(out/'LAUNCHER_FAILED.txt').write_text(str(exc)+'\n'+traceback.format_exc());print('FAILED_06I '+str(exc),flush=True)
    finally:
        shutil.copytree(out,payload/'results',dirs_exist_ok=True)
        if (run/'console.log').exists():shutil.copy2(run/'console.log',payload/'console.log')
        (payload/'EXIT_CODE.txt').write_text(str(status)+'\n');manifest=payload/'SHA256SUMS.tsv'
        with manifest.open('w',newline='') as f:
            w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['sha256','path','bytes'])
            for p in sorted(payload.rglob('*')):
                if p.is_file() and p!=manifest:w.writerow([sha(p),p.relative_to(payload).as_posix(),p.stat().st_size])
        archive=root/(('CD_06I_RESULTS_' if status==0 else 'CD_06I_PARTIAL_')+token+'.zip')
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
            for p in sorted(payload.rglob('*')):
                if p.is_file():z.write(p,(Path(payload.name)/p.relative_to(payload)).as_posix())
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:raise RuntimeError('Return archive CRC failed')
        print('ARCHIVE_COMPLETE '+str(archive),flush=True);print('RETURN_ZIP='+str(archive),flush=True);print('EXIT_CODE='+str(status),flush=True);print('OUTPUT='+str(out),flush=True)
    return status

if __name__=='__main__':raise SystemExit(main())
