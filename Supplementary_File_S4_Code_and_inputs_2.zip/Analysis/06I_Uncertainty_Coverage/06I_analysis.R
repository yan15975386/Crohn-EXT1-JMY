#!/usr/bin/env Rscript
# Frozen review follow-up. No downloads, installation or clinical-model reruns.
options(stringsAsFactors=FALSE,warn=1)
IFN7<-c('STAT1','IRF1','ISG15','MX2','GBP1','GBP2','GBP5');TARGETS<-c('EXT1','JMY')
rd<-function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE)
wt<-function(x,p){con<-if(grepl('\\.gz$',p))gzfile(p,'wt')else file(p,'wt');on.exit(try(close(con),silent=TRUE));write.table(x,con,sep='\t',quote=FALSE,row.names=FALSE,na='NA')}
msg<-function(...)cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),paste(...,collapse=' '),'\n')
change<-function(a,b)c(delta_signed=b-a,absolute_reduction=abs(a)-abs(b))
draw_indices<-function(u){strata<-interaction(u$group,u$cohort_factor,drop=TRUE,lex.order=TRUE);unlist(lapply(split(seq_len(nrow(u)),strata),function(j)sample(j,length(j),replace=TRUE)),use.names=FALSE)}
match_reference<-function(f,g){
  target<-f[f$gene_symbol==g,,drop=FALSE];pool<-f[!f$gene_symbol%in%TARGETS,,drop=FALSE]
  empty<-pool[FALSE,];empty$mean_difference<-numeric();empty$detection_difference<-numeric();empty$distance<-numeric()
  if(nrow(target)!=1L)return(list(rows=empty,n_caliper=0L,status='TARGET_ANNOTATION_NOT_CONCORDANT'))
  s<-vapply(pool[,c('mean_log2_raw_CPM','donor_detection_fraction')],sd,numeric(1))
  if(any(!is.finite(s))||any(s<=0))stop('Matching reference feature has no variance')
  pool$mean_difference<-pool$mean_log2_raw_CPM-target$mean_log2_raw_CPM
  pool$detection_difference<-pool$donor_detection_fraction-target$donor_detection_fraction
  pool$distance<-(pool$mean_difference/s[1])^2+(pool$detection_difference/s[2])^2
  pool<-pool[abs(pool$mean_difference)<=.5&abs(pool$detection_difference)<=.10,,drop=FALSE]
  pool<-pool[order(pool$distance,pool$gene_id,method='radix'),,drop=FALSE];selected<-head(pool,100L)
  list(rows=selected,n_caliper=nrow(pool),status=if(nrow(selected)>=20L)'SUFFICIENT_MATCHES'else'INSUFFICIENT_MATCHES_NO_CALIPER_RELAXATION')
}
self_tests<-function(){
  stopifnot(max(abs(change(-.4,-.1)-c(.3,.3)))<1e-12,max(abs(change(-.2,.3)-c(.5,-.1)))<1e-12)
  u<-data.frame(group=factor(rep(c('Healthy','CD_inflamed'),each=8)),cohort_factor=factor(rep(c('Discovery','Replication'),8)))
  set.seed(20261108);j<-draw_indices(u)
  stopifnot(length(j)==nrow(u),identical(unname(table(u$group,u$cohort_factor)),unname(table(u$group[j],u$cohort_factor[j]))))
  f<-data.frame(gene_id=paste0('G',1:62),gene_symbol=c('EXT1','JMY',paste0('C',1:60)),mean_log2_raw_CPM=c(2,3,seq(1,4,length.out=60)),donor_detection_fraction=c(.8,.9,seq(.6,1,length.out=60)))
  a<-match_reference(f,'EXT1');b<-match_reference(f[nrow(f):1,],'EXT1')
  stopifnot(identical(a$rows$gene_id,b$rows$gene_id),!any(a$rows$gene_symbol%in%TARGETS),all(abs(a$rows$mean_difference)<=.5),all(abs(a$rows$detection_difference)<=.10))
  f$mean_log2_raw_CPM[f$gene_symbol=='EXT1']<-100;stopifnot(nrow(match_reference(f,'EXT1')$rows)==0L)
  msg('R_SELF_TESTS_PASSED','synthetic logic only, not biological analysis')
}
args<-commandArgs(trailingOnly=TRUE)
if(identical(args,'--self-test')){self_tests();quit(status=0)}
if(length(args)!=2L)stop('Usage: Rscript 06I_analysis.R PROJECT_ROOT NEW_OUTPUT_DIRECTORY')
root<-normalizePath(args[1],mustWork=TRUE);out<-normalizePath(args[2],mustWork=TRUE)
self<-normalizePath(sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),mustWork=TRUE);code<-dirname(self)
B<-as.integer(Sys.getenv('CD06I_BOOTSTRAPS','1000'));workers<-as.integer(Sys.getenv('CD06I_WORKERS','4'));SEED<-20261108L

read_counts<-function(path,genes,units){
  con<-gzfile(path,'rt');on.exit(try(close(con),silent=TRUE));m<-as(Matrix::readMM(con),'CsparseMatrix')
  stopifnot(nrow(m)==nrow(genes),ncol(m)==nrow(units),!anyDuplicated(genes$gene_id),!anyDuplicated(units$unit_key))
  if(any(!is.finite(m@x))||any(m@x<0)||any(m@x!=floor(m@x)))stop('Counts are not raw nonnegative integers')
  rownames(m)<-genes$gene_id;colnames(m)<-units$unit_key;m
}
resolve_cache<-function(){
  p<-Sys.getenv('CD06I_PB_DIR','');if(!nzchar(p))p<-file.path(root,'intermediate','05X_IBDverse_pseudobulk_20261030','counts_c9d0dbadfef2bb908699')
  needed<-c('genes.tsv','units_CD163hi.tsv','counts_CD163hi.mtx.gz');manifest<-rd(file.path(code,'inputs','SOURCE_PB_manifest.tsv'))
  expected<-as.character(manifest$md5[match(needed,manifest$path)])
  if(anyNA(expected)||!all(file.exists(file.path(p,needed)))||!identical(unname(tools::md5sum(file.path(p,needed))),expected))stop('Frozen cache missing or hashes differ. Set CD06I_PB_DIR; do not download H5AD again.')
  writeLines(normalizePath(p),file.path(out,'PSEUDOBULK_CACHE_LOCATION.txt'))
  snapshot<-file.path(out,'input_snapshot');dir.create(snapshot,showWarnings=FALSE)
  if(!all(file.copy(file.path(p,needed),file.path(snapshot,needed),overwrite=TRUE)))stop('Input snapshot failed')
  stopifnot(identical(unname(tools::md5sum(file.path(snapshot,needed))),expected));snapshot
}
prepare<-function(m,u,keep,score_rows){
  y<-edgeR::DGEList(m[keep,,drop=FALSE])
  if(any(colSums(y$counts)<=0)||any(rowSums(y$counts)<=0))stop('Zero library or gene in fixed bootstrap universe')
  y<-edgeR::calcNormFactors(y);effective<-y$samples$lib.size*y$samples$norm.factors
  score<-colMeans(log2(1+sweep(as.matrix(m[score_rows,,drop=FALSE]),2,effective/1e6,'/')))
  if(!is.finite(sd(score))||sd(score)<=0)stop('IFN7 score has no variation')
  u$score_z<-as.numeric(scale(score))
  X0<-model.matrix(~sex+age_decade+cohort_factor+group,u);X1<-model.matrix(~sex+age_decade+cohort_factor+score_z+group,u)
  rownames(X0)<-rownames(X1)<-colnames(m)
  for(X in list(X0,X1))if(qr(X)$rank!=ncol(X)||nrow(X)-ncol(X)<2L)stop('Nonestimable resampled design')
  list(y=y,X0=X0,X1=X1,units=u)
}
fit_one<-function(y,X,genes,full=FALSE){
  coefficient<-match('groupCD_inflamed',colnames(X));stopifnot(!is.na(coefficient))
  yy<-edgeR::estimateDisp(y,design=X);qfit<-edgeR::glmQLFit(yy,design=X,robust=FALSE)
  qcoef<-qfit$coefficients[,coefficient]/log(2)
  v<-limma::voom(yy,design=X,plot=FALSE);vf<-limma::eBayes(limma::lmFit(v,X),robust=FALSE)
  if(!full)return(list(edgeR_QL=data.frame(gene_id=rownames(y),logFC=qcoef),limma_voom=data.frame(gene_id=rownames(y),logFC=vf$coefficients[,coefficient])))
  qt<-edgeR::topTags(edgeR::glmQLFTest(qfit,coef=coefficient),n=Inf,sort.by='none')$table
  qt$gene_id<-rownames(qt);qt$gene_symbol<-genes$gene_symbol[match(qt$gene_id,genes$gene_id)];qt$genome_q<-p.adjust(qt$PValue,'BH');qt$CI95_low<-NA_real_;qt$CI95_high<-NA_real_
  vt<-limma::topTable(vf,coef=coefficient,number=Inf,sort.by='none',confint=.95)
  vt$gene_id<-rownames(vt);vt$gene_symbol<-genes$gene_symbol[match(vt$gene_id,genes$gene_id)];vt$PValue<-vt$P.Value;vt$genome_q<-p.adjust(vt$PValue,'BH');vt$CI95_low<-vt$CI.L;vt$CI95_high<-vt$CI.R
  stopifnot(max(abs(qt$logFC-qcoef[match(qt$gene_id,rownames(y))]))<1e-12,max(abs(vt$logFC-vf$coefficients[match(vt$gene_id,rownames(y)),coefficient]))<1e-12)
  list(edgeR_QL=qt,limma_voom=vt)
}
pair_targets<-function(a,b,genes){
  rows<-list()
  for(method in names(a))for(g in TARGETS){
    id<-genes$gene_id[genes$gene_symbol==g];if(length(id)!=1L)stop('Ambiguous target')
    x<-a[[method]]$logFC[match(id,a[[method]]$gene_id)];y<-b[[method]]$logFC[match(id,b[[method]]$gene_id)]
    if(length(x)!=1L||length(y)!=1L||!is.finite(x)||!is.finite(y))stop('Unavailable coefficient')
    rows[[paste(method,g)]]<-data.frame(backend=method,gene_symbol=g,cohort_log2FC=x,IFN7_log2FC=y,delta_signed=y-x,absolute_reduction=abs(x)-abs(y),relative_reduction_pct=100*(1-abs(y)/abs(x)),ratio_baseline_abs_ge_0_1=abs(x)>=.1)
  };do.call(rbind,rows)
}
baseline_checks<-function(fits){
  checks<-list()
  for(v in names(fits))for(method in names(fits[[v]])){
    a<-fits[[v]][[method]];e<-rd(file.path(code,'reference_baseline',paste0('ALL_genes_',v,'_A_vs_H_',method,'.tsv.gz')))
    if(nrow(a)!=nrow(e)||!setequal(a$gene_id,e$gene_id))stop('Baseline gene universe mismatch')
    a<-a[match(e$gene_id,a$gene_id),,drop=FALSE]
    for(field in c('logFC','PValue','genome_q','CI95_low','CI95_high')){
      x<-a[[field]];y<-e[[field]];finite<-is.finite(x)&is.finite(y);difference<-if(any(finite))max(abs(x[finite]-y[finite]))else NA_real_
      passed<-identical(is.na(x),is.na(y))&&!any(is.infinite(x))&&(is.na(difference)||difference<1e-7)
      checks[[paste(v,method,field)]]<-data.frame(variant=v,backend=method,column=field,n_finite_pairs=sum(finite),max_absolute_difference=difference,passed=passed)
    };wt(a,file.path(out,paste0('ALL_genes_reproduced_',v,'_',method,'.tsv.gz')))
  }
  checks<-do.call(rbind,checks);wt(checks,file.path(out,'baseline_full_gene_checks20.tsv'))
  if(!all(checks$passed))stop('Historical full-gene baselines did not reproduce; new calculations stopped')
  msg('FULL_GENE_BASELINE_REPRODUCED',nrow(checks),'column checks')
}
coverage<-function(m,u,genes,keep){
  external_genes<-rd(file.path(code,'inputs','genes.tsv'));j<-match(genes$gene_id,external_genes$gene_id)
  unique_main<-!duplicated(genes$gene_symbol)&!duplicated(genes$gene_symbol,fromLast=TRUE)&!is.na(genes$gene_symbol)&nzchar(genes$gene_symbol)
  unique_ext<-!duplicated(external_genes$gene_symbol)&!duplicated(external_genes$gene_symbol,fromLast=TRUE)&!is.na(external_genes$gene_symbol)&nzchar(external_genes$gene_symbol)
  common<-keep&unique_main&!is.na(j);common[common]<-unique_ext[j[common]]&genes$gene_symbol[common]==external_genes$gene_symbol[j[common]]
  lib<-Matrix::colSums(m);stopifnot(all(lib>0));expression<-log2(1+sweep(as.matrix(m),2,lib/1e6,'/'))
  f<-data.frame(gene_id=genes$gene_id,gene_symbol=genes$gene_symbol,mean_log2_raw_CPM=rowMeans(expression),donor_detection_fraction=Matrix::rowMeans(m>0),main_filter_passed=keep,unambiguous_common_reference=common)
  wt(f,file.path(out,'coverage_main_reference_features.tsv.gz'));rm(expression)
  selected<-setNames(lapply(TARGETS,function(g)match_reference(f[common,,drop=FALSE],g)),TARGETS)
  roster<-do.call(rbind,lapply(TARGETS,function(g){r<-selected[[g]]$rows;r$target<-rep(g,nrow(r));r$matching_rank<-seq_len(nrow(r));r$n_within_calipers<-rep(selected[[g]]$n_caliper,nrow(r));r}))
  wt(roster,file.path(out,'coverage_matched_gene_roster.tsv'))
  expected<-rd(file.path(code,'inputs','expected_external_eligibility4.tsv'));allstats<-list();joined<-list();summary<-list();checks<-list()
  for(comp in c('AUTHOR_MACROPHAGES','POOLED_AUTHOR_MACROPHAGES')){
    eu<-rd(file.path(code,'inputs',paste0('units_',comp,'.tsv')));x<-read_counts(file.path(code,'inputs',paste0('counts_',comp,'.mtx.gz')),external_genes,eu)
    elib<-Matrix::colSums(x);cut<-10/median(elib)*1e6;minimum<-min(table(eu$Type));above<-rowSums(sweep(as.matrix(x),2,elib/1e6,'/')>=cut);total<-Matrix::rowSums(x)
    eligible<-edgeR::filterByExpr(edgeR::DGEList(x),group=eu$Type,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
    stopifnot(identical(as.logical(eligible),as.logical(above>=minimum&total>=15)))
    st<-data.frame(compartment=comp,gene_id=external_genes$gene_id,gene_symbol=external_genes$gene_symbol,n_donors=nrow(eu),CPM_cutoff=cut,minimum_donors_above_CPM=minimum,observed_donors_above_CPM=above,total_raw_counts=total,passed_frozen_filter=eligible);allstats[[comp]]<-st
    for(g in TARGETS){
      t<-st[st$gene_symbol==g,,drop=FALSE];e<-expected[expected$compartment==comp&expected$gene_symbol==g,,drop=FALSE];stopifnot(nrow(t)==1L,nrow(e)==1L)
      passed<-t$total_raw_counts==e$total_raw_counts&&t$observed_donors_above_CPM==e$observed_donors_above_CPM&&t$passed_frozen_filter==e$passed_frozen_filter&&sum(eligible)==e$n_genes_after_filter&&abs(cut-e$CPM_cutoff)<1e-7
      checks[[paste(comp,g)]]<-data.frame(compartment=comp,gene_symbol=g,passed=passed);if(!passed)stop('Independent coverage baseline mismatch: ',comp,' ',g)
      matches<-selected[[g]];j<-match(matches$rows$gene_id,st$gene_id);stopifnot(!anyNA(j));cs<-st[j,,drop=FALSE];cs$target<-rep(g,nrow(cs));cs$matching_rank<-seq_len(nrow(cs));joined[[paste(comp,g)]]<-cs
      sufficient<-matches$status=='SUFFICIENT_MATCHES'
      summary[[paste(comp,g)]]<-data.frame(compartment=comp,gene_symbol=g,n_reference_donors=nrow(u),n_matched_controls=nrow(cs),n_within_calipers=matches$n_caliper,matching_status=matches$status,target_total_raw_counts=t$total_raw_counts,target_donors_above_CPM=t$observed_donors_above_CPM,target_passed_filter=t$passed_frozen_filter,matched_controls_passed=sum(cs$passed_frozen_filter),matched_controls_pass_fraction=if(sufficient)mean(cs$passed_frozen_filter)else NA_real_,target_donor_coverage_percentile=if(sufficient)100*(sum(cs$observed_donors_above_CPM<t$observed_donors_above_CPM)+.5*sum(cs$observed_donors_above_CPM==t$observed_donors_above_CPM))/nrow(cs)else NA_real_,formal_PValue=NA_real_)
    }
  }
  wt(do.call(rbind,allstats),file.path(out,'coverage_all_external_gene_metrics.tsv.gz'));wt(do.call(rbind,joined),file.path(out,'coverage_matched_external_metrics.tsv'));wt(do.call(rbind,summary),file.path(out,'coverage_matched_summary4.tsv'));wt(do.call(rbind,checks),file.path(out,'coverage_baseline_checks4.tsv'))
  msg('MATCHED_COVERAGE_COMPLETED','reference selection uses main-cohort features only; no enrichment tests')
}
main<-function(){
  needed<-c('Matrix','edgeR','limma');missing<-needed[!vapply(needed,requireNamespace,logical(1),quietly=TRUE)];if(length(missing))stop('Missing installed packages: ',paste(missing,collapse=', '),'; no installation attempted')
  if(is.na(B)||B<200L||B>10000L||is.na(workers)||workers<1L||workers>16L)stop('Invalid CD06I_BOOTSTRAPS (200..10000) or CD06I_WORKERS (1..16)')
  workers<-min(workers,B);self_tests();pb<-resolve_cache();genes<-rd(file.path(pb,'genes.tsv'));units<-rd(file.path(pb,'units_CD163hi.tsv'));stopifnot(!anyDuplicated(units$individual_id))
  counts<-read_counts(file.path(pb,'counts_CD163hi.mtx.gz'),genes,units)
  u<-units[units$clinical_group%in%c('Healthy','CD_inflamed')&units$n_cells>=15L,,drop=FALSE]
  stopifnot(!anyNA(u[,c('individual_id','sex','age_binned_10','cohort','clinical_group')]),sum(u$clinical_group=='Healthy')==113L,sum(u$clinical_group=='CD_inflamed')==50L)
  u$group<-factor(u$clinical_group,levels=c('Healthy','CD_inflamed'));u$sex<-factor(u$sex,levels=c('female','male'));u$age_decade<-u$age_binned_10/10;u$cohort_factor<-factor(u$cohort,levels=c('Discovery','Replication'))
  m<-counts[,match(u$unit_key,colnames(counts)),drop=FALSE];rm(counts)
  keep<-edgeR::filterByExpr(edgeR::DGEList(m),group=u$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7);stopifnot(sum(keep)==8335L)
  score_rows<-match(IFN7,genes$gene_symbol);stopifnot(!anyNA(score_rows),all(vapply(IFN7,function(g)sum(genes$gene_symbol==g)==1L,logical(1))))
  initial<-prepare(m,u,keep,score_rows);f0<-fit_one(initial$y,initial$X0,genes,TRUE);f1<-fit_one(initial$y,initial$X1,genes,TRUE);baseline_checks(list(COHORT=f0,IFN7=f1))
  point<-pair_targets(f0,f1,genes);wt(point,file.path(out,'bootstrap_original_paired_effects4.tsv'));wt(initial$units,file.path(out,'main_units163.tsv'));wt(data.frame(gene_id=genes$gene_id,original_filter_passed=keep),file.path(out,'main_fixed_gene_universe.tsv.gz'))
  wt(data.frame(bootstrap_replicates=B,master_seed=SEED,workers=workers,minimum_success_fraction=.95),file.path(out,'runtime_settings.tsv'))
  coverage(m,u,genes,keep)
  RNGkind("L'Ecuyer-CMRG");set.seed(SEED);streams<-vector('list',B);for(i in seq_len(B)){streams[[i]]<-.Random.seed;.Random.seed<-parallel::nextRNGStream(.Random.seed)}
  signature<-list(B=B,seed=SEED,script_md5=unname(tools::md5sum(self)),cache_md5=unname(tools::md5sum(file.path(pb,c('genes.tsv','units_CD163hi.tsv','counts_CD163hi.mtx.gz')))))
  sf<-file.path(out,'bootstrap_signature.rds');if(file.exists(sf)){if(!identical(readRDS(sf),signature))stop('Checkpoint signature changed; use a new output directory')}else saveRDS(signature,sf)
  checkpoint<-file.path(out,'bootstrap_checkpoints');dir.create(checkpoint,showWarnings=FALSE)
  one<-function(i){
    p<-file.path(checkpoint,sprintf('replicate_%05d.rds',i));if(file.exists(p))return(readRDS(p));assign('.Random.seed',streams[[i]],envir=.GlobalEnv)
    j<-draw_indices(u);bu<-u[j,,drop=FALSE];bm<-m[,j,drop=FALSE];colnames(bm)<-paste0('draw_',seq_len(ncol(bm)));rownames(bu)<-colnames(bm)
    result<-tryCatch({prepared<-prepare(bm,bu,keep,score_rows);a<-fit_one(prepared$y,prepared$X0,genes);b<-fit_one(prepared$y,prepared$X1,genes);r<-pair_targets(a,b,genes);r$replicate<-i;list(replicate=i,status='SUCCESS',message='',indices=j,rows=r)},error=function(e)list(replicate=i,status='UNAVAILABLE',message=conditionMessage(e),indices=j,rows=NULL))
    temporary<-paste0(p,'.tmp_',Sys.getpid());saveRDS(result,temporary);if(!file.rename(temporary,p))stop('Cannot save checkpoint');result
  }
  results<-vector('list',B);batch<-workers*5L
  for(start in seq.int(1L,B,by=batch)){
    ids<-seq.int(start,min(B,start+batch-1L));r<-if(workers==1L)lapply(ids,one)else parallel::mclapply(ids,one,mc.cores=workers,mc.preschedule=FALSE,mc.set.seed=FALSE)
    for(k in seq_along(ids)){if(inherits(r[[k]],'try-error')||!is.list(r[[k]]))stop('Bootstrap worker failed outside model handling');results[[ids[k]]]<-r[[k]]}
    msg('BOOTSTRAP_PROGRESS',max(ids),'/',B,'available=',sum(vapply(results[seq_len(max(ids))],function(z)identical(z$status,'SUCCESS'),logical(1))))
  }
  status<-do.call(rbind,lapply(results,function(z)data.frame(replicate=z$replicate,status=z$status,message=z$message)))
  draws<-do.call(rbind,lapply(results,function(z)data.frame(replicate=z$replicate,draw_position=seq_along(z$indices),source_unit_key=u$unit_key[z$indices],group=as.character(u$group[z$indices]),cohort=as.character(u$cohort_factor[z$indices]))))
  raw<-do.call(rbind,lapply(results,function(z)z$rows));if(is.null(raw)){raw<-point[FALSE,];raw$replicate<-integer()}
  wt(status,file.path(out,'bootstrap_replicate_status.tsv'));wt(draws,file.path(out,'bootstrap_draws.tsv.gz'));wt(raw,file.path(out,'bootstrap_paired_effects_all.tsv.gz'))
  success<-sum(status$status=='SUCCESS');enough<-success>=ceiling(.95*B);summary<-point;summary$planned_replicates<-B;summary$successful_replicates<-success;summary$minimum_success_required<-ceiling(.95*B)
  summary$interval_status<-if(enough)'AVAILABLE_NOMINAL_PERCENTILE_95'else'UNAVAILABLE_INSUFFICIENT_SUCCESSFUL_REPLICATES'
  for(field in c('cohort_log2FC','IFN7_log2FC','delta_signed','absolute_reduction')){
    summary[[paste0(field,'_CI95_low')]]<-NA_real_;summary[[paste0(field,'_CI95_high')]]<-NA_real_
    if(enough)for(i in seq_len(nrow(summary))){values<-raw[raw$backend==summary$backend[i]&raw$gene_symbol==summary$gene_symbol[i],field];stopifnot(length(values)==success,all(is.finite(values)));ci<-quantile(values,c(.025,.975),names=FALSE,type=7);summary[i,paste0(field,c('_CI95_low','_CI95_high'))]<-as.list(ci)}
  }
  summary$relative_percentage_interval<-'not_estimated_ratio_is_descriptive_point_summary';summary$historical_selection_adjusted<-FALSE;wt(summary,file.path(out,'bootstrap_paired_summary4.tsv'))
  writeLines(c('Stratified patient draws pair both models and both methods. Fixed original 8335-gene universe; TMM and IFN7 recomputed in each resample.','Nominal percentile intervals describe within-study sampling uncertainty conditional on the observed universe and analytical choices.','No interval corrects historical candidate selection, establishes independent replication or estimates mediation. Percentage reductions remain descriptive point summaries.','Matched genes are selected only using main-cohort abundance, detection and common unambiguous annotation, never independent counts or eligibility.','External matched-coverage fractions and empirical positions are descriptive; no formal enrichment P values or explanation for sparsity.'),file.path(out,'INTERPRETATION.txt'))
  state<-if(!enough)'COMPLETED_WITH_INSUFFICIENT_BOOTSTRAP_SUPPORT'else if(success<B)'COMPLETED_WITH_UNAVAILABLE_REPLICATES'else'COMPLETED';writeLines(state,file.path(out,'RUN_STATUS.txt'));msg('DONE_06I',state,'successful=',success,'planned=',B)
}
tryCatch({main();capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))},error=function(e){writeLines(conditionMessage(e),file.path(out,'RUN_FAILED.txt'));capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'));msg('FAILED_06I',conditionMessage(e));quit(status=1)})
