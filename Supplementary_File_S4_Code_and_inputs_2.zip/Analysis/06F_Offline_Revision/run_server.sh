#!/usr/bin/env bash
set -Eeuo pipefail
CD06F_TASK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CD06F_PROJECT="${1:-/media/desk16/iy12923/消化/scmore/CD_scMORE}"
CD06F_PYTHON="${CD06F_PYTHON:-$(command -v python3 || true)}"
if [[ -z "$CD06F_PYTHON" ]]; then printf 'FAILED Python 3.8 or later is required.\n'; exit 1; fi
"$CD06F_PYTHON" -c 'import sys; assert sys.version_info >= (3,8), "Python 3.8 or later required"'
CD06F_ID="$(date +%Y%m%d_%H%M%S)_$$_${RANDOM}"
CD06F_RESULT_BASE="$CD06F_PROJECT/results/06F_offline_revision_20261106"
CD06F_OUT="$CD06F_RESULT_BASE/$CD06F_ID"
CD06F_ARCHIVE="$CD06F_PROJECT/CD_06F_RESULTS_${CD06F_ID}.zip"
mkdir -p "$CD06F_RESULT_BASE"
finish_06f() {
    CD06F_EXIT=$?
    trap - EXIT
    set +e
    "$CD06F_PYTHON" - "$CD06F_OUT" "$CD06F_ARCHIVE" "$CD06F_TASK_DIR" "$CD06F_EXIT" <<'PY'
import sys,zipfile
from pathlib import Path
out,archive,task=map(Path,sys.argv[1:4]);code=int(sys.argv[4])
out.mkdir(parents=True,exist_ok=True)
if code and not (out/'RUN_STATUS.txt').exists(): (out/'RUN_STATUS.txt').write_text('FAILED\n')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(out.rglob('*')):
        if p.is_file():z.write(p,out.name+'/'+str(p.relative_to(out)))
    for rel in ['06F_existing_results.py','run_server.sh','06F_ANALYSIS_SCOPE.json','inputs/INPUT_SHA256.tsv']:
        p=task/rel
        if p.is_file():z.write(p,out.name+'/executed_code/'+rel)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('ARCHIVE_COMPLETE',archive,flush=True)
PY
    CD06F_ARCHIVE_EXIT=$?
    if [[ "$CD06F_ARCHIVE_EXIT" -ne 0 && "$CD06F_EXIT" -eq 0 ]]; then CD06F_EXIT="$CD06F_ARCHIVE_EXIT"; fi
    printf 'EXIT_CODE=%s\nOUTPUT=%s\n' "$CD06F_EXIT" "$CD06F_OUT"
    if [[ -f "$CD06F_ARCHIVE" ]]; then printf 'RETURN_ZIP=%s\n' "$CD06F_ARCHIVE"; fi
    exit "$CD06F_EXIT"
}
trap finish_06f EXIT
printf 'START_06F=%s\nOUTPUT=%s\nPYTHON=%s\n' "$CD06F_ID" "$CD06F_OUT" "$CD06F_PYTHON"
printf 'MODE=OFFLINE_EXISTING_RESULTS_AND_DESCRIPTIVE_DIAGNOSTICS\nNo installation or download is performed.\n'
"$CD06F_PYTHON" -u "$CD06F_TASK_DIR/06F_existing_results.py" --input-dir "$CD06F_TASK_DIR/inputs" --out "$CD06F_OUT"
