#!/usr/bin/env python3
"""Offline hash verification and review-ZIP collection; standard library only."""
import argparse
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import zipfile

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action',choices=['verify','archive'])
    ap.add_argument('--package-dir',type=Path,required=True)
    ap.add_argument('--output',type=Path)
    ap.add_argument('--return-zip',type=Path)
    ap.add_argument('--log',type=Path)
    ap.add_argument('--exit-code',type=int,default=0)
    args=ap.parse_args();root=args.package_dir.resolve()
    if args.action=='verify':
        with (root/'SHA256SUMS.tsv').open(encoding='utf-8') as f:rows=list(csv.DictReader(f,delimiter='\t'))
        for r in rows:
            p=root/r['path']
            if not p.is_file() or p.stat().st_size!=int(r['size_bytes']) or digest(p)!=r['sha256']:raise ValueError('Package file changed: '+r['path'])
        print('PACKAGE_HASH_CHECKS_PASSED',len(rows),flush=True);return
    if args.output is None or args.return_zip is None:raise ValueError('Archive needs --output and --return-zip')
    destination=args.return_zip;destination.parent.mkdir(parents=True,exist_ok=True)
    if destination.exists():raise FileExistsError('Refusing to overwrite return ZIP')
    status={'phase':'06H2','exit_code':args.exit_code,'archived_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
            'scope':'Review actual generated files; an archive is not proof that R fits completed'}
    with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('06H2_RESULTS/ARCHIVE_STATUS.json',json.dumps(status,indent=2)+'\n')
        if args.output.exists():
            for p in sorted(args.output.rglob('*')):
                if p.is_file():z.write(p,'06H2_RESULTS/results/'+str(p.relative_to(args.output)))
        for name in ['06H2_clinical_adjustment.R','06E_external_validation_frozen.R','prepare_06H2_clinical.py','06H2_package_io.py','run_06H2.sh','SHA256SUMS.tsv','inputs/FROZEN_06H2_PLAN.json','inputs/PLANNED_06H2_ROWS32.tsv']:
            z.write(root/name,'06H2_RESULTS/executed_code/'+name)
        if args.log is not None and args.log.exists():z.write(args.log,'06H2_RESULTS/console.log')
    print('ARCHIVE_COMPLETE',destination,flush=True)

if __name__=='__main__':main()
