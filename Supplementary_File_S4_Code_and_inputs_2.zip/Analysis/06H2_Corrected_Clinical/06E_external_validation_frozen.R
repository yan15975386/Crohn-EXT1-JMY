#!/usr/bin/env Rscript
# Frozen independent-study follow-up. Public author labels; no adaptive rescue.
options(stringsAsFactors=FALSE,warn=1)
argv<-commandArgs(trailingOnly=TRUE)
if(length(argv)!=2L)stop('Expected input and output directories')
input_dir<-normalizePath(argv[1L],mustWork=TRUE);output_dir<-argv[2L]
dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
needed<-c('Matrix','edgeR','limma')
absent<-needed[!vapply(needed,requireNamespace,logical(1),quietly=TRUE)]
if(length(absent))stop('Missing installed packages: ',paste(absent,collapse=', '))
TARGET_GENES<-c('EXT1','JMY')
IFN7_GENES<-c('STAT1','IRF1','ISG15','MX2','GBP1','GBP2','GBP5')
COMPARTMENTS<-c('AUTHOR_MACROPHAGES','POOLED_AUTHOR_MACROPHAGES')
BACKENDS<-c('edgeR_QL','limma_voom')
write_tsv<-function(x,name)utils::write.table(x,file=file.path(output_dir,name),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
message_log<-function(...)cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),paste(...,collapse=' '),'\n')
bh_fixed_family<-function(p){q<-stats::p.adjust(ifelse(is.finite(p),p,1),'BH');q[!is.finite(p)]<-NA_real_;q}

read_compartment<-function(compartment_key,gene_table){
  unit_file<-file.path(input_dir,paste0('units_',compartment_key,'.tsv'))
  units<-utils::read.delim(unit_file,check.names=FALSE,colClasses=c(PubID='character'))
  connection<-gzfile(file.path(input_dir,paste0('counts_',compartment_key,'.mtx.gz')),'rt')
  raw_counts<-tryCatch(as(Matrix::readMM(connection),'dgCMatrix'),finally=try(close(connection),silent=TRUE))
  required<-c('PubID','Type','Chem','n_cells','unit_key')
  if(!all(required%in%names(units))||anyNA(units[,required,drop=FALSE])||anyDuplicated(units$PubID)||anyDuplicated(units$unit_key))stop('Invalid independent donor metadata: ',compartment_key)
  if(nrow(raw_counts)!=nrow(gene_table)||ncol(raw_counts)!=nrow(units))stop('Count/metadata dimensions differ')
  if(any(!is.finite(raw_counts@x))||any(raw_counts@x<0)||any(raw_counts@x!=floor(raw_counts@x)))stop('Raw counts must be nonnegative integers')
  if(any(Matrix::colSums(raw_counts)<=0)||any(units$n_cells<15L)||!all(units$Type%in%c('Heal','Infl'))||!all(units$Chem%in%c('v2','v3')))stop('Input eligibility differs from the frozen plan')
  group_counts<-table(factor(units$Type,levels=c('Heal','Infl')))
  frozen_sizes<-if(compartment_key=='AUTHOR_MACROPHAGES')c(5L,9L)else c(8L,9L)
  if(!identical(as.integer(group_counts),frozen_sizes))stop('Frozen clinical group sizes differ')
  rownames(raw_counts)<-gene_table$gene_id;colnames(raw_counts)<-units$unit_key
  list(counts=raw_counts,units=units)
}

candidate_rows<-function(full_table,backend_key,model_key,compartment_key,conditioned,n_case,n_reference,n_observations,residual_df){
  positions<-match(TARGET_GENES,as.character(full_table$gene_symbol))
  found<-!is.na(positions)
  values<-function(column){ans<-rep(NA_real_,length(TARGET_GENES));ans[found]<-full_table[[column]][positions[found]];ans}
  data.frame(model_id=model_key,compartment=compartment_key,IFN7_conditioned=conditioned,contrast='Infl_vs_Heal_TI',backend=backend_key,gene_symbol=TARGET_GENES,
    n_case=n_case,n_reference=n_reference,n_observations=n_observations,residual_df=residual_df,n_tested_genes=nrow(full_table),
    log2FC=values('logFC'),CI95_low=values('CI95_low'),CI95_high=values('CI95_high'),PValue=values('PValue'),genome_q=values('genome_q'),
    status=ifelse(found,'tested','not_tested_expression_filter'),detail='',interval_method=if(backend_key=='limma_voom')'moderated_t_from_same_voom_fit'else'not_reported_for_QL')
}

unavailable_rows<-function(model_key,compartment_key,conditioned,reason,n_case=NA_integer_,n_reference=NA_integer_){
  rows<-expand.grid(backend=BACKENDS,gene_symbol=TARGET_GENES,stringsAsFactors=FALSE)
  rows$model_id<-model_key;rows$compartment<-compartment_key;rows$IFN7_conditioned<-conditioned;rows$contrast<-'Infl_vs_Heal_TI'
  rows$n_case<-n_case;rows$n_reference<-n_reference
  for(column in c('n_observations','residual_df','n_tested_genes','log2FC','CI95_low','CI95_high','PValue','genome_q'))rows[[column]]<-NA_real_
  rows$status<-'unavailable';rows$detail<-reason
  rows$interval_method<-ifelse(rows$backend=='limma_voom','unavailable','not_reported_for_QL')
  rows
}

fit_model<-function(compartment_key,conditioned,source,gene_table){
  model_key<-paste(compartment_key,if(conditioned)'CHEM_IFN7'else'CHEM',sep='__')
  units<-source$units;raw_counts<-source$counts
  units$group<-factor(units$Type,levels=c('Heal','Infl'));units$Chem<-factor(units$Chem,levels=c('v2','v3'))
  n_case<-sum(units$Type=='Infl');n_reference<-sum(units$Type=='Heal')
  if(min(n_case,n_reference)<4L)stop('Fewer than four independent donors per group')
  y0<-edgeR::DGEList(counts=raw_counts)
  keep<-edgeR::filterByExpr(y0,group=units$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
  if(sum(keep)<100L)stop('Fewer than 100 expressed genes')
  y<-edgeR::calcNormFactors(y0[keep,,keep.lib.sizes=FALSE],method='TMM')
  if(conditioned){
    positions<-match(IFN7_GENES,gene_table$gene_symbol)
    if(anyNA(positions))stop('A fixed IFN7 member is missing')
    cpm<-sweep(as.matrix(raw_counts[positions,,drop=FALSE]),2,y$samples$lib.size*y$samples$norm.factors/1e6,'/')
    score<-colMeans(log2(1+cpm))
    if(!is.finite(sd(score))||sd(score)==0)stop('IFN7 score has no variation')
    units$IFN7_z<-as.numeric(scale(score))
  }
  formula<-if(conditioned)~Chem+IFN7_z+group else ~Chem+group
  design<-stats::model.matrix(formula,units);rownames(design)<-units$unit_key
  design_rank<-qr(design)$rank
  if(design_rank<ncol(design)||nrow(design)-ncol(design)<2L)stop('Nonidentifiable design or fewer than two residual degrees of freedom')
  coefficient_index<-match('groupInfl',colnames(design))
  if(is.na(coefficient_index))stop('Clinical group coefficient is missing')
  write_tsv(data.frame(unit_key=rownames(design),design,check.names=FALSE),paste0('design_',model_key,'.tsv'))
  units$effective_library_size<-y$samples$lib.size*y$samples$norm.factors
  write_tsv(units,paste0('units_',model_key,'.tsv'))
  y<-edgeR::estimateDisp(y,design=design)
  qfit<-edgeR::glmQLFit(y,design=design,robust=FALSE)
  qt<-as.data.frame(edgeR::topTags(edgeR::glmQLFTest(qfit,coef=coefficient_index),n=Inf,sort.by='none')$table)
  qt$gene_id<-rownames(qt);qt$gene_symbol<-gene_table$gene_symbol[match(qt$gene_id,gene_table$gene_id)]
  qt$genome_q<-stats::p.adjust(qt$PValue,'BH');qt$CI95_low<-NA_real_;qt$CI95_high<-NA_real_
  v<-limma::voom(y,design=design,plot=FALSE)
  vf<-limma::eBayes(limma::lmFit(v,design),robust=FALSE)
  vt<-as.data.frame(limma::topTable(vf,coef=coefficient_index,number=Inf,sort.by='none',confint=.95))
  vt$gene_id<-rownames(vt);vt$gene_symbol<-gene_table$gene_symbol[match(vt$gene_id,gene_table$gene_id)]
  vt$PValue<-vt$P.Value;vt$genome_q<-stats::p.adjust(vt$PValue,'BH');vt$CI95_low<-vt$CI.L;vt$CI95_high<-vt$CI.R
  output<-list()
  for(backend_key in BACKENDS){
    full<-if(backend_key=='edgeR_QL')qt else vt
    if(any(!is.finite(full$PValue)))stop('Nonfinite full-transcriptome P values')
    write_tsv(full,paste0('ALL_genes_',model_key,'_',backend_key,'.tsv'))
    output[[backend_key]]<-candidate_rows(full,backend_key,model_key,compartment_key,conditioned,n_case,n_reference,nrow(design),nrow(design)-ncol(design))
  }
  do.call(rbind,output)
}

run_contract_checks<-function(){
  checks<-list()
  p<-c(.001,.02,rep(NA_real_,14L));q<-bh_fixed_family(p)
  checks[['fixed_family_preserves_16_rows']]<-length(q)==16L&&isTRUE(all.equal(q[1:2],c(.016,.16)))&&all(is.na(q[3:16]))
  fake<-data.frame(gene_symbol='EXT1',logFC=.3,CI95_low=.1,CI95_high=.5,PValue=.01,genome_q=.04)
  extracted<-candidate_rows(fake,'limma_voom','fixture','AUTHOR_MACROPHAGES',FALSE,9L,5L,14L,11L)
  checks[['matching_own_interval_and_missing_target_status']]<-extracted$CI95_low[1L]==.1&&extracted$log2FC[1L]==.3&&extracted$status[2L]=='not_tested_expression_filter'&&is.na(extracted$PValue[2L])
  missing<-unavailable_rows('fixture','AUTHOR_MACROPHAGES',TRUE,'synthetic contract fixture')
  checks[['unavailable_retains_two_genes_and_two_methods']]<-nrow(missing)==4L&&all(is.na(missing$PValue))&&all(missing$status=='unavailable')
  tab<-data.frame(check=names(checks),passed=unlist(checks,use.names=FALSE),kind='SYNTHETIC_CODE_CONTRACT_NOT_RNA_RESULTS')
  write_tsv(tab,'R_contract_checks.tsv')
  if(!all(tab$passed))stop('R code-contract check failed')
  message_log('R_CONTRACT_CHECKS_PASSED',nrow(tab),'SYNTHETIC_CODE_CONTRACT_NOT_RNA_RESULTS')
}

main<-function(){
  run_contract_checks()
  genes<-utils::read.delim(file.path(input_dir,'genes.tsv'),check.names=FALSE)
  if(anyDuplicated(genes$gene_id)||anyDuplicated(genes$gene_symbol)||anyNA(match(c(TARGET_GENES,IFN7_GENES),genes$gene_symbol)))stop('Invalid frozen gene identities')
  ledger<-list()
  for(compartment_key in COMPARTMENTS){
    source<-read_compartment(compartment_key,genes)
    for(conditioned in c(FALSE,TRUE)){
      model_key<-paste(compartment_key,if(conditioned)'CHEM_IFN7'else'CHEM',sep='__');message_log('FIT',model_key)
      result<-tryCatch(fit_model(compartment_key,conditioned,source,genes),error=function(error){message_log('MODEL_UNAVAILABLE',model_key,conditionMessage(error));unavailable_rows(model_key,compartment_key,conditioned,conditionMessage(error),sum(source$units$Type=='Infl'),sum(source$units$Type=='Heal'))})
      ledger[[model_key]]<-result
      write_tsv(do.call(rbind,ledger),'candidate_progress.tsv')
    }
  }
  result<-do.call(rbind,ledger)
  if(nrow(result)!=16L||anyDuplicated(paste(result$model_id,result$backend,result$gene_symbol,sep='::')))stop('Frozen 16-row plan was not preserved')
  planned<-utils::read.delim(file.path(input_dir,'PLANNED_16_ROWS.tsv'),check.names=FALSE)
  keys<-function(x)paste(x$model_id,x$backend,x$gene_symbol,sep='::')
  if(nrow(planned)!=16L||!setequal(keys(result),keys(planned)))stop('Output keys differ from the frozen input ledger')
  result$q_exploratory_union16<-bh_fixed_family(result$PValue);result$family_size<-16L
  result$population_role<-ifelse(result$compartment=='AUTHOR_MACROPHAGES','primary_author_compartment','pooled_compartment_sensitivity')
  write_tsv(result,'Table_06E_independent_candidate_results16.tsv')
  ci<-result[result$backend=='limma_voom'&is.finite(result$CI95_low)&is.finite(result$CI95_high),,drop=FALSE]
  if(nrow(ci)){
    grDevices::pdf(file.path(output_dir,'Independent_candidate_voom_intervals.pdf'),width=9,height=6,onefile=TRUE)
    for(gene_key in TARGET_GENES){
      a<-ci[ci$gene_symbol==gene_key,,drop=FALSE]
      if(!nrow(a))next
      label<-paste(ifelse(a$compartment=='AUTHOR_MACROPHAGES','Author Macrophages','Pooled macrophages'),ifelse(a$IFN7_conditioned,'chemistry + IFN7','chemistry'),sep=' | ')
      graphics::par(mar=c(4.5,15,3,2));at<-seq_len(nrow(a));range_x<-range(c(0,a$CI95_low,a$CI95_high))
      graphics::plot(a$log2FC,at,xlim=range_x,ylim=c(.5,nrow(a)+.5),yaxt='n',ylab='',xlab='Voom coefficient and its 95% confidence interval',main=paste(gene_key,'independent terminal ileum contrast'),pch=19,col='#24516D')
      graphics::abline(v=0,lty=2,col='gray60');graphics::segments(a$CI95_low,at,a$CI95_high,at,col='#24516D',lwd=1.5);graphics::axis(2,at=at,labels=label,las=1,cex.axis=.8)
    }
    grDevices::dev.off()
  }
  writeLines(c('Independent study, terminal ileum Infl versus Heal, using author annotations.','The author Macrophages label is not asserted to equal IBDverse CD163-hi.','Sex and age were not available in the public cell metadata; chemistry adjustment does not replace them.','Processing layer partly tracks chemistry; unmeasured clinical and technical differences remain.','IFN7 conditioning changes the estimand and is not causal mediation or proof of independence.','The 16 rows are correlated method/compartment sensitivities, not 16 independent studies.','All prespecified rows remain; there is no outcome-selected replacement population or relaxed expression filter.'),file.path(output_dir,'INTERPRETATION.txt'))
  writeLines(if(any(result$status=='unavailable'))'COMPLETED_WITH_UNAVAILABLE_MODELS'else'COMPLETED',file.path(output_dir,'RUN_STATUS.txt'))
  message_log('DONE_06E','planned_rows',nrow(result),'tested_rows',sum(result$status=='tested'))
}
tryCatch({main();capture.output(sessionInfo(),file=file.path(output_dir,'R_sessionInfo.txt'))},error=function(error){writeLines(conditionMessage(error),file.path(output_dir,'RUN_FAILED.txt'));capture.output(sessionInfo(),file=file.path(output_dir,'R_sessionInfo.txt'));message_log('FAILED_06E',conditionMessage(error));quit(status=1L)})
