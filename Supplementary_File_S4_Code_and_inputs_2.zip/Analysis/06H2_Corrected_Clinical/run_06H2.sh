#!/usr/bin/env bash
set -euo pipefail
ROOT06H2=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
OUT06H2=${1:?Expected a fresh output directory}
RETURN06H2=${2:?Expected an absolute return ZIP path}
LOG06H2=${3:-}
PYTHON06H2=${PYTHON06H2:-python3}
RSCRIPT06H2=${RSCRIPT06H2:-/usr/local/bin/Rscript}
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
finish_06H2() {
  RC06H2=$?
  trap - EXIT
  ARCHIVE_ARGS06H2=(archive --package-dir "$ROOT06H2" --output "$OUT06H2" --return-zip "$RETURN06H2" --exit-code "$RC06H2")
  if [[ -n "$LOG06H2" ]]; then ARCHIVE_ARGS06H2+=(--log "$LOG06H2"); fi
  "$PYTHON06H2" "$ROOT06H2/06H2_package_io.py" "${ARCHIVE_ARGS06H2[@]}" || { printf 'ARCHIVE_FAILED\n'; exit 1; }
  printf 'RETURN_ZIP=%s\nEXIT_CODE=%s\nOUTPUT=%s\n' "$RETURN06H2" "$RC06H2" "$OUT06H2"
  exit "$RC06H2"
}
trap finish_06H2 EXIT
printf 'START_06H2=%s\nPACKAGE=%s\nOUTPUT=%s\n' "$(date +%Y%m%d_%H%M%S)" "$ROOT06H2" "$OUT06H2"
"$PYTHON06H2" "$ROOT06H2/06H2_package_io.py" verify --package-dir "$ROOT06H2"
"$PYTHON06H2" "$ROOT06H2/prepare_06H2_clinical.py" --package-dir "$ROOT06H2" --output "$OUT06H2/metadata_reproduced"
"$PYTHON06H2" - "$ROOT06H2" "$OUT06H2/metadata_reproduced" <<'PY'
import pathlib,sys,hashlib
root,out=map(pathlib.Path,sys.argv[1:])
for c in ('AUTHOR_MACROPHAGES','POOLED_AUTHOR_MACROPHAGES'):
    name='units_clinical_'+c+'.tsv'
    a,b=(root/'inputs'/name).read_bytes(),(out/name).read_bytes()
    if a!=b:raise ValueError('Clinical metadata did not reproduce: '+name)
print('CLINICAL_INPUTS_EXACTLY_REPRODUCED 31_UNITS',flush=True)
PY
if [[ ! -x "$RSCRIPT06H2" ]]; then RSCRIPT06H2=$(command -v Rscript || true); fi
if [[ -z "$RSCRIPT06H2" ]]; then printf 'FAILED_06H2 Rscript not found; no installation attempted\n'; exit 1; fi
printf 'RSCRIPT=%s\n' "$RSCRIPT06H2"
"$RSCRIPT06H2" -e 'if(!all(vapply(c("Matrix","edgeR","limma"),requireNamespace,logical(1),quietly=TRUE)))stop("Missing previously installed R packages");invisible(parse(file=commandArgs(TRUE)[1]));cat("R_PARSE_PASSED\n")' "$ROOT06H2/06H2_clinical_adjustment.R"
"$RSCRIPT06H2" "$ROOT06H2/06H2_clinical_adjustment.R" "$ROOT06H2/inputs" "$OUT06H2/R_results"
