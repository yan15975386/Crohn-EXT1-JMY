#!/usr/bin/env python3
"""Exact channel-based clinical join; standard library only, no RNA-model fits."""
import argparse
import collections
import csv
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import xml.etree.ElementTree as ET
import zipfile

NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
COMPARTMENTS = ("AUTHOR_MACROPHAGES", "POOLED_AUTHOR_MACROPHAGES")
EXPECTED_XLSX = "edda31d86501602beaa3ce8417e01adec922e019504b3a12ffc4c621dc2725eb"
EXPECTED_PDF = "d471a0bbaaf7bac0f079c789f7ae752610acd1d114f0264e973e529ab50d2a8a"


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def read_tsv(path):
    with Path(path).open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def write_tsv(path, rows, fields=None):
    rows = list(rows)
    fields = fields or list(dict.fromkeys(k for r in rows for k in r))
    with Path(path).open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter="\t", lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def read_xlsx(path, formula_checks=None):
    """Read stored worksheet values without editing or recalculating the source."""
    if not zipfile.is_zipfile(path):
        raise ValueError("Not an XLSX ZIP container")
    sheets = {}
    with zipfile.ZipFile(path) as z:
        strings = []
        if "xl/sharedStrings.xml" in z.namelist():
            strings = ["".join(t.text or "" for t in si.findall(".//s:t", NS))
                       for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("s:si", NS)]
        rels = {x.attrib["Id"]: x.attrib["Target"] for x in ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
                if x.get("TargetMode") != "External"}
        for sheet in ET.fromstring(z.read("xl/workbook.xml")).findall("s:sheets/s:sheet", NS):
            name = sheet.attrib["name"]
            target = rels[sheet.attrib[RID]]
            target = target.lstrip("/") if target.startswith("/") else "xl/" + target
            if ".." in PurePosixPath(target).parts:
                raise ValueError("Unexpected worksheet path")
            headers = None
            records = []
            formula_cells, stored_values, shared_formulas = [], {}, {}
            for row in ET.fromstring(z.read(target)).findall("s:sheetData/s:row", NS):
                cells = {}
                for c in row.findall("s:c", NS):
                    formula = c.find("s:f", NS)
                    if formula is not None:
                        formula_cells.append((c.attrib["r"], formula.text, dict(formula.attrib)))
                        if formula.text and formula.get("t") == "shared":
                            shared_formulas[formula.attrib["si"]] = (c.attrib["r"], formula.text)
                    col = re.sub(r"[0-9]", "", c.attrib["r"])
                    v = c.find("s:v", NS)
                    value = (v.text if v is not None else "".join(t.text or "" for t in c.findall(".//s:t", NS))) or ""
                    cells[col] = strings[int(value)] if c.get("t") == "s" else value
                    stored_values[c.attrib["r"]] = cells[col]
                if row.attrib["r"] == "1":
                    headers = cells
                    if not all(headers.values()) or len(set(headers.values())) != len(headers):
                        raise ValueError("Blank or duplicate worksheet header")
                elif any(cells.values()):
                    if headers is None:
                        raise ValueError("Missing first-row headers")
                    record = {h: cells.get(c, "").strip() for c, h in headers.items()}
                    record["source_sheet"] = name
                    record["source_xlsx_row"] = int(row.attrib["r"])
                    records.append(record)
            for cell, formula_text, attrs in formula_cells:
                anchor = cell
                if not formula_text:
                    if attrs.get("t") != "shared" or attrs.get("si") not in shared_formulas:
                        raise ValueError("Unresolved shared formula: " + name + "!" + cell)
                    anchor, formula_text = shared_formulas[attrs["si"]]
                match = re.fullmatch(r'IF\(C([0-9]+)="NA",\s*"Heal",\s*"CD"\)', formula_text)
                if name != "Donors (Patients) - corrected" or not match or not re.fullmatch(r"B[0-9]+", cell):
                    raise ValueError("Unreviewed formula: " + name + "!" + cell)
                if int(match.group(1)) != int(anchor[1:]):
                    raise ValueError("Unexpected formula reference offset")
                precedent = "C" + cell[1:]
                expected = "Heal" if stored_values.get(precedent, "") == "NA" else "CD"
                if stored_values[cell] != expected:
                    raise ValueError("Stale formula cache: " + name + "!" + cell)
                if formula_checks is not None:
                    formula_checks.append(dict(sheet=name,cell=cell,precedent=precedent,cached_value=stored_values[cell],independently_evaluated_value=expected,passed=True))
            sheets[name] = records
    return sheets


def prefix_column(rows, prefix):
    names = [k for k in rows[0] if " ".join(k.split()).startswith(prefix)]
    if len(names) != 1:
        raise ValueError("Expected exactly one column: " + prefix)
    return names[0]


def unique_index(rows, key):
    result = {}
    for row in rows:
        value = row[key]
        if not value or value in result:
            raise ValueError("Missing/duplicate identifier in " + key)
        result[value] = row
    return result


def rank(matrix, tolerance=1e-10):
    """Gaussian elimination for small metadata-only design matrices."""
    a = [list(map(float, row)) for row in matrix]
    n, p = len(a), len(a[0])
    used = 0
    for col in range(p):
        if used == n:
            break
        pivot = max(range(used, n), key=lambda i: abs(a[i][col]))
        if abs(a[pivot][col]) <= tolerance:
            continue
        a[used], a[pivot] = a[pivot], a[used]
        scale = a[used][col]
        a[used] = [v / scale for v in a[used]]
        for i in range(used + 1, n):
            scale = a[i][col]
            a[i] = [x - scale * y for x, y in zip(a[i], a[used])]
        used += 1
    return used


def model_id(compartment, conditioned, clinical=True):
    suffix = "CHEM_SEX_AGEBAND" if clinical else "CHEM"
    return compartment + "__" + suffix + ("_IFN7" if conditioned else "")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--package-dir", type=Path, default=Path(__file__).resolve().parent)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    root, out = args.package_dir.resolve(), args.output.resolve()
    if out.exists() and any(out.iterdir()):
        raise ValueError("Choose a fresh metadata audit directory")
    out.mkdir(parents=True, exist_ok=True)
    xlsx, pdf = root / "public_sources/mmc2.xlsx", root / "public_sources/PIIS1074761323000122.pdf"
    if digest(xlsx) != EXPECTED_XLSX or digest(pdf) != EXPECTED_PDF:
        raise ValueError("Uploaded primary-source bytes changed")
    formula_checks = []
    sheets = read_xlsx(xlsx, formula_checks)
    write_tsv(out / "Table_06H2_source_formula_cache_checks.tsv", formula_checks)
    expected_sheets = {"Donors (Patients) - corrected", "Samples", "Fractions (Channels)"}
    if set(sheets) != expected_sheets:
        raise ValueError("Unexpected Table S1 sheet structure")
    donors, samples, channels = (sheets[k] for k in ("Donors (Patients) - corrected", "Samples", "Fractions (Channels)"))
    sample_index = unique_index(samples, "Sample.ID")
    channel_index = unique_index(channels, "Channel.ID")
    donor_index = collections.defaultdict(list)
    for r in donors:
        donor_index[r["Donor.ID"]].append(r)
    donor_type = prefix_column(donors, "Type (")
    type_c, site_c, chem_c, layer_c = (prefix_column(channels, p) for p in ("Type (", "Site (", "10x Genomics Chemistry", "Layer information"))
    sample_type, sample_site, sample_chem = (prefix_column(samples, p) for p in ("Type (", "Site (", "10x Genomics Chemistry"))
    with gzip.open(root / "inputs/selected_cells.tsv.gz", "rt", encoding="utf-8", newline="") as f:
        selected = list(csv.DictReader(f, delimiter="\t"))
    if len({r["cell_id"] for r in selected}) != 6304:
        raise ValueError("Frozen selected-cell union differs")
    selected_channel_meta = {}
    for r in selected:
        key = r["PubIDSample"]
        m = {k: r[k] for k in ("PubID", "Type", "Chem", "Site", "Layer")}
        if key in selected_channel_meta and selected_channel_meta[key] != m:
            raise ValueError("Nonconstant author channel metadata")
        selected_channel_meta[key] = m
    rows = []
    common_fields = [k for k in samples[0] if k in channels[0] and k not in ("source_sheet", "source_xlsx_row", "Notes")]
    for key in sorted(selected_channel_meta):
        a = selected_channel_meta[key]
        if key not in channel_index:
            raise ValueError("Selected channel absent from clinical Table S1: " + key)
        c = channel_index[key]
        s = sample_index[c["Sample.ID"]]
        disagreements = [k for k in common_fields if c[k] != s[k]]
        if disagreements:
            raise ValueError("Sample/channel disagreement: " + key + " " + ", ".join(disagreements))
        if not (c["Donor.ID"] == a["PubID"] == s["Donor.ID"] and c[type_c] == a["Type"] and
                c[chem_c] == a["Chem"] and c[site_c] == a["Site"] == "TI"):
            raise ValueError("Clinical donor/group/site/chemistry differs from the frozen channel: " + key)
        if {"epithelium (E)": "E", "lamina propria (L)": "L", "not separated (N)": "N"}.get(c[layer_c]) != a["Layer"]:
            raise ValueError("Processing layer differs: " + key)
        if c["Sex"] not in ("Female", "Male") or not re.fullmatch(r"[0-9]+-[0-9]+", c["Age group"]):
            raise ValueError("Missing or unsupported age/sex: " + key)
        lo, hi = map(int, c["Age group"].split("-"))
        if hi - lo != 4:
            raise ValueError("Unexpected age-interval width: " + key)
        expected_donor_type = "Heal" if a["Type"] == "Heal" else "CD"
        compatible = [d for d in donor_index[c["Donor.ID"]] if d["Age group"] == c["Age group"] and d["Sex"] == c["Sex"] and d[donor_type] == expected_donor_type]
        if not compatible:
            raise ValueError("Corrected donor rows do not corroborate channel age/sex: " + key)
        rows.append(dict(Channel_ID=key, Sample_ID=c["Sample.ID"], PubID=c["Donor.ID"], Type=a["Type"], Chem=a["Chem"], Site=a["Site"],
                         Age_band=c["Age group"], Sex=c["Sex"], channel_xlsx_row=c["source_xlsx_row"], sample_xlsx_row=s["source_xlsx_row"],
                         corroborating_corrected_donor_rows="|".join(str(d["source_xlsx_row"]) for d in compatible),
                         donor_ID_records_in_corrected_sheet=len(donor_index[c["Donor.ID"]]),
                         age_sex_corroborating_records=len(compatible), exact_channel_and_sample_join=True,
                         common_sample_channel_fields_checked=len(common_fields), common_sample_channel_disagreements=0))
    write_tsv(out / "Table_06H2_selected_channel_crosswalk30.tsv", rows)
    by_channel = {r["Channel_ID"]: r for r in rows}
    by_donor = collections.defaultdict(list)
    for r in rows:
        by_donor[r["PubID"]].append(r)
    for pubid, r in by_donor.items():
        if len({x["Age_band"] for x in r}) != 1 or len({x["Sex"] for x in r}) != 1:
            raise ValueError("Selected channels pool inconsistent age/sex within a donor: " + pubid)
    coverage, design_summary, overlaps, unit_rows = [], [], [], []
    for comp in COMPARTMENTS:
        original = read_tsv(root / ("inputs/units_" + comp + ".tsv"))
        expanded = []
        for u in original:
            chosen_cells = [r for r in selected if r["compartment"] == comp and r["PubID"] == u["PubID"]]
            if len(chosen_cells) != int(u["n_cells"]):
                raise ValueError("Frozen per-unit selected-cell count differs")
            ids = sorted({r["PubIDSample"] for r in chosen_cells})
            clinical = [by_channel[k] for k in ids]
            if len({r["Age_band"] for r in clinical}) != 1 or len({r["Sex"] for r in clinical}) != 1:
                raise ValueError("Unit clinical assignment is not unique")
            e = dict(u, Age_band=clinical[0]["Age_band"], Sex=clinical[0]["Sex"], n_clinical_channels=len(ids),
                     n_biological_sample_ids=len({r["Sample_ID"] for r in clinical}), source_channels="|".join(ids),
                     source_sample_ids="|".join(sorted({r["Sample_ID"] for r in clinical})),
                     source_channel_xlsx_rows="|".join(str(r["channel_xlsx_row"]) for r in clinical))
            expanded.append(e)
            unit_rows.append(dict(compartment=comp, **e))
        write_tsv(out / ("units_clinical_" + comp + ".tsv"), expanded)
        levels = sorted({r["Age_band"] for r in expanded}, key=lambda s: int(s.split("-")[0]))
        reference_scores = {r["unit_key"]: float(r["IFN7_z"]) for r in read_tsv(root / ("reference_baseline/units_" + comp + "__CHEM_IFN7.tsv"))}
        for conditioned in (False, True):
            names = ["(Intercept)", "Chemv3", "SexMale"] + ["Age_band" + level for level in levels[1:]]
            if conditioned:
                names.append("IFN7_z")
            names.append("groupInfl")
            values = []
            for u in expanded:
                row = [1, int(u["Chem"] == "v3"), int(u["Sex"] == "Male")] + [int(u["Age_band"] == level) for level in levels[1:]]
                if conditioned:
                    row.append(reference_scores[u["unit_key"]])
                row.append(int(u["Type"] == "Infl"))
                values.append(row)
            mid = model_id(comp, conditioned)
            observed_rank = rank(values)
            design_summary.append(dict(model_id=mid, compartment=comp, IFN7_conditioned=conditioned, n_donors=len(expanded),
                                       n_parameters=len(names), rank=observed_rank, nominal_residual_df=len(expanded)-observed_rank,
                                       full_rank=observed_rank == len(names), age_band_levels="|".join(levels),
                                       age_treatment="categorical_original_intervals_no_midpoint"))
            if observed_rank != len(names) or len(expanded) - observed_rank < 2:
                raise ValueError("Unidentifiable prespecified clinical design: " + mid)
            write_tsv(out / ("preflight_design_" + mid + ".tsv"), [dict(unit_key=u["unit_key"], **dict(zip(names,v))) for u,v in zip(expanded,values)])
        coverage.append(dict(compartment=comp, donors=len(expanded), healthy=sum(u["Type"] == "Heal" for u in expanded), inflamed=sum(u["Type"] == "Infl" for u in expanded), clinical_mapped_donors=len(expanded)))
        for level in levels:
            sub = [u for u in expanded if u["Age_band"] == level]
            nh, ni = sum(u["Type"] == "Heal" for u in sub), sum(u["Type"] == "Infl" for u in sub)
            overlaps.append(dict(compartment=comp, Age_band=level, healthy=nh, inflamed=ni, both_groups_present=bool(nh and ni),
                                 interpretation="few overlapping age strata; full rank is not proof of adequate overlap"))
    write_tsv(out / "Table_06H2_analysis_units31.tsv", unit_rows)
    write_tsv(out / "Table_06H2_cohort_coverage.tsv", coverage)
    write_tsv(out / "Table_06H2_design_preflight.tsv", design_summary)
    write_tsv(out / "Table_06H2_age_band_group_overlap.tsv", overlaps)
    old = {r["PubID"]:r for r in read_tsv(root / "reference_baseline/HCA_previous_crosswalk17.tsv")}
    comparison = []
    for pubid in sorted(by_donor):
        new, previous = by_donor[pubid][0], old[pubid]
        old_age, old_sex = previous["HCA_age_as_recorded_unverified"], previous["HCA_sex_as_recorded_unverified"]
        comparison.append(dict(PubID=pubid, previous_HCA_age=old_age, previous_HCA_sex=old_sex,
                               channel_Age_band=new["Age_band"], channel_Sex=new["Sex"],
                               previous_HCA_present=bool(old_age and old_sex),
                               age_band_differs=bool(old_age) and old_age != new["Age_band"],
                               sex_differs=bool(old_sex) and old_sex.lower() != new["Sex"].lower(),
                               clinical_model_source="uploaded_TableS1_exact_channel_records"))
    write_tsv(out / "Table_06H2_previous_HCA_comparison17.tsv", comparison)
    donor_occurrences = collections.Counter(d["Donor.ID"] for d in donors)
    status = dict(phase="06H2", audit_completed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                  source_xlsx_sha256=digest(xlsx), source_pdf_sha256=digest(pdf),
                  primary_correction_in_uploaded_PDF_page=23,
                  source_mode="user-provided public publisher PDF and supplement; download URL not independently fetched",
                  corrected_donor_sheet_present=True, source_donor_rows=len(donors), source_unique_donor_ids=len(donor_index),
                  source_sample_rows=len(samples), source_channel_rows=len(channels),
                  repeated_donor_ids={k:v for k,v in donor_occurrences.items() if v>1},
                  selected_channels_total=len(rows), selected_channels_exactly_matched=len(rows),
                  selected_unique_donors=len(by_donor), selected_donors_clinically_mapped=len(by_donor),
                  selected_cells_unique=6304, analysis_units_total=len(unit_rows),
                  previous_HCA_comparable_donors=sum(r["previous_HCA_present"] for r in comparison),
                  previous_HCA_age_band_differences=sum(r["age_band_differs"] for r in comparison),
                  previous_HCA_sex_differences=sum(r["sex_differs"] for r in comparison),
                  corrected_104152_selected_age_band=by_donor["104152"][0]["Age_band"],
                  clinical_assignment_resolved_for_frozen_analysis=True, clinical_covariates_used_in_new_RNA_models=False,
                  exact_age_or_midpoint_imputed=False, participant_population_or_expression_filter_changed=False,
                  new_RNA_models_fitted=0, R_fits_status="PENDING_SERVER_EXECUTION",
                  RUN_STATUS="CLINICAL_MAPPING_COMPLETE_R_FITS_PENDING")
    (out / "06H2_METADATA_STATUS.json").write_text(json.dumps(status,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    checks = [
        ("uploaded_primary_source_hashes_verified",digest(xlsx)==EXPECTED_XLSX and digest(pdf)==EXPECTED_PDF),
        ("all_30_selected_channels_exactly_matched",len(rows)==30),
        ("all_17_selected_donors_have_consistent_channel_age_sex",len(by_donor)==17),
        ("sample_and_channel_fields_concordant",all(r["common_sample_channel_disagreements"]==0 for r in rows)),
        ("corrected_donor_records_corroborate_selected_channel_age_sex",all(r["age_sex_corroborating_records"]>0 for r in rows)),
        ("all_31_frozen_analysis_units_and_cell_counts_retained",len(unit_rows)==31),
        ("all_four_clinical_designs_full_rank_at_least_two_residual_df",len(design_summary)==4 and all(r["full_rank"] and r["nominal_residual_df"]>=2 for r in design_summary)),
        ("104152_uses_selected_channel_visit_not_first_donor_merge",by_donor["104152"][0]["Age_band"]=="35-39"),
        ("no_age_midpoint_or_expression_model_generated",not status["exact_age_or_midpoint_imputed"] and status["new_RNA_models_fitted"]==0),
    ]
    write_tsv(out / "06H2_actual_metadata_checks.tsv", [dict(check=k,passed=v,scope="ACTUAL_PUBLIC_SOURCE_AND_FROZEN_INPUTS_NOT_RNA_RESULTS") for k,v in checks])
    if not all(v for k,v in checks):
        raise ValueError("Actual metadata check failed")
    print(json.dumps(status,ensure_ascii=False,indent=2),flush=True)
    print("METADATA_CHECKS_PASSED",len(checks),"ACTUAL_DATA_ONLY",flush=True)


if __name__ == "__main__":
    main()
