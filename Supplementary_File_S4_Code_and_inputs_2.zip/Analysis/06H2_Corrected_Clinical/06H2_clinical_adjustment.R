#!/usr/bin/env Rscript
# Corrected public Table S1 follow-up; no adaptive populations or expression filters.
options(stringsAsFactors=FALSE,warn=1,contrasts=c('contr.treatment','contr.poly'))
argv <- commandArgs(trailingOnly=TRUE)
if(length(argv)!=2L) stop('Expected input and output directories')
input_dir <- normalizePath(argv[1L],mustWork=TRUE)
output_dir <- argv[2L]
package_dir <- normalizePath(file.path(input_dir,'..'),mustWork=TRUE)
dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
TARGET_GENES <- c('EXT1','JMY')
IFN7_GENES <- c('STAT1','IRF1','ISG15','MX2','GBP1','GBP2','GBP5')
COMPARTMENTS <- c('AUTHOR_MACROPHAGES','POOLED_AUTHOR_MACROPHAGES')
BACKENDS <- c('edgeR_QL','limma_voom')
write_tsv <- function(x,name) utils::write.table(x,file.path(output_dir,name),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
message_log <- function(...) cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),paste(...,collapse=' '),'\n')
model_key <- function(compartment,conditioned,clinical=TRUE) paste0(compartment,'__',if(clinical)'CHEM_SEX_AGEBAND'else'CHEM',if(conditioned)'_IFN7'else'')
DESIGN_RECORDS <- list()

load_frozen_functions <- function(){
  needed <- c('Matrix','edgeR','limma')
  absent <- needed[!vapply(needed,requireNamespace,logical(1),quietly=TRUE)]
  if(length(absent)) stop('Missing installed packages: ',paste(absent,collapse=', '),'; no package installation is attempted')
  # Import only the unchanged function definitions. Never evaluate the old driver.
  imports <- c('read_compartment','candidate_rows','unavailable_rows','fit_model','bh_fixed_family')
  expressions <- parse(file.path(package_dir,'06E_external_validation_frozen.R'))
  found <- character()
  for(term in expressions){
    if(is.call(term)&&identical(term[[1L]],as.name('<-'))&&is.symbol(term[[2L]])){
      name <- as.character(term[[2L]])
      if(name%in%imports){
        if(!is.call(term[[3L]])||!identical(term[[3L]][[1L]],as.name('function'))) stop('Frozen import is not a function')
        eval(term,envir=.GlobalEnv)
        found <- c(found,name)
      }
    }
  }
  if(!setequal(found,imports)||anyDuplicated(found)) stop('Frozen function definitions differ')
  message_log('FROZEN_06E_FUNCTIONS_IMPORTED',paste(found,collapse=','))
}

compare_full_baseline <- function(key,backend){
  name <- paste0('ALL_genes_',key,'_',backend,'.tsv')
  old <- utils::read.delim(file.path(package_dir,'reference_baseline',name),check.names=FALSE)
  current <- utils::read.delim(file.path(output_dir,name),check.names=FALSE)
  if(anyDuplicated(old$gene_id)||anyDuplicated(current$gene_id)||!setequal(old$gene_id,current$gene_id)) stop('Baseline tested-gene set differs: ',name)
  current <- current[match(old$gene_id,current$gene_id),,drop=FALSE]
  if(!identical(as.character(current$gene_symbol),as.character(old$gene_symbol))) stop('Baseline gene symbols differ')
  columns <- c('logFC','PValue','genome_q','CI95_low','CI95_high')
  if(!all(columns%in%names(current))||!all(columns%in%names(old))) stop('Baseline schema differs')
  checks <- list()
  for(column in columns){
    a <- as.numeric(current[[column]]); b <- as.numeric(old[[column]])
    masks_match <- identical(is.na(a),is.na(b))
    ok <- is.finite(a)&is.finite(b)
    difference <- abs(a[ok]-b[ok])
    pass <- masks_match&&all(difference<=1e-8+1e-6*abs(b[ok]))
    checks[[column]] <- data.frame(model_id=key,backend=backend,column=column,n_genes=nrow(old),n_finite_pairs=sum(ok),
                                  max_absolute_difference=if(any(ok))max(difference)else NA_real_,passed=pass,
                                  scope='ACTUAL_PREVIOUS_FULL_GENE_TABLE_REPRODUCTION')
  }
  do.call(rbind,checks)
}

load_clinical_units <- function(compartment,original){
  units <- utils::read.delim(file.path(input_dir,paste0('units_clinical_',compartment,'.tsv')),check.names=FALSE,colClasses=c(PubID='character'))
  if(anyDuplicated(units$unit_key)||!setequal(units$unit_key,original$unit_key)) stop('Clinical unit keys differ')
  units <- units[match(original$unit_key,units$unit_key),,drop=FALSE]
  for(column in names(original)) if(!identical(as.character(units[[column]]),as.character(original[[column]]))) stop('Frozen unit column changed: ',column)
  if(anyNA(units[,c('Age_band','Sex')])||any(!units$Sex%in%c('Female','Male'))||any(!grepl('^[0-9]+-[0-9]+$',units$Age_band))) stop('Invalid corrected age/sex')
  units$group <- factor(units$Type,levels=c('Heal','Infl'))
  units$Chem <- factor(units$Chem,levels=c('v2','v3'))
  units$Sex <- factor(units$Sex,levels=c('Female','Male'))
  levels_age <- unique(as.character(units$Age_band))
  levels_age <- levels_age[order(as.numeric(sub('-.*','',levels_age)))]
  units$Age_band <- factor(units$Age_band,levels=levels_age)
  units
}

fit_clinical <- function(compartment,conditioned,source,genes){
  key <- model_key(compartment,conditioned)
  units <- load_clinical_units(compartment,source$units)
  raw_counts <- source$counts
  y0 <- edgeR::DGEList(counts=raw_counts)
  # Same group-based filter as the executed 06E baseline. No covariate-dependent rescue.
  keep <- edgeR::filterByExpr(y0,group=units$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
  expected_n <- if(compartment=='AUTHOR_MACROPHAGES')781L else 5678L
  if(sum(keep)!=expected_n) stop('Frozen expression-filter gene count differs')
  y <- edgeR::calcNormFactors(y0[keep,,keep.lib.sizes=FALSE],method='TMM')
  if(conditioned){
    positions <- match(IFN7_GENES,genes$gene_symbol)
    if(anyNA(positions)) stop('Fixed IFN7 member missing')
    cpm <- sweep(as.matrix(raw_counts[positions,,drop=FALSE]),2,y$samples$lib.size*y$samples$norm.factors/1e6,'/')
    score <- colMeans(log2(1+cpm))
    if(!is.finite(stats::sd(score))||stats::sd(score)==0) stop('IFN7 score has no variation')
    units$IFN7_z <- as.numeric(scale(score))
  }
  formula <- if(conditioned)~Chem+Sex+Age_band+IFN7_z+group else ~Chem+Sex+Age_band+group
  design <- stats::model.matrix(formula,units)
  rownames(design) <- units$unit_key
  qrd <- qr(design); df <- nrow(design)-qrd$rank
  if(qrd$rank!=ncol(design)||df<2L) stop('Clinical design is not identifiable or has fewer than two residual degrees of freedom')
  index <- match('groupInfl',colnames(design))
  if(is.na(index)) stop('Clinical group coefficient is missing')
  expected <- utils::read.delim(file.path(package_dir,'executed_metadata_audit',paste0('preflight_design_',key,'.tsv')),check.names=FALSE)
  if(!identical(as.character(expected$unit_key),rownames(design))||!identical(names(expected)[-1L],colnames(design))) stop('Actual R design differs from frozen metadata design keys')
  if(any(abs(as.matrix(expected[,-1L,drop=FALSE])-design)>1e-8)) stop('Actual R design differs from frozen metadata design values')
  leverage <- rowSums(qr.Q(qrd)^2)
  group_residual <- qr.resid(qr(design[,-index,drop=FALSE]),design[,index])
  if(sum(group_residual^2)<=1e-10) stop('Clinical contrast has no residual information')
  diagnostic <- data.frame(model_id=key,compartment=compartment,IFN7_conditioned=conditioned,n_donors=nrow(design),
                           n_parameters=ncol(design),rank=qrd$rank,nominal_residual_df=df,kappa_design=kappa(design,exact=TRUE),
                           maximum_leverage=max(leverage),n_age_bands=nlevels(units$Age_band),
                           formula=paste(deparse(formula),collapse=''),age_treatment='categorical_original_intervals_no_midpoint')
  DESIGN_RECORDS[[key]] <<- diagnostic
  write_tsv(do.call(rbind,DESIGN_RECORDS),'Table_06H2_design_diagnostics.tsv')
  write_tsv(data.frame(unit_key=rownames(design),design,check.names=FALSE),paste0('design_',key,'.tsv'))
  units$effective_library_size <- y$samples$lib.size*y$samples$norm.factors
  units$design_leverage <- leverage;units$residualized_group_indicator <- group_residual
  write_tsv(units,paste0('units_',key,'.tsv'))
  y <- edgeR::estimateDisp(y,design=design)
  fit <- edgeR::glmQLFit(y,design=design,robust=FALSE)
  qt <- as.data.frame(edgeR::topTags(edgeR::glmQLFTest(fit,coef=index),n=Inf,sort.by='none')$table)
  qt$gene_id <- rownames(qt);qt$gene_symbol <- genes$gene_symbol[match(qt$gene_id,genes$gene_id)]
  qt$genome_q <- stats::p.adjust(qt$PValue,'BH');qt$CI95_low <- NA_real_;qt$CI95_high <- NA_real_
  v <- limma::voom(y,design=design,plot=FALSE)
  vf <- limma::eBayes(limma::lmFit(v,design),robust=FALSE)
  vt <- as.data.frame(limma::topTable(vf,coef=index,number=Inf,sort.by='none',confint=.95))
  vt$gene_id <- rownames(vt);vt$gene_symbol <- genes$gene_symbol[match(vt$gene_id,genes$gene_id)]
  vt$PValue <- vt$P.Value;vt$genome_q <- stats::p.adjust(vt$PValue,'BH');vt$CI95_low <- vt$CI.L;vt$CI95_high <- vt$CI.R
  result <- list()
  baseline_name <- paste0('ALL_genes_',model_key(compartment,FALSE,FALSE),'_edgeR_QL.tsv')
  baseline_genes <- utils::read.delim(file.path(output_dir,baseline_name),check.names=FALSE)$gene_id
  for(backend in BACKENDS){
    full <- if(backend=='edgeR_QL')qt else vt
    if(any(!is.finite(full$PValue))||any(full$PValue<0|full$PValue>1)) stop('Nonfinite or invalid full-gene P values in clinical model')
    if(!setequal(full$gene_id,baseline_genes)) stop('Clinical tested-gene universe differs from baseline')
    write_tsv(full,paste0('ALL_genes_',key,'_',backend,'.tsv'))
    result[[backend]] <- candidate_rows(full,backend,key,compartment,conditioned,sum(units$Type=='Infl'),sum(units$Type=='Heal'),nrow(design),df)
  }
  do.call(rbind,result)
}

main <- function(){
  load_frozen_functions()
  genes <- utils::read.delim(file.path(input_dir,'genes.tsv'),check.names=FALSE)
  if(anyDuplicated(genes$gene_id)||anyDuplicated(genes$gene_symbol)||anyNA(match(c(TARGET_GENES,IFN7_GENES),genes$gene_symbol))) stop('Frozen gene identities differ')
  sources <- lapply(COMPARTMENTS,function(c)read_compartment(c,genes));names(sources)<-COMPARTMENTS
  baseline <- list();checks <- list()
  for(compartment in COMPARTMENTS){
    for(conditioned in c(FALSE,TRUE)){
      key <- model_key(compartment,conditioned,FALSE)
      message_log('REPRODUCE_06E',key)
      baseline[[key]] <- fit_model(compartment,conditioned,sources[[compartment]],genes)
      for(backend in BACKENDS) checks[[paste(key,backend)]] <- compare_full_baseline(key,backend)
      write_tsv(do.call(rbind,checks),'06H2_baseline_full_gene_reproduction_checks.tsv')
    }
  }
  if(!all(do.call(rbind,checks)$passed)) stop('Historical full-gene baseline did not reproduce; clinical fits were not started')
  baseline <- do.call(rbind,baseline)
  if(nrow(baseline)!=16L) stop('Historical baseline ledger does not have 16 rows')
  baseline$analysis_role <- 'historical_baseline_reproduction'
  baseline$clinical_covariates <- 'chemistry_only'
  baseline$q_previous_baseline_union16 <- bh_fixed_family(baseline$PValue)
  baseline$q_new_clinical_union16 <- NA_real_
  write_tsv(baseline,'Table_06H2_baseline_reproduced16.tsv')
  message_log('BASELINE_ALL_FULL_GENE_CHECKS_PASSED','clinical_models_starting')
  clinical <- list()
  for(compartment in COMPARTMENTS){
    for(conditioned in c(FALSE,TRUE)){
      key <- model_key(compartment,conditioned)
      message_log('FIT_CORRECTED_CLINICAL',key)
      source <- sources[[compartment]]
      result <- tryCatch(fit_clinical(compartment,conditioned,source,genes),error=function(error){
        message_log('CLINICAL_MODEL_UNAVAILABLE',key,conditionMessage(error))
        unavailable_rows(key,compartment,conditioned,conditionMessage(error),sum(source$units$Type=='Infl'),sum(source$units$Type=='Heal'))
      })
      clinical[[key]] <- result
      write_tsv(do.call(rbind,clinical),'clinical_candidate_progress.tsv')
    }
  }
  clinical <- do.call(rbind,clinical)
  if(nrow(clinical)!=16L) stop('Corrected clinical ledger does not have 16 rows')
  clinical$analysis_role <- 'corrected_clinical_sensitivity'
  clinical$clinical_covariates <- 'chemistry_plus_sex_plus_categorical_age_band'
  clinical$q_previous_baseline_union16 <- NA_real_
  clinical$q_new_clinical_union16 <- bh_fixed_family(clinical$PValue)
  clinical <- clinical[,names(baseline),drop=FALSE]
  all_rows <- rbind(baseline,clinical)
  all_rows$population_role <- ifelse(all_rows$compartment=='AUTHOR_MACROPHAGES','primary_author_compartment','pooled_compartment_sensitivity')
  planned <- utils::read.delim(file.path(input_dir,'PLANNED_06H2_ROWS32.tsv'),check.names=FALSE)
  keys <- function(x)paste(x$model_id,x$backend,x$gene_symbol,sep='::')
  if(nrow(all_rows)!=32L||anyDuplicated(keys(all_rows))||!setequal(keys(all_rows),keys(planned))) stop('Frozen 32-row plan differs')
  all_rows <- all_rows[match(keys(planned),keys(all_rows)),,drop=FALSE]
  write_tsv(all_rows,'Table_06H2_all_candidate_rows32.tsv')
  write_tsv(all_rows[all_rows$analysis_role=='corrected_clinical_sensitivity',,drop=FALSE],'Table_06H2_new_clinical_results16.tsv')
  short_key <- function(x)paste(x$compartment,x$IFN7_conditioned,x$backend,x$gene_symbol,sep='::')
  comparison <- all_rows[all_rows$analysis_role=='corrected_clinical_sensitivity',,drop=FALSE]
  indices <- match(short_key(comparison),short_key(baseline))
  if(anyNA(indices)) stop('Baseline/clinical candidate correspondence differs')
  comparison$baseline_status <- baseline$status[indices]
  comparison$baseline_log2FC <- baseline$log2FC[indices]
  comparison$baseline_genome_q <- baseline$genome_q[indices]
  comparison$clinical_minus_baseline_log2FC <- comparison$log2FC-comparison$baseline_log2FC
  write_tsv(comparison,'Table_06H2_baseline_clinical_comparison16.tsv')
  writeLines(c(
    'Public Table S1 age/sex were joined by exact selected Channel.ID, corroborated by Sample.ID and corrected donor records.',
    'Repeated donor records represent sampling events; the selected terminal-ileum 104152 channel uses age band 35-39.',
    'Age intervals enter as categorical levels; no exact ages or interval midpoints were imputed.',
    'The 14/17-donor populations, raw counts, group-based expression filter, TMM normalization and fixed IFN7 definition are retained.',
    'Full rank with small samples is not evidence of adequate covariate overlap. Inspect age-group overlap, leverage and residual degrees of freedom.',
    'The 16 new candidate-method rows form one additional BH family; unavailable tests remain in that family as P=1 only for correction.',
    'Transcriptome BH is also reported separately for every fitted full-gene model; nominal P values do not replace these q values.',
    'IFN7 conditioning changes the estimand and is not causal mediation. This follow-up does not create another independent cohort.',
    'Expression-filtered targets remain untested; no cutoff relaxation or population substitution is allowed.'
  ),file.path(output_dir,'06H2_INTERPRETATION.txt'))
  status <- if(any(clinical$status=='unavailable'))'COMPLETED_WITH_UNAVAILABLE_CLINICAL_MODELS'else'COMPLETED'
  writeLines(status,file.path(output_dir,'RUN_STATUS.txt'))
  n_unavailable <- length(unique(clinical$model_id[clinical$status=='unavailable']))
  writeLines(sprintf(paste0('{"phase":"06H2","baseline_full_gene_tables_reproduced":8,',
                           '"baseline_numeric_column_checks_passed":%d,"clinical_models_attempted":4,',
                           '"clinical_models_completed":%d,"clinical_models_unavailable":%d,',
                           '"new_clinical_candidate_rows":16,"new_tested_candidate_rows":%d,',
                           '"new_expression_filtered_candidate_rows":%d,"RUN_STATUS":"%s"}'),
                     nrow(do.call(rbind,checks)),4L-n_unavailable,n_unavailable,sum(clinical$status=='tested'),
                     sum(clinical$status=='not_tested_expression_filter'),status),file.path(output_dir,'06H2_R_FIT_STATUS.json'))
  message_log('DONE_06H2','planned_rows',nrow(all_rows),'new_clinical_rows',nrow(clinical),'new_tested_rows',sum(clinical$status=='tested'),'status',status)
}

tryCatch({main();capture.output(sessionInfo(),file=file.path(output_dir,'R_sessionInfo.txt'))},error=function(error){
  writeLines(conditionMessage(error),file.path(output_dir,'RUN_FAILED.txt'))
  capture.output(sessionInfo(),file=file.path(output_dir,'R_sessionInfo.txt'))
  message_log('FAILED_06H2',conditionMessage(error));quit(status=1L)
})
