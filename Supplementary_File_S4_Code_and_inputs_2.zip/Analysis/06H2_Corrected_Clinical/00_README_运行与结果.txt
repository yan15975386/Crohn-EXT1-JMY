06H2：更正临床表匹配及独立队列协变量敏感性分析

已完成：原文PDF第23页正式更正的阅读与目视核对；Table S1三层资料核验；30个通道、17位供者、31个分析单元的临床映射；9项实际资料检查；7926个源单元格的独立读取核对；4个设计矩阵的独立SVD秩检查。
待完成：服务器R语法检查、8张旧全基因结果表复现、4个新增临床模型（各2种方法）的拟合与结果审核。本地没有Rscript，不能把资料核验或代码准备当作已完成R统计分析。

本包包含全部必要的小型输入，使用现有R环境即可运行。不需要重新下载IBDverse或SCP1884计数矩阵，不创建Python环境、不安装任何依赖。Python只使用标准库；R使用之前已有的Matrix、edgeR、limma。BLAS限制为1线程，便于同时运行多个项目。

分析约定
- 固定使用两个既有群体：作者Macrophages（14位供者）和既有合并巨噬细胞群体（17位供者），均为终末回肠Infl versus Heal。
- 新增模型：Chem + Sex + Age_band + group，以及对应的加IFN7版本。年龄为原始区间分类变量，不作为任意炎症等级、不推算精确年龄、不取区间中点。
- 完整保留旧16行基线和新16行临床敏感性结果。各完整模型报告全转录组BH；新16行另作一个BH家族。缺失/过滤行保留。
- 不根据结果改变年龄编码、群体、过滤标准、治疗变量、基因或供者子集。年龄组间重叠有限，需结合残差自由度、杠杆值和设计诊断解释结果。
- 104152按所选I104152_N的35–39岁记录连接。不同采样事件不作为新增独立患者，不能按供者首行盲目合并。

步骤
将CD_06H2_Corrected_Clinical_20261108.zip上传到/media/desk16/iy12923/消化/scmore/CD_scMORE/，然后运行下方唯一一行命令。它创建独立运行目录，以nohup启动并用tail -f显示日志，结束时返回RETURN_ZIP。Ctrl+C可退出日志查看，后台任务继续运行。

bash -c 'set -euo pipefail; project="/media/desk16/iy12923/消化/scmore/CD_scMORE"; package="CD_06H2_Corrected_Clinical_20261108"; test -f "$project/$package.zip"; run=$(mktemp -d "$project/06H2_run_$(date +%Y%m%d_%H%M%S)_XXXXXX"); unzip -q "$project/$package.zip" -d "$run"; stamp="$(date +%Y%m%d_%H%M%S)_$$"; out="$project/results/06H2_corrected_clinical_20261108/$stamp"; log="$run/console.log"; ret="$project/CD_06H2_RESULTS_$stamp.zip"; nohup bash "$run/$package/run_06H2.sh" "$out" "$ret" "$log" >"$log" 2>&1 < /dev/null & pid=$!; printf "PID=%s\nLOG=%s\nRETURN_ZIP=%s\n" "$pid" "$log" "$ret"; tail --pid="$pid" -n 80 -f "$log"; wait "$pid"'

成功时应看到BASELINE_ALL_FULL_GENE_CHECKS_PASSED、DONE_06H2和EXIT_CODE=0。若某个新增模型不可估计，32行计划仍会保留并记录具体原因；请同时查看R_results/RUN_STATUS.txt和06H2_R_FIT_STATUS.json，不能仅凭已生成ZIP认定全部模型成功。
运行后将日志中RETURN_ZIP指向的CD_06H2_RESULTS_*.zip发回。届时再核对全基因BH、候选数值、临床模型设计、基线一致性，并整合全文和补充材料。

目录
public_sources/：用户提供的原始PDF和XLSX，未修改。
inputs/：原始小型伪批量计数、基因、冻结供者和细胞清单、新临床输入、固定32行计划。
reference_baseline/：既有服务器06E的8张完整结果表、临床比较所需元数据和原R会话信息。
executed_metadata_audit/：已执行的资料审计、源坐标、公式缓存核对、设计预检及独立读取QA。
06E_external_validation_frozen.R：原执行脚本的完整副本，新增脚本只导入其中5个未改动函数，不运行旧驱动。
06H2_clinical_adjustment.R：基线复现及新增临床模型。
06H_FINDINGS_中文.txt：更新后的临床核查报告。
SHA256SUMS.tsv：所有交付内容的指纹；启动时自动校验。

