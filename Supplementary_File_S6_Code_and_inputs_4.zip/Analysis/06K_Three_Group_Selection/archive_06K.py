from pathlib import Path
import sys,json,hashlib,zipfile,csv
out,code=map(Path,sys.argv[1:3]);status=int(sys.argv[3])
rows=[]
for root,prefix in [(out,'results'),(code,'executed_code')]:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix not in ['.rds','.zip']:
   rows.append((p,prefix+'/'+p.relative_to(root).as_posix(),hashlib.sha256(p.read_bytes()).hexdigest()))
label='RESULTS' if status==0 else 'PARTIAL';target=out.parent/('CD_06K_'+label+'_'+out.parent.name+'.zip')
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name,_ in rows:z.write(p,name)
 z.writestr('SHA256SUMS.tsv','sha256\tpath\n'+''.join(h+'\t'+name+'\n' for _,name,h in rows))
 z.writestr('execution_status.json',json.dumps({'exit_code':status,'full_model_rds_omitted_for_size':True,'complete_tables_and_executed_code_retained':True},indent=2))
with zipfile.ZipFile(target) as z:assert z.testzip() is None
print('RETURN_ZIP='+str(target),flush=True);print('EXIT_CODE='+str(status),flush=True)
