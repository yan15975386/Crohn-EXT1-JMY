#!/usr/bin/env Rscript
options(stringsAsFactors=FALSE,warn=1)
args<-commandArgs(trailingOnly=TRUE)
if(length(args)!=2L)stop('Usage: Rscript 06K_analysis.R CODE_DIRECTORY OUTPUT_DIRECTORY')
code<-normalizePath(args[1],mustWork=TRUE);out<-args[2]
dir.create(out,recursive=TRUE,showWarnings=FALSE)
for(pkg in c('Matrix','edgeR','limma'))if(!requireNamespace(pkg,quietly=TRUE))stop('Missing installed package: ',pkg)
logmsg<-function(...)cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),..., '\n')
read_tab<-function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE)
write_tab<-function(d,name){p<-file.path(out,name);con<-if(grepl('\\.gz$',p))gzfile(p,'wt')else file(p,'wt');on.exit(try(close(con),silent=TRUE));write.table(d,con,sep='\t',quote=FALSE,row.names=FALSE,na='NA')}
checks<-list()
check<-function(name,ok,detail=''){checks[[length(checks)+1L]]<<-data.frame(check=name,passed=isTRUE(ok),detail=as.character(detail));write_tab(do.call(rbind,checks),'numerical_checks.tsv');if(!isTRUE(ok))stop(name,': ',detail)}
TARGETS<-c('EXT1','JMY')
main<-function(){
 genes<-read_tab(file.path(code,'inputs/genes.tsv'));u<-read_tab(file.path(code,'inputs/units_CD163hi.tsv'))
 con<-gzfile(file.path(code,'inputs/counts_CD163hi.mtx.gz'),'rt');m<-tryCatch(as(Matrix::readMM(con),'CsparseMatrix'),finally=try(close(con),silent=TRUE))
 check('raw_dimensions',nrow(m)==nrow(genes)&&ncol(m)==nrow(u),paste(dim(m),collapse='x'))
 check('one_unit_per_donor',!anyDuplicated(u$individual_id)&&!anyDuplicated(u$unit_key))
 check('raw_integer_counts',all(is.finite(m@x))&&all(m@x>=0)&&all(m@x==floor(m@x)))
 check('fixed_group_sizes',identical(as.integer(table(factor(u$clinical_group,levels=c('Healthy','CD_uninflamed','CD_inflamed')))),c(113L,37L,50L)))
 check('target_unique_features',all(vapply(TARGETS,function(g)sum(genes$gene_symbol==g,na.rm=TRUE)==1L,logical(1))))
 check('fixed_minimum_cells',all(u$n_cells>=15L))
 rownames(m)<-genes$gene_id;colnames(m)<-u$unit_key
 expected<-read_tab(file.path(code,'inputs/baseline_candidates8.tsv'))
 prep<-function(index,levels){
  z<-u[index,,drop=FALSE];z$group<-factor(z$clinical_group,levels=levels);z$sex<-factor(z$sex,levels=c('female','male'));z$cohort_factor<-factor(z$cohort,levels=c('Discovery','Replication'));z$age_decade<-z$age_binned_10/10
  X<-model.matrix(~sex+age_decade+cohort_factor+group,z);rownames(X)<-z$unit_key
  check(paste0('design_full_rank_',length(index)),qr(X)$rank==ncol(X)&&nrow(X)-ncol(X)>=2L)
  y<-edgeR::DGEList(counts=m[,index,drop=FALSE]);keep<-edgeR::filterByExpr(y,group=z$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
  y<-edgeR::calcNormFactors(y[keep,,keep.lib.sizes=FALSE]);list(y=y,X=X,u=z)
 }
 fit<-function(obj,C,prefix,retain=FALSE){
  y<-edgeR::estimateDisp(obj$y,design=obj$X)
  qfit<-edgeR::glmQLFit(y,design=obj$X,robust=FALSE)
  v<-limma::voom(y,design=obj$X,plot=FALSE)
  vf<-limma::eBayes(limma::contrasts.fit(limma::lmFit(v,obj$X),C),robust=FALSE)
  rows<-list();full<-list()
  for(k in seq_len(ncol(C))){
   contrast<-colnames(C)[k]
   q<-as.data.frame(edgeR::topTags(edgeR::glmQLFTest(qfit,contrast=C[,k]),n=Inf,sort.by='none')$table)
   w<-as.data.frame(limma::topTable(vf,coef=k,number=Inf,sort.by='none',confint=.95))
   for(backend in c('edgeR_QL','limma_voom')){
    a<-if(backend=='edgeR_QL')q else w
    a$gene_id<-rownames(a);a$gene_symbol<-genes$gene_symbol[match(a$gene_id,genes$gene_id)]
    a$PValue<-if(backend=='edgeR_QL')a$PValue else a$P.Value
    a$genome_q<-p.adjust(a$PValue,'BH')
    a$CI95_low<-if(backend=='edgeR_QL')NA_real_ else a$CI.L
    a$CI95_high<-if(backend=='edgeR_QL')NA_real_ else a$CI.R
    check(paste(prefix,contrast,backend,'finite_tests',sep='_'),all(is.finite(a$PValue))&&all(is.finite(a$logFC)))
    id<-match(TARGETS,a$gene_symbol)
    row<-data.frame(model_id=prefix,contrast=contrast,backend=backend,gene_symbol=TARGETS,log2FC=a$logFC[id],CI95_low=a$CI95_low[id],CI95_high=a$CI95_high[id],PValue=a$PValue[id],genome_q=a$genome_q[id],n_tested_genes=nrow(a),n_total=nrow(obj$X),design_rank=ncol(obj$X),residual_df=nrow(obj$X)-ncol(obj$X),status=ifelse(is.na(id),'not_tested_expression_filter','tested'))
    rows[[paste(contrast,backend)]]<-row;full[[paste(contrast,backend)]]<-a
    if(retain)write_tab(a,paste0('ALL_genes_',contrast,'_',backend,'.tsv.gz'))
   }
  }
  if(retain){saveRDS(list(QL=qfit,voom=v,voom_contrasts=vf,design=obj$X,contrasts=C),file.path(out,'joint_model_objects.rds'));write_tab(data.frame(gene_id=rownames(y),gene_symbol=genes$gene_symbol[match(rownames(y),genes$gene_id)]),'joint_tested_gene_universe.tsv')}
  list(rows=do.call(rbind,rows),full=full,y=y)
 }
 baseline_rows<-list();baseline_audit<-list()
 for(old in c('A_vs_H','A_vs_U')){
  ref<-if(old=='A_vs_H')'Healthy'else'CD_uninflamed';index<-which(u$clinical_group%in%c(ref,'CD_inflamed'))
  obj<-prep(index,c(ref,'CD_inflamed'));C<-matrix(0,ncol(obj$X),1,dimnames=list(colnames(obj$X),old));C['groupCD_inflamed',1]<-1
  logmsg('REPRODUCE_BASELINE',old)
  z<-fit(obj,C,paste0('COHORT_',old))$rows
  for(i in seq_len(nrow(z))){
   e<-expected[expected$model_id==paste0('COHORT_',old)&expected$backend==z$backend[i]&expected$gene_symbol==z$gene_symbol[i],,drop=FALSE]
   check(paste0('unique_reference_',old,'_',i),nrow(e)==1L)
   for(field in c('log2FC','PValue','genome_q','CI95_low','CI95_high','n_tested_genes')){
    delta<-if(is.na(e[[field]])&&is.na(z[[field]][i]))0 else abs(e[[field]]-z[[field]][i])
    tol<-if(field=='n_tested_genes')0 else 1e-7
    check(paste('baseline',old,z$backend[i],z$gene_symbol[i],field,sep='_'),is.finite(delta)&&delta<=tol,format(delta,digits=16))
    baseline_audit[[length(baseline_audit)+1L]]<-data.frame(contrast=old,backend=z$backend[i],gene_symbol=z$gene_symbol[i],field=field,expected=e[[field]],observed=z[[field]][i],absolute_difference=delta,tolerance=tol,passed=is.finite(delta)&&delta<=tol)
   }
  }
  baseline_rows[[old]]<-z
 }
 write_tab(do.call(rbind,baseline_audit),'baseline_reproduction48.tsv')
 write_tab(do.call(rbind,baseline_rows),'baseline_candidate_results8.tsv')
 logmsg('FROZEN_BASELINES_REPRODUCED')
 obj<-prep(seq_len(nrow(u)),c('Healthy','CD_uninflamed','CD_inflamed'))
 C<-matrix(0,ncol(obj$X),3,dimnames=list(colnames(obj$X),c('I_vs_H','U_vs_H','I_vs_U')))
 C['groupCD_inflamed',c('I_vs_H','I_vs_U')]<-1;C['groupCD_uninflamed','U_vs_H']<-1;C['groupCD_uninflamed','I_vs_U']<--1
 check('contrast_algebra',all(C[,'I_vs_H']-C[,'U_vs_H']==C[,'I_vs_U']))
 write_tab(data.frame(term=rownames(C),C,check.names=FALSE),'joint_contrasts.tsv')
 z<-fit(obj,C,'JOINT_THREE_GROUP',retain=TRUE);r<-z$rows
 r$n_case<-ifelse(r$contrast=='U_vs_H',37L,50L);r$n_reference<-ifelse(r$contrast=='I_vs_U',37L,113L)
 r$q_exploratory_target6<-NA_real_
 for(backend in c('edgeR_QL','limma_voom')){
  j<-which(r$backend==backend);p<-r$PValue[j];qq<-p.adjust(ifelse(is.finite(p),p,1),'BH');qq[!is.finite(p)]<-NA_real_;r$q_exploratory_target6[j]<-qq
  a<-z$full[[paste('I_vs_H',backend)]];b<-z$full[[paste('U_vs_H',backend)]];c<-z$full[[paste('I_vs_U',backend)]]
  check(paste0(backend,'_common_gene_universe'),identical(a$gene_id,b$gene_id)&&identical(a$gene_id,c$gene_id))
  check(paste0(backend,'_all_gene_contrast_algebra'),max(abs(a$logFC-b$logFC-c$logFC))<1e-7,max(abs(a$logFC-b$logFC-c$logFC)))
 }
 check('all_twelve_target_rows',nrow(r)==12L&&!anyDuplicated(paste(r$contrast,r$backend,r$gene_symbol)))
 write_tab(r,'joint_candidate_results12.tsv')
 obj$u$filtered_library_size<-z$y$samples$lib.size;obj$u$TMM_factor<-z$y$samples$norm.factors;obj$u$effective_library_size<-z$y$samples$lib.size*z$y$samples$norm.factors
 write_tab(cbind(obj$u,as.data.frame(obj$X)),'joint_units_and_design200.tsv')
 check('TMM_geometric_mean_one',abs(mean(base::log(obj$u$TMM_factor)))<1e-10)
 write_tab(data.frame(metric=c('status','n_donors','n_genes','design_rank','residual_df','new_independent_cohorts','new_wet_experiments'),value=c('COMPLETED',nrow(obj$X),nrow(z$y),ncol(obj$X),nrow(obj$X)-ncol(obj$X),0,0)),'model_summary.tsv')
 logmsg('COMPLETED_06K_JOINT',nrow(r),'target rows;',nrow(z$y),'genes')
}
tryCatch({main();capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'));writeLines('COMPLETED',file.path(out,'RUN_STATUS.txt'))},error=function(e){capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'));writeLines(conditionMessage(e),file.path(out,'RUN_FAILED.txt'));logmsg('FAILED_06K',conditionMessage(e));quit(status=1)})
