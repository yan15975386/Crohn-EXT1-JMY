#!/usr/bin/env Rscript
options(stringsAsFactors=FALSE)
a<-commandArgs(trailingOnly=TRUE);if(length(a)!=2L)stop('Usage: Rscript 06K_selection_offline.R CODE_DIRECTORY OUTPUT_DIRECTORY')
code<-normalizePath(a[1],mustWork=TRUE);out<-a[2];dir.create(out,recursive=TRUE,showWarnings=FALSE)
read_tab<-function(p)read.delim(p,stringsAsFactors=FALSE,check.names=FALSE)
write_tab<-function(d,name)write.table(d,file.path(out,name),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
src<-file.path(code,'inputs/public_source')
mapping<-read_tab(file.path(src,'sample_individual_mapping.tsv'));individual<-read_tab(file.path(src,'individual_metadata.tsv'));sample<-read_tab(file.path(src,'sample_metadata.tsv'));cells<-read_tab(file.path(code,'inputs/source_sample_cell_counts343.tsv'))
stopifnot(nrow(mapping)==343L,!anyDuplicated(mapping$individual_id),!anyDuplicated(mapping$sanger_sample_id))
m<-merge(merge(merge(mapping,individual,by='individual_id',sort=FALSE),sample,by='sanger_sample_id',sort=FALSE),cells,by='sanger_sample_id',sort=FALSE)
stopifnot(nrow(m)==343L,sum(m$n_source_cells)==1185861L)
m$clinical_group<-ifelse(m$disease_status=='Healthy','Healthy',ifelse(m$ti_ses_inflamed=='inflamed','CD_inflamed','CD_uninflamed'))
m$covariates_complete<-m$sex%in%c('female','male')&is.finite(m$age_binned_10)&m$cohort%in%c('Discovery','Replication')
m$meets_cell_threshold<-m$n_CD163hi_cells>=15L;m$eligible<-m$covariates_complete&m$meets_cell_threshold
f<-read_tab(file.path(code,'inputs/units_CD163hi.tsv'));m$included_in_frozen200<-m$individual_id%in%f$individual_id
stopifnot(all(m$eligible==m$included_in_frozen200),sum(m$eligible)==200L)
matchrow<-match(f$individual_id,m$individual_id)
stopifnot(!anyNA(matchrow),all(f$n_cells==m$n_CD163hi_cells[matchrow]))
for(field in c('sex','cohort','age_binned_10','clinical_group','sanger_sample_id'))stopifnot(identical(as.character(f[[field]]),as.character(m[[field]][matchrow])))
m$CD163hi_fraction_source_cells<-m$n_CD163hi_cells/m$n_source_cells
flows<-list();balances<-list()
for(g in c('Healthy','CD_uninflamed','CD_inflamed')){
 z<-m[m$clinical_group==g,,drop=FALSE]
 vals<-c(nrow(z),sum(z$n_source_cells>0L),sum(z$n_CD163hi_cells>0L),sum(z$meets_cell_threshold),sum(z$eligible),sum(z$included_in_frozen200))
 flows[[g]]<-data.frame(clinical_group=g,stage=c('source_metadata','represented_in_H5AD','at_least_one_CD163hi_cell','at_least_15_CD163hi_cells','complete_covariates_and_15_cells','in_frozen_analysis'),n=vals,source_group_denominator=nrow(z),proportion_of_source_group=vals/nrow(z))
 for(field in c('age_binned_10','female','Replication','log2_source_cells_plus1','log2_CD163hi_cells_plus1','CD163hi_fraction_source_cells')){
  v<-switch(field,female=as.numeric(z$sex=='female'),Replication=as.numeric(z$cohort=='Replication'),log2_source_cells_plus1=base::log2(1+z$n_source_cells),log2_CD163hi_cells_plus1=base::log2(1+z$n_CD163hi_cells),z[[field]])
  x<-v[z$eligible];y<-v[!z$eligible]
  vx<-if(field%in%c('female','Replication'))mean(x)*(1-mean(x))else var(x)
  vy<-if(field%in%c('female','Replication'))mean(y)*(1-mean(y))else var(y)
  smd<-(mean(x)-mean(y))/sqrt((vx+vy)/2)
  balances[[paste(g,field)]]<-data.frame(clinical_group=g,field=field,n_included=length(x),n_excluded=length(y),included_mean_or_fraction=mean(x),excluded_mean_or_fraction=mean(y),included_median=median(x),excluded_median=median(y),SMD_included_minus_excluded=smd)
 }
}
write_tab(do.call(rbind,flows),'selection_flow18.tsv');write_tab(do.call(rbind,balances),'selection_balance18.tsv')
writeLines('COMPLETED; independently reconstructed from frozen public source metadata and metadata-only cell counts',file.path(out,'RUN_STATUS.txt'))
capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))
cat('OFFLINE_SELECTION_REPRODUCED 343 source; 200 eligible\n')
