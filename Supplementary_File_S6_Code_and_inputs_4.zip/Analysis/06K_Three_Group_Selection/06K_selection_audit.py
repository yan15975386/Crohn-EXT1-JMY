from pathlib import Path
import argparse,io,urllib.request,collections,json,hashlib,math
import numpy as np
import pandas as pd

URL='https://ftp.ebi.ac.uk/biostudies/fire/E-MTAB-/999/E-MTAB-16999/Files/Full_cohort.h5ad'
SIZE=25476124776
class RangeReader(io.RawIOBase):
    def __init__(self,url,size,block=1024*1024,maximum=256*1024*1024):
        self.url=url;self.size=size;self.block=block;self.maximum=maximum;self.position=0;self.cache=collections.OrderedDict();self.fetched=0;self.requests=0;self.identity=None
    def readable(self):return True
    def seekable(self):return True
    def tell(self):return self.position
    def seek(self,offset,whence=0):
        pos=offset if whence==0 else self.position+offset if whence==1 else self.size+offset
        if pos<0:raise ValueError('Negative seek')
        self.position=pos;return pos
    def read(self,size=-1):
        if size<0:raise RuntimeError('Whole-file read prohibited; metadata range access only')
        size=min(size,self.size-self.position)
        if size<=0:return b''
        output=[]
        while size:
            key=self.position//self.block
            if key not in self.cache:
                lo=key*self.block;hi=min(self.size,lo+self.block)-1
                if self.fetched+hi-lo+1>self.maximum:raise RuntimeError('Metadata range budget exceeded; no full H5AD download')
                req=urllib.request.Request(self.url,headers={'Range':f'bytes={lo}-{hi}','Accept-Encoding':'identity'})
                with urllib.request.urlopen(req,timeout=40) as f:
                    if f.status!=206 or f.headers.get('Content-Range')!=f'bytes {lo}-{hi}/{self.size}':raise RuntimeError('Source ignored or changed the validated HTTP range')
                    identity={k:f.headers.get(k) for k in ['ETag','Last-Modified']}
                    if self.identity is not None and identity!=self.identity:raise RuntimeError('Source identity changed across ranges')
                    self.identity=identity;b=f.read(hi-lo+2)
                    if len(b)!=hi-lo+1:raise RuntimeError('Incorrect range byte count')
                self.cache[key]=b;self.fetched+=len(b);self.requests+=1
                if len(self.cache)>32:self.cache.popitem(last=False)
                print('METADATA_RANGE',self.requests,'bytes',self.fetched,flush=True)
            self.cache.move_to_end(key);b=self.cache[key];start=self.position-key*self.block;n=min(size,len(b)-start)
            output.append(b[start:start+n]);self.position+=n;size-=n
        return b''.join(output)
    def readinto(self,buffer):
        b=self.read(len(buffer));buffer[:len(b)]=b;return len(b)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--code',required=True);ap.add_argument('--out',required=True);ap.add_argument('--remote-obs',action='store_true');ap.add_argument('--h5ad');a=ap.parse_args()
    code=Path(a.code);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);sources=code/'inputs/public_source'
    mapping=pd.read_csv(sources/'sample_individual_mapping.tsv',sep='\t');individual=pd.read_csv(sources/'individual_metadata.tsv',sep='\t');sample=pd.read_csv(sources/'sample_metadata.tsv',sep='\t')
    assert len(mapping)==343 and mapping.individual_id.nunique()==343 and mapping.sanger_sample_id.nunique()==343
    meta=mapping.merge(individual,on='individual_id',validate='one_to_one').merge(sample,on='sanger_sample_id',validate='one_to_one')
    cached=code/'inputs/source_sample_cell_counts343.tsv';provenance={}
    if a.remote_obs or a.h5ad:
        import h5py
        remote=None
        if a.h5ad:
            p=Path(a.h5ad);assert p.stat().st_size==SIZE;handle=p;provenance={'mode':'existing local H5AD obs only','source_size':SIZE}
        else:
            remote=RangeReader(URL,SIZE);handle=remote;provenance={'mode':'validated HTTP Range obs only','source_URL':URL,'source_size':SIZE}
        with h5py.File(handle,'r') as h:
            def categorical(name):
                node=h['obs'][name];return node['categories'].asstr()[:],node['codes'][:]
            labels,label_codes=categorical('label');samples,sample_codes=categorical('sanger_sample_id')
            assert len(label_codes)==len(sample_codes)==1185861
            assert set(samples)==set(mapping.sanger_sample_id)
            assert (sample_codes>=0).all() and sample_codes.max()<len(samples)
            totals=np.bincount(sample_codes,minlength=len(samples))
            hi=np.flatnonzero(labels=='Macrophages CD163-hi');assert len(hi)==1
            n_hi=np.bincount(sample_codes[label_codes==hi[0]],minlength=len(samples))
            states=['Macrophages CD163-hi','Macrophages CD163-lo','Macrophages ITGA4+','Macrophages CCL3/4+ CXCL9/10+']
            ids=np.flatnonzero(np.isin(labels,states));assert len(ids)==4
            n_mac=np.bincount(sample_codes[np.isin(label_codes,ids)],minlength=len(samples))
            cells=pd.DataFrame({'sanger_sample_id':samples,'n_source_cells':totals,'n_CD163hi_cells':n_hi,'n_four_state_macrophages':n_mac})
        if remote:
            provenance.update({'range_requests':remote.requests,'bytes_fetched':remote.fetched,'HTTP_identity':remote.identity,'whole_file_sha256_recomputed':False});remote.close()
        cells.to_csv(out/'source_sample_cell_counts343.tsv',sep='\t',index=False)
    else:
        if not cached.exists():raise RuntimeError('No frozen source cell counts; use existing --h5ad or explicitly --remote-obs')
        cells=pd.read_csv(cached,sep='\t');provenance={'mode':'frozen metadata-only extraction','source_file':cached.name,'sha256':hashlib.sha256(cached.read_bytes()).hexdigest()}
    meta=meta.merge(cells,on='sanger_sample_id',validate='one_to_one')
    assert len(meta)==343 and meta.n_source_cells.sum()==1185861
    meta['clinical_group']=np.select([meta.disease_status.eq('Healthy'),meta.disease_status.eq('CD')&meta.ti_ses_inflamed.eq('inflamed'),meta.disease_status.eq('CD')&meta.ti_ses_inflamed.eq('uninflamed')],['Healthy','CD_inflamed','CD_uninflamed'],default='UNAVAILABLE')
    assert not meta.clinical_group.eq('UNAVAILABLE').any()
    meta['covariates_complete']=meta.sex.isin(['female','male'])&meta.age_binned_10.notna()&meta.cohort.isin(['Discovery','Replication'])
    meta['meets_cell_threshold']=meta.n_CD163hi_cells.ge(15)
    meta['eligible']=meta.covariates_complete&meta.meets_cell_threshold
    frozen=pd.read_csv(code/'inputs/units_CD163hi.tsv',sep='\t');meta['included_in_frozen200']=meta.individual_id.isin(frozen.individual_id)
    assert np.array_equal(meta.eligible,meta.included_in_frozen200)
    compare=meta[meta.eligible].merge(frozen,on='individual_id',validate='one_to_one',suffixes=('_source','_frozen'))
    assert len(compare)==200 and np.array_equal(compare.n_CD163hi_cells,compare.n_cells)
    for field in ['sanger_sample_id','sex','age_binned_10','cohort','clinical_group']:
        assert np.array_equal(compare[field+'_source'].astype(str),compare[field+'_frozen'].astype(str)),field
    meta['exclusion_reason']=np.select([meta.eligible,~meta.covariates_complete,meta.n_CD163hi_cells.eq(0)],['included','incomplete_covariates','no_CD163hi_cells'],default='1_to_14_CD163hi_cells')
    meta['CD163hi_fraction_source_cells']=meta.n_CD163hi_cells/meta.n_source_cells
    meta.to_csv(out/'source_donor_eligibility343.tsv',sep='\t',index=False)
    flow=[];balance=[]
    for group in ['Healthy','CD_uninflamed','CD_inflamed']:
        z=meta[meta.clinical_group.eq(group)];keep=z[z.eligible];drop=z[~z.eligible]
        stages=[('source_metadata',len(z)),('represented_in_H5AD',int(z.n_source_cells.gt(0).sum())),('at_least_one_CD163hi_cell',int(z.n_CD163hi_cells.gt(0).sum())),('at_least_15_CD163hi_cells',int(z.meets_cell_threshold.sum())),('complete_covariates_and_15_cells',len(keep)),('in_frozen_analysis',int(z.included_in_frozen200.sum()))]
        for stage,n in stages:flow.append({'clinical_group':group,'stage':stage,'n':n,'source_group_denominator':len(z),'proportion_of_source_group':n/len(z)})
        for field in ['age_binned_10','female','Replication','log2_source_cells_plus1','log2_CD163hi_cells_plus1','CD163hi_fraction_source_cells']:
            def values(d):
                if field=='female':return d.sex.eq('female').astype(float).to_numpy()
                if field=='Replication':return d.cohort.eq('Replication').astype(float).to_numpy()
                if field=='log2_source_cells_plus1':return np.log2(1+d.n_source_cells.to_numpy())
                if field=='log2_CD163hi_cells_plus1':return np.log2(1+d.n_CD163hi_cells.to_numpy())
                return d[field].dropna().astype(float).to_numpy()
            x,y=values(keep),values(drop)
            vx=x.mean()*(1-x.mean()) if field in ['female','Replication'] else x.var(ddof=1)
            vy=y.mean()*(1-y.mean()) if field in ['female','Replication'] else y.var(ddof=1)
            denominator=math.sqrt((vx+vy)/2);smd=(x.mean()-y.mean())/denominator if denominator>0 else np.nan
            balance.append({'clinical_group':group,'field':field,'n_included':len(x),'n_excluded':len(y),'included_mean_or_fraction':x.mean(),'excluded_mean_or_fraction':y.mean(),'included_median':np.median(x),'excluded_median':np.median(y),'SMD_included_minus_excluded':smd})
    pd.DataFrame(flow).to_csv(out/'selection_flow18.tsv',sep='\t',index=False)
    pd.DataFrame(balance).to_csv(out/'selection_balance18.tsv',sep='\t',index=False)
    status={'status':'COMPLETED','source_donors':343,'source_cells':1185861,'frozen_eligible_donors_reproduced':200,'all_source_cells_and_included_metadata_match':True,'source_group_counts':meta.groupby('clinical_group').size().to_dict(),'eligible_group_counts':meta[meta.eligible].groupby('clinical_group').size().to_dict(),'exclusion_reasons':meta.groupby(['clinical_group','exclusion_reason']).size().to_dict().__str__(),'H5AD_access':provenance,'no_new_expression_tests_in_this_script':True}
    (out/'selection_audit_summary.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(status,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
