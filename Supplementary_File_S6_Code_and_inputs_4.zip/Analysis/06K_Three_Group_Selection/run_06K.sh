#!/usr/bin/env bash
set -euo pipefail
CD06K_CODE="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CD06K_ROOT="${1:?Project root required}"
CD06K_OUT="${2:?Unique output directory required}"
mkdir -p "$CD06K_OUT"
CD06K_RSCRIPT="${CD06K_RSCRIPT:-$(command -v Rscript || true)}"
if [ -z "$CD06K_RSCRIPT" ]; then printf '%s\n' 'Rscript is unavailable'; exit 1; fi
CD06K_PYTHON="${CD06K_PYTHON:-$(command -v python3 || true)}"
if [ -z "$CD06K_PYTHON" ]; then printf '%s\n' 'Python3 standard library is required for archiving'; exit 1; fi
cd06k_archive() { CD06K_EXIT=$?; trap - EXIT; "$CD06K_PYTHON" "$CD06K_CODE/archive_06K.py" "$CD06K_OUT" "$CD06K_CODE" "$CD06K_EXIT"; exit "$CD06K_EXIT"; }
trap cd06k_archive EXIT
printf 'START_06K\nOUTPUT=%s\n' "$CD06K_OUT"
"$CD06K_RSCRIPT" --vanilla "$CD06K_CODE/06K_analysis.R" "$CD06K_CODE" "$CD06K_OUT/R_results"
"$CD06K_RSCRIPT" --vanilla "$CD06K_CODE/06K_selection_offline.R" "$CD06K_CODE" "$CD06K_OUT/selection"
printf '%s\n' 'COMPLETED_06K; metadata and counts reused offline; no additional download or installation'
