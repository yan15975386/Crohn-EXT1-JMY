#!/usr/bin/env Rscript
options(stringsAsFactors=FALSE,warn=1)
args<-commandArgs(trailingOnly=TRUE)
if(length(args)!=3L)stop('Usage: Rscript 06L_analysis.R CODE OUTPUT BASELINE_REEXECUTION')
code<-normalizePath(args[1],mustWork=TRUE);out<-args[2];baseline<-normalizePath(args[3],mustWork=TRUE)
dir.create(out,recursive=TRUE,showWarnings=FALSE)
for(pkg in c('Matrix','edgeR','limma'))if(!requireNamespace(pkg,quietly=TRUE))stop('Missing package: ',pkg)
read_tab<-function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE)
write_tab<-function(d,name){p<-file.path(out,name);con<-if(grepl('\\.gz$',p))gzfile(p,'wt')else file(p,'wt');on.exit(try(close(con),silent=TRUE));write.table(d,con,sep='\t',quote=FALSE,row.names=FALSE,na='NA')}
checks<-list();check<-function(name,ok,detail=''){checks[[length(checks)+1L]]<<-data.frame(check=name,passed=isTRUE(ok),detail=as.character(detail));write_tab(do.call(rbind,checks),'numerical_checks.tsv');if(!isTRUE(ok))stop(name,': ',detail)}
logmsg<-function(...)cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),...,'\n')
TARGETS<-c('EXT1','JMY');IFN<-c('STAT1','IRF1','ISG15','MX2','GBP1','GBP2','GBP5')
main<-function(){
 expected<-read_tab(file.path(code,'inputs/expected_joint_candidates12.tsv'))
 observed<-read_tab(file.path(baseline,'joint_candidate_results12.tsv'))
 ba<-list()
 for(i in seq_len(nrow(expected))){
  e<-expected[i,,drop=FALSE];z<-observed[observed$contrast==e$contrast&observed$backend==e$backend&observed$gene_symbol==e$gene_symbol,,drop=FALSE]
  check(paste0('unique_joint_reference_',i),nrow(z)==1L)
  for(field in c('log2FC','PValue','genome_q','CI95_low','CI95_high','n_tested_genes')){
   delta<-if(is.na(e[[field]])&&is.na(z[[field]]))0 else abs(e[[field]]-z[[field]])
   tol<-if(field=='n_tested_genes')0 else 1e-7
   check(paste('joint_reproduction',i,field,sep='_'),is.finite(delta)&&delta<=tol,delta)
   ba[[length(ba)+1L]]<-data.frame(contrast=e$contrast,backend=e$backend,gene_symbol=e$gene_symbol,field=field,expected=e[[field]],observed=z[[field]],absolute_difference=delta,tolerance=tol,passed=is.finite(delta)&&delta<=tol)
  }
 }
 write_tab(do.call(rbind,ba),'joint_baseline_reproduction72.tsv');logmsg('EXISTING_JOINT_MODEL_REPRODUCED')
 genes<-read_tab(file.path(code,'inputs/genes.tsv'))
 check('unique_symbols',!anyDuplicated(genes$gene_symbol)&&!anyDuplicated(genes$gene_id))
 check('all_fixed_genes_present',all(c(TARGETS,IFN)%in%genes$gene_symbol))
 rows<-list();eligibility<-list();designs<-list();coverage<-list();inference<-list();units_all<-list()
 for(compartment in c('STRICT_MAC','CURATED_MAC')){
  u<-read_tab(file.path(code,'inputs',paste0('units_',compartment,'.tsv')))
  con<-gzfile(file.path(code,'inputs',paste0('counts_',compartment,'.mtx.gz')),'rt')
  m<-tryCatch(as(Matrix::readMM(con),'CsparseMatrix'),finally=try(close(con),silent=TRUE))
  check(paste0(compartment,'_dimensions'),nrow(m)==nrow(genes)&&ncol(m)==nrow(u))
  check(paste0(compartment,'_independent_donors'),!anyDuplicated(u$donor_id)&&!anyDuplicated(u$unit_key))
  check(paste0(compartment,'_integer_nonnegative'),all(is.finite(m@x))&&all(m@x>=0)&&all(m@x==floor(m@x)))
  check(paste0(compartment,'_frozen_group_sizes'),identical(as.integer(table(factor(u$group,levels=c('FGID','CD')))),c(13L,11L)))
  check(paste0(compartment,'_frozen_clinical_states'),all(u$inflammation==ifelse(u$group=='CD','Y','N'))&&all(u$n_cells>=15L))
  check(paste0(compartment,'_required_covariates'),all(is.finite(u$age_years))&&all(u$sex%in%c('female','male')))
  rownames(m)<-genes$gene_id;colnames(m)<-u$unit_key
  u$group<-factor(u$group,levels=c('FGID','CD'));u$sex<-factor(u$sex,levels=c('female','male'));u$age_decade<-u$age_years/10
  y0<-edgeR::DGEList(counts=m)
  keep<-edgeR::filterByExpr(y0,group=u$group,min.count=10,min.total.count=15,large.n=10,min.prop=.7)
  y<-edgeR::calcNormFactors(y0[keep,,keep.lib.sizes=FALSE])
  check(paste0(compartment,'_TMM_geometric_mean'),abs(mean(base::log(y$samples$norm.factors)))<1e-10)
  eff<-y$samples$lib.size*y$samples$norm.factors
  check(paste0(compartment,'_effective_library_positive'),all(is.finite(eff))&&all(eff>0))
  idx<-match(IFN,genes$gene_symbol)
  score<-colMeans(log2(1+sweep(as.matrix(m[idx,,drop=FALSE]),2,eff/1e6,'/')))
  check(paste0(compartment,'_IFN_score_finite'),all(is.finite(score))&&sd(score)>0)
  u$IFN7_z<-as.numeric(scale(score));u$filtered_library_size<-y$samples$lib.size;u$TMM_factor<-y$samples$norm.factors;u$effective_library_size<-eff;u$compartment<-compartment
  units_all[[compartment]]<-u
  for(g in TARGETS){
   gi<-match(g,genes$gene_symbol);raw<-as.numeric(m[gi,]);rawcpm<-raw/y0$samples$lib.size*1e6
   min_n<-min(table(u$group));required<-if(min_n>10)10+.7*(min_n-10)else min_n
   cutoff<-10/median(y0$samples$lib.size)*1e6
   passed<-sum(rawcpm>=cutoff)>=required-1e-14&&sum(raw)>=15-1e-14
   check(paste(compartment,g,'independent_filter_reproduction',sep='_'),identical(isTRUE(keep[gi]),isTRUE(passed)))
   eligibility[[length(eligibility)+1L]]<-data.frame(compartment=compartment,gene_symbol=g,total_counts=sum(raw),n_detected_donors=sum(raw>0),n_above_CPM_cutoff=sum(rawcpm>=cutoff),required_donors=required,CPM_cutoff=cutoff,passed_filter=keep[gi],n_tested_genes=sum(keep),n_CD=11,n_FGID=13)
   coverage[[length(coverage)+1L]]<-data.frame(compartment=compartment,donor_id=u$donor_id,group=as.character(u$group),gene_symbol=g,raw_counts=raw,raw_library_cpm=rawcpm,raw_library_size=y0$samples$lib.size,age_years=u$age_years,sex=as.character(u$sex),n_cells=u$n_cells)
  }
  for(model in c('CLINICAL','IFN7_CLINICAL')){
   form<-if(model=='CLINICAL')~sex+age_decade+group else ~sex+age_decade+IFN7_z+group
   X<-model.matrix(form,u);rownames(X)<-u$unit_key
   check(paste(compartment,model,'full_rank',sep='_'),qr(X)$rank==ncol(X)&&nrow(X)-ncol(X)>=2L)
   write_tab(data.frame(unit_key=u$unit_key,X,check.names=FALSE),paste0('design_',compartment,'_',model,'.tsv'))
   Y<-edgeR::estimateDisp(y,X);qfit<-edgeR::glmQLFit(Y,X,robust=FALSE)
   v<-limma::voom(Y,X,plot=FALSE);vf<-limma::eBayes(limma::lmFit(v,X),robust=FALSE)
   coef<-match('groupCD',colnames(X));check(paste(compartment,model,'group_coefficient',sep='_'),is.finite(coef))
   q<-as.data.frame(edgeR::topTags(edgeR::glmQLFTest(qfit,coef=coef),n=Inf,sort.by='none')$table)
   w<-as.data.frame(limma::topTable(vf,coef=coef,number=Inf,sort.by='none',confint=.95))
   for(backend in c('edgeR_QL','limma_voom')){
    a<-if(backend=='edgeR_QL')q else w;a$gene_id<-rownames(a);a$gene_symbol<-genes$gene_symbol[match(a$gene_id,genes$gene_id)]
    a$PValue<-if(backend=='edgeR_QL')a$PValue else a$P.Value;a$genome_q<-p.adjust(a$PValue,'BH')
    a$CI95_low<-if(backend=='edgeR_QL')NA_real_ else a$CI.L;a$CI95_high<-if(backend=='edgeR_QL')NA_real_ else a$CI.R
    check(paste(compartment,model,backend,'finite_tests',sep='_'),all(is.finite(a$PValue))&&all(is.finite(a$logFC))&&all(a$PValue>=0&a$PValue<=1))
    write_tab(a,paste0('ALL_genes_',compartment,'_',model,'_',backend,'.tsv.gz'))
    id<-match(TARGETS,a$gene_symbol)
    rr<-data.frame(study='SCP1422_SCP1423',compartment=compartment,model_id=model,backend=backend,contrast='Inflamed_untreated_CD_vs_FGID',gene_symbol=TARGETS,log2FC=a$logFC[id],CI95_low=a$CI95_low[id],CI95_high=a$CI95_high[id],PValue=a$PValue[id],genome_q=a$genome_q[id],n_tested_genes=nrow(a),n_CD=11,n_FGID=13,n_total=24,design_rank=ncol(X),residual_df=nrow(X)-ncol(X),status=ifelse(is.na(id),'not_tested_expression_filter','tested'))
    rows[[length(rows)+1L]]<-rr
   }
   inference[[length(inference)+1L]]<-data.frame(compartment=compartment,model_id=model,gene_id=rownames(vf),coefficient=vf$coefficients[,coef],stdev_unscaled=vf$stdev.unscaled[,coef],s2_post=vf$s2.post,df_total=vf$df.total)
   h<-rowSums(qr.Q(qr(X))^2);vif<-sapply(seq_len(ncol(X))[-1L],function(i){xx<-X[,i];res<-lm.fit(X[,-i,drop=FALSE],xx)$residuals;sum((xx-mean(xx))^2)/sum(res^2)})
   designs[[length(designs)+1L]]<-data.frame(compartment=compartment,model_id=model,formula=paste(deparse(form),collapse=''),n_total=nrow(X),rank=ncol(X),residual_df=nrow(X)-ncol(X),n_genes=nrow(Y),max_VIF=max(vif),max_leverage=max(h),IFN_group_correlation=cor(u$IFN7_z,as.numeric(u$group)))
   logmsg('FIT_COMPLETED',compartment,model,'genes',nrow(Y))
  }
 }
 r<-do.call(rbind,rows);check('sixteen_planned_rows',nrow(r)==16L&&!anyDuplicated(paste(r$compartment,r$model_id,r$backend,r$gene_symbol)))
 r$q_sensitivity16<-p.adjust(ifelse(is.finite(r$PValue),r$PValue,1),'BH');r$q_sensitivity16[!is.finite(r$PValue)]<-NA_real_
 write_tab(r,'candidate_results16.tsv');write_tab(do.call(rbind,eligibility),'target_eligibility4.tsv');write_tab(do.call(rbind,coverage),'target_donor_coverage96.tsv')
 write_tab(do.call(rbind,designs),'design_summary4.tsv');write_tab(do.call(rbind,units_all),'units_and_scores48.tsv');write_tab(do.call(rbind,inference),'voom_inference_components.tsv.gz')
 writeLines('COMPLETED',file.path(out,'RUN_STATUS.txt'));logmsg('COMPLETED_06L')
}
tryCatch({main();capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))},error=function(e){capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'));writeLines(conditionMessage(e),file.path(out,'RUN_FAILED.txt'));logmsg('FAILED_06L',conditionMessage(e));quit(status=1)})
